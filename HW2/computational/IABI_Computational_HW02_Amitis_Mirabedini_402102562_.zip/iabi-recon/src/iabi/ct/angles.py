"""Projection-angle samplers for the CT track.

The number of projection angles is the CT counterpart of MRI's acceleration
factor. Fewer angles means less dose and a faster scan, but the problem
becomes underdetermined and FBP develops streaks from high-contrast edges.
Measurements are simulated from clean images, so the angle count can be
changed freely and a trained model can be scored at other angle counts.

Parallel-beam projections at `theta` and `theta + pi` measure the same lines
from opposite sides, so a complete dataset spans ``[0, pi)``. Sampling over
``[0, 2*pi)`` duplicates lines and halves the effective angle count.
"""

from __future__ import annotations

import math

import torch
from torch import Tensor

__all__ = ["equispaced_angles"]


def equispaced_angles(
    n_angles: int,
    offset: float = 0.0,
    device: torch.device | str = "cpu",
) -> Tensor:
    """`n_angles` angles evenly spaced over ``[0, pi)``.

    Parameters
    ----------
    offset:
        Rotate the whole set by this many radians. Randomising the offset
        during training stops the network from keying on one fixed geometry.
    """
    if n_angles < 1:
        raise ValueError(f"n_angles must be >= 1, got {n_angles}")
    base = torch.linspace(0, math.pi, n_angles + 1, device=device)[:-1]
    return base + offset

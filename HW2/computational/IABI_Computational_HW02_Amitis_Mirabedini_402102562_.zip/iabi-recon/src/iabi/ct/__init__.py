"""The CT track: everything specific to low-dose CT.

TODOs 4 to 7 are here: forward projection and backprojection (`operator.py`),
the low-dose noise model (`simulate.py`) and the ramp filter (`filters.py`).
After the MRI track this folder is all that is left; the shared code is reused
unchanged. `angles.py` is given.

Gate: pytest tests/ct tests/test_adjoint.py
"""

from .angles import equispaced_angles
from .filters import ramp_filter
from .operator import ParallelBeamRadon
from .simulate import simulate_ct

__all__ = ["ParallelBeamRadon", "ramp_filter", "equispaced_angles", "simulate_ct"]

"""Low-dose CT measurement simulation: Beer-Lambert, Poisson, log.

TODO 6. Read `iabi/mri/simulate.py` first: it is short and given, and this
file follows its conventions.

MRI noise is Gaussian; CT noise is not
--------------------------------------
The CT detector counts photons, so the noise is Poisson, and the sinogram is
computed through a logarithm::

    I = I0 * exp(-A(x))          Beer-Lambert attenuation
    N ~ Poisson(I)               photon counting at the detector
    p = -log(N / I0)             the log-transformed sinogram

So the noise in `p` depends on the signal. Rays through dense structures
arrive with fewer photons and are the noisiest, which is why low-dose streaks
come from dense material. The log of a Poisson variable is also biased, badly
so when counts approach zero. This follows the LoDoPaB-CT protocol. Adding
Gaussian noise to `A(x)` would lose both effects.
"""

from __future__ import annotations

import math

import torch
from torch import Generator, Tensor

from .operator import ParallelBeamRadon

__all__ = ["simulate_ct"]


def simulate_ct(
    x: Tensor,
    op: ParallelBeamRadon,
    photons: float = 4096.0,
    mu_scale: float = 3.0,
    generator: Generator | None = None,
) -> Tensor:
    """Simulate a low-dose sinogram with Beer-Lambert attenuation and Poisson noise.

    Parameters
    ----------
    photons:
        Incident photon count per detector bin, `I0`. This is the dose knob:
        4096 matches the LoDoPaB-CT low-dose setting, higher is a cleaner
        scan, and dropping toward a few hundred gives a punishing one. Set to
        ``float('inf')`` for a noiseless sinogram.
    mu_scale:
        Converts normalised image intensity into an attenuation coefficient so
        that the exponential lands in a usable dynamic range. This value is
        load-bearing, and it is worth seeing why.

        The field of view spans [-1, 1] in image coordinates, so a ray
        crossing all of it at intensity `v` has line integral
        ``2 * v * mu_scale``. Intensities are normalised to [0, 1], so `v = 1`
        is the hardest case the scaling can ever face. The number of photons
        reaching the detector is ``I0 * exp(-that)``, and with `I0 = 4096`:

        =========  ===============  ==================  ============
        mu_scale   worst-case A     photons at detector  noise
        =========  ===============  ==================  ============
        3          6.0              10                  31%
        10         20.0             8e-6                total loss
        30         60.0             4e-23               total loss
        =========  ===============  ==================  ============

        Below roughly one photon the count clamps (see the `clamp` below) and
        the measurement stops depending on the object at all: the sinogram
        goes flat and no method can reconstruct anything. Too small, and every
        ray arrives with plenty of photons and the problem is trivially
        noise-free.

        That table is the *bound*, not the typical case: it assumes a solid
        block of maximum intensity filling the scanner. A real head does not,
        so the shipped packs sit comfortably inside it. Measured over all
        2500 slices at `mu_scale=3.0` and `I0=4096`:

        ===================================  ==========
        largest line integral A(x)           4.36
        fewest photons at any detector bin   52
        noise on that worst ray              14%
        noise on a median ray                3%
        bins expected to clamp at zero       none
        ===================================  ==========

        So at the default dose a median ray has around 3%
        noise and the worst rays around four times that. It is
        signal-dependent by construction, which makes this a low-dose problem
        rather than a denoising one, and the reason streaks radiate from dense
        structure. See `tests/ct/test_simulate.py`, which checks the bound
        rather than these measured numbers, so it stays valid if the packs
        change.

    Returns
    -------
    The log-transformed noisy sinogram, on the same scale as ``op.A(x)`` so it
    can be compared against the forward operator directly.
    """
    # ------------------------------------------------------------------
    # ------------------------------------------------------------------
    # TODO(students) [6/20]: simulate a low-dose sinogram.
    #
    #   1. clean = op.A(x * mu_scale). If `photons` is not finite, there is no
    #      noise to add: return clean / mu_scale. (math.isfinite, because
    #      `photons` is a Python float.)
    #   2. intensity = photons * exp(-clean)              Beer-Lambert
    #   3. counts ~ Poisson(intensity)                    photon counting
    #      torch.poisson(intensity.cpu(), generator=generator), then move back:
    #      a CPU Generator cannot seed sampling into a CUDA tensor.
    #   4. Clamp counts to a minimum of 1, then -log(counts / photons), and
    #      return that divided by mu_scale.
    #
    # The clamp matters: a bin that recorded nothing would give an infinite
    # line integral, which is the model breaking down rather than a
    # numerical accident.
    #
    # This chain is what makes the noise *signal-dependent*: dense material
    # passes fewest photons and is noisiest. Adding Gaussian noise to the
    # sinogram instead turns a low-dose problem into a denoising exercise,
    # and it never looks broken.
    #
    # Gate: pytest tests/ct/test_simulate.py
    # ------------------------------------------------------------------
    clean = op.A(x * mu_scale)
    if not math.isfinite(photons):
        return clean / mu_scale
    intensity = photons * torch.exp(-clean)
    counts = torch.poisson(intensity.cpu(), generator=generator).to(x.device)
    return -torch.log(counts.clamp(min=1) / photons) / mu_scale

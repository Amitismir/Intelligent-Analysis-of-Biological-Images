"""CT forward operator: 2D parallel-beam Radon transform.

Physics
-------
An X-ray beam is attenuated by everything along its path. By Beer-Lambert,
the log of the intensity drop is the line integral of the attenuation
coefficient. A parallel-beam scanner records one row of parallel line
integrals per gantry angle, and the rows stacked over angles form a sinogram:
the Radon transform of the slice. Lower dose means fewer photons (noisier
rows) or fewer angles (sparse view), and both make the inverse problem harder.

Why we implement it by hand
---------------------------
Production projectors (ASTRA, torch-radon, LEAP) are compiled CUDA and often
fail to install on a fresh Colab runtime. A parallel-beam projector is about
forty lines of `grid_sample`:

    forward projection  = rotate the image by theta, then sum down the columns
    backprojection      = smear each detector row back across the image,
                          apply the transpose rotation, and accumulate
                          over angles

Backprojection is the adjoint, not the inverse: it gives a recognisable but
very blurry image. Filtering the rows before backprojecting makes it sharp;
see `ct/filters.py`.

Accuracy
--------
This is a teaching projector: bilinear rotation, no ray-driven weighting, no
detector model. Don't benchmark it against ASTRA.

`A_adjoint` is still the exact transpose of `A` to float32 precision, and
`tests/test_adjoint.py` checks it with the same tolerance as MRI. The
transpose of an interpolation is not the interpolation run backwards:
resampling onto a rotated grid and back undoes the geometry but not the
bilinear weights, and the two differ by about ten percent at a generic angle.
The transpose of a gather is a scatter, which is what the backward pass of
`grid_sample` computes; see `_rotate_adjoint`.
"""

from __future__ import annotations

import math

import torch
import torch.nn.functional as F
from torch import Tensor

from ..shared.operator import Operator
from .filters import ramp_filter

__all__ = ["ParallelBeamRadon"]


def _rotation_grids(angles: Tensor, n: int, inverse: bool = False) -> Tensor:
    """Affine sampling grids that rotate an `n x n` image by each angle.

    Returns a tensor of shape ``(n_angles, n, n, 2)`` suitable for
    `F.grid_sample`. With ``inverse=True`` the grid for the opposite rotation
    is built.

    Note what ``inverse=True`` is *not*: it is not the transpose of the
    forward interpolation. Rotating back undoes the geometry but not the
    bilinear weighting, and the two differ by around ten percent at a generic
    angle, far too much for `A_adjoint` to be built out of it. The exact
    transpose is `_rotate_adjoint` below.
    """
    cos, sin = torch.cos(angles), torch.sin(angles)
    zero = torch.zeros_like(cos)
    if inverse:
        # Transpose of the rotation matrix below.
        theta = torch.stack(
            [
                torch.stack([cos, sin, zero], dim=-1),
                torch.stack([-sin, cos, zero], dim=-1),
            ],
            dim=-2,
        )
    else:
        theta = torch.stack(
            [
                torch.stack([cos, -sin, zero], dim=-1),
                torch.stack([sin, cos, zero], dim=-1),
            ],
            dim=-2,
        )
    return F.affine_grid(
        theta, size=(angles.shape[0], 1, n, n), align_corners=False
    )


def _rotate(x: Tensor, grid: Tensor) -> Tensor:
    """Bilinear resample of `x` on `grid`. This is the matrix ``W``."""
    return F.grid_sample(
        x, grid, mode="bilinear", padding_mode="zeros", align_corners=False
    )


class _RotateAdjoint(torch.autograd.Function):
    """``v -> W^T v``, the exact transpose of `_rotate`.

    `grid_sample` gathers: every output pixel is a weighted sum of its four
    neighbours in the input. The transpose is the matching *scatter*, which
    `grid_sample` does not expose. It is precisely what its own backward
    pass computes, because for a linear map the vector-Jacobian product is the
    transpose. So we run that backward pass directly.

    Doing it through a custom `Function` rather than a bare
    `torch.autograd.grad` call keeps the result differentiable: `backward`
    below is `_rotate` again, which is what lets gradients flow through
    `A_adjoint` in a training loop.
    """

    @staticmethod
    def forward(ctx, v: Tensor, grid: Tensor, shape: tuple[int, ...]) -> Tensor:
        ctx.save_for_backward(grid)
        with torch.enable_grad():
            x = torch.zeros(shape, device=v.device, dtype=v.dtype, requires_grad=True)
            (out,) = torch.autograd.grad(_rotate(x, grid), x, grad_outputs=v)
        return out

    @staticmethod
    def backward(ctx, g: Tensor):  # pragma: no cover - exercised via autograd
        (grid,) = ctx.saved_tensors
        return _rotate(g, grid), None, None


def _rotate_adjoint(v: Tensor, grid: Tensor, shape: tuple[int, ...]) -> Tensor:
    """Apply ``W^T`` for the bilinear resampling defined by `grid`."""
    return _RotateAdjoint.apply(v, grid, shape)


class ParallelBeamRadon(Operator):
    """2D parallel-beam Radon transform on a square image.

    Parameters
    ----------
    angles:
        Projection angles in radians. For a complete parallel-beam dataset
        these should span ``[0, pi)``, since angles pi apart measure the same
        lines from the other side and add no information.
    n_pixels:
        Side length of the (square) image. Detector bins equal `n_pixels`.
    angle_chunk:
        How many angles to rotate at once. Peak memory is
        ``batch * angle_chunk * n_pixels^2`` floats; lower this if a
        many-angle configuration runs out of memory on a T4.

    Shapes
    ------
    ``x : (B, 1, N, N) float32``  ->  ``y : (B, 1, n_angles, N) float32``
    """

    name = "ct"

    def __init__(self, angles: Tensor, n_pixels: int, angle_chunk: int = 64):
        self.angles = angles
        self.n_pixels = int(n_pixels)
        self.angle_chunk = int(angle_chunk)
        # Image spans [-1, 1], so one pixel is 2/N wide. This is the `s` in the
        # ramp-filter derivation and the scale that turns a pixel sum into a
        # line integral.
        self.pixel_size = 2.0 / self.n_pixels
        self._grids: dict[tuple[bool, torch.device], Tensor] = {}

    def to(self, device: torch.device | str) -> "ParallelBeamRadon":
        return ParallelBeamRadon(
            self.angles.to(device), self.n_pixels, self.angle_chunk
        )

    @property
    def n_angles(self) -> int:
        return int(self.angles.shape[0])

    def _grid(self, inverse: bool, device: torch.device) -> Tensor:
        """Cached rotation grids; rebuilding these every call is wasteful."""
        key = (inverse, device)
        if key not in self._grids:
            self._grids[key] = _rotation_grids(
                self.angles.to(device), self.n_pixels, inverse=inverse
            )
        return self._grids[key]

    # ------------------------------------------------------------------
    # Forward and adjoint
    # ------------------------------------------------------------------

    def A(self, x: Tensor) -> Tensor:
        """Image -> sinogram (forward projection)."""
        # ------------------------------------------------------------------
        # ------------------------------------------------------------------
        # TODO(students) [4/20]: forward projection.
        #
        # Per angle: rotate the image with the provided `_rotate`, sum down
        # dim=-2 for one detector row, scale by `self.pixel_size` to turn a
        # pixel sum into a line integral. `self._grid(False, x.device)` gives
        # you the (n_angles, N, N, 2) grids `_rotate` expects.
        #
        # Work in chunks of `self.angle_chunk` so a 180-angle config fits in
        # memory, and stack to (B, 1, n_angles, N). To rotate one image by many
        # angles at once, expand x to (B*a, 1, N, N) and the grids to
        # (B*a, N, N, 2). `_backproject_raw` does exactly this in the other
        # direction, so read it if the reshaping bites.
        #
        # Gate: pytest tests/test_adjoint.py tests/ct/test_shapes.py
        # ------------------------------------------------------------------
        b, _, n, _ = x.shape
        grids = self._grid(False, x.device)
        projections = []
        for start in range(0, self.n_angles, self.angle_chunk):
            g = grids[start : start + self.angle_chunk]
            a = g.shape[0]
            xb = x.unsqueeze(1).expand(b, a, 1, n, n).reshape(b * a, 1, n, n)
            gb = g.unsqueeze(0).expand(b, a, n, n, 2).reshape(b * a, n, n, 2)
            rotated = _rotate(xb, gb)
            row = rotated.sum(dim=-2) * self.pixel_size
            projections.append(row.reshape(b, a, n))
        return torch.cat(projections, dim=1).unsqueeze(1)

    def _backproject_raw(self, y: Tensor) -> Tensor:
        """Unscaled backprojection: smear, then apply the transpose rotation.

        Kept separate from `A_adjoint` because the adjoint and the FBP
        reconstruction need *different* scale factors applied to the same
        geometric operation. Conflating them is the classic reason a
        hand-written FBP comes out with the right structure at the wrong
        brightness.

        This is the exact transpose of the geometry in `A`, built from the
        *forward* grid via `_rotate_adjoint`. Resampling on the inverse grid
        instead would look right and be wrong by about ten percent; see
        `_rotation_grids`.
        """
        b = y.shape[0]
        n = self.n_pixels
        grids = self._grid(False, y.device)
        out = torch.zeros(b, 1, n, n, device=y.device, dtype=y.dtype)
        sino = y.squeeze(1)  # (B, n_angles, N)
        for start in range(0, self.n_angles, self.angle_chunk):
            g = grids[start : start + self.angle_chunk]
            a = g.shape[0]
            chunk = sino[:, start : start + a, :]  # (B, a, N)
            # Adjoint of "sum down the columns" is "broadcast back up them".
            smear = chunk.unsqueeze(-2).expand(b, a, n, n).reshape(b * a, 1, n, n)
            gb = g.unsqueeze(0).expand(b, a, n, n, 2).reshape(b * a, n, n, 2)
            rot = _rotate_adjoint(smear, gb, (b * a, 1, n, n))
            out = out + rot.reshape(b, a, 1, n, n).sum(dim=1)
        return out

    def A_adjoint(self, y: Tensor) -> Tensor:
        """Sinogram -> image (backprojection).

        This is the adjoint of `A`, *not* its inverse. The result is the
        blurry unfiltered backprojection. Compare it side by side with `fbp`
        in the notebook. The difference is one filter, and seeing it is the
        point of the exercise.
        """
        # ------------------------------------------------------------------
        # ------------------------------------------------------------------
        # TODO(students) [5/20]: backprojection.
        #
        # `_backproject_raw` does the geometry. What is missing is the scale
        # factor that makes this the true adjoint of `A`.
        #
        # Derive it: `A` rotates, sums along dim=-2, and multiplies by
        # pixel_size. The adjoint of a sum is a broadcast, the adjoint of the
        # rotation is `_rotate_adjoint` (both already done for you inside
        # `_backproject_raw`), and the adjoint of "multiply by a constant" is
        # the same constant.
        #
        # Worth knowing why `_backproject_raw` calls `_rotate_adjoint` and not
        # simply `_rotate` on the inverse grid: rotating back undoes the
        # geometry but not the bilinear weights, so it is about ten percent
        # off being the transpose. See this module's docstring.
        #
        # Gate: pytest tests/test_adjoint.py
        # ------------------------------------------------------------------
        return self._backproject_raw(y) * self.pixel_size

    def measurement_shape(self, image_shape: tuple[int, ...]) -> tuple[int, ...]:
        b = image_shape[0]
        return (b, 1, self.n_angles, self.n_pixels)

    # ------------------------------------------------------------------
    # Provided baseline: filtered backprojection.
    # ------------------------------------------------------------------

    def fbp(self, y: Tensor, window: str = "ramlak") -> Tensor:
        r"""Filtered backprojection: the classical analytic inverse.

        Ramp-filter each detector row, then backproject. The angular integral
        :math:`\int_0^\pi d\theta` is discretised as :math:`\pi/n_{angles}`
        times a sum, and because `_backproject_raw` carries no `pixel_size`
        factor the scaling works out to exactly that constant.

        This is rung one of the CT baseline ladder. It is fast, needs no
        training, and falls apart at low dose and low angle counts, which is
        precisely the gap the learned methods are trying to close.
        """
        filtered = ramp_filter(y, self.pixel_size, window=window)
        return self._backproject_raw(filtered) * (math.pi / self.n_angles)

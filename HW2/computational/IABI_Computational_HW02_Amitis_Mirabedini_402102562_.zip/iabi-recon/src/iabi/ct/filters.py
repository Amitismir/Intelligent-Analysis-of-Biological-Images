"""The ramp filter: the *filtered* in filtered backprojection.

TODO 7. It is kept apart from `operator.py` because it is 1D signal processing
on each detector row rather than geometry. Without it backprojection gives a
blurry image, and with the right scale FBP gives quantitative attenuation
values. The derivation is on `ramp_filter`.
"""

from __future__ import annotations

import math

import torch
import torch.nn.functional as F
from torch import Tensor

__all__ = ["ramp_filter"]


def ramp_filter(sino: Tensor, pixel_size: float, window: str = "ramlak") -> Tensor:
    r"""Apply the ramp filter along the detector axis of a sinogram.

    The filtered-backprojection formula is

    .. math::
        f(x) = \int_0^{\pi} q_\theta(x \cdot n_\theta)\, d\theta, \qquad
        q_\theta(t) = \int |\nu| P_\theta(\nu) e^{2\pi i \nu t} d\nu

    so the filter is :math:`|\nu|` and the obvious implementation is to
    multiply ``rfft(p)`` by ``rfftfreq(N, d=s).abs()``. That is wrong, and
    wrong in a way worth understanding, because it looks right: the structure
    comes out correct and only the *quantitative* values are off.

    Two things break it. Sampling :math:`|\nu|` pointwise is the DFT of a
    spatial kernel that has been wrapped periodically, so each projection is
    filtered with contributions from its own opposite end; and the sample at
    :math:`\nu = 0` sets the filter's DC gain to exactly zero, discarding the
    mean of every projection. The result is a smooth negative bowl across the
    image whose depth grows with the size of the object: a 128-pixel disk of
    true attenuation 0.8 came back at 0.70 spanning half the field of view and
    at 0.54 spanning most of it.

    The fix is the standard one (Kak & Slaney, *Principles of Computerized
    Tomographic Imaging*, §3.3.3): build the filter from the band-limited ramp's
    *spatial* impulse response, sampled at the detector spacing `s`,

    .. math::
        h(0) = \frac{1}{4s^2}, \qquad
        h(ns) = \begin{cases}
            0 & n \text{ even} \\
            -\dfrac{1}{\pi^2 n^2 s^2} & n \text{ odd}
        \end{cases}

    and convolve, :math:`q = s\,(h * p)`, via an FFT on a grid zero-padded to
    at least twice the detector width so the convolution is linear rather than
    circular. With that, the same disk reconstructs at 0.800 at every radius.

    Parameters
    ----------
    window:
        ``"ramlak"`` is the unwindowed ramp: sharpest, noisiest. ``"hann"``
        tapers the high frequencies, trading resolution for noise suppression.
        Comparing the two at low dose is a cheap ablation, and the one
        projection-domain experiment in this assignment: a fixed, hand-designed
        sinogram filter, the classical ancestor of the learned ones.
    """
    if window not in ("ramlak", "hann"):
        raise ValueError(f"unknown window {window!r}; use 'ramlak' or 'hann'")

    # ------------------------------------------------------------------
    # ------------------------------------------------------------------
    # TODO(students) [7/20]: apply the ramp filter along the detector axis.
    #
    # Follow the docstring above: build the filter from the ramp's *spatial*
    # impulse response, not by sampling |nu| on the frequency axis.
    #
    #   1. n_pad = next power of two >= 2 * n_det, and zero-pad the sinogram to
    #      it on the right. The FFT convolves circularly; the padding is what
    #      makes it linear over the detector.
    #   2. taps = arange(-(n_pad // 2), n_pad // 2), then
    #        h[0]     = 1 / (4 * s^2)
    #        h[odd]   = -1 / (pi * n * s)^2
    #        h[even]  = 0                       with s = pixel_size
    #      filt = rfft(ifftshift(h)).real * s   (the ifftshift puts the
    #      centre tap at index 0, where the DFT expects it.)
    #   3. For "hann", taper by (1 + cos(pi * nu / nu_max)) / 2 with
    #      nu = rfftfreq(n_pad, d=pixel_size).
    #   4. rfft along dim=-1 only, so each projection is filtered on its own
    #      and never across angles. Multiply, irfft(..., n=n_pad, dim=-1), then
    #      slice back to the first n_det samples.
    #
    # The tempting one-liner, rfft(p) * rfftfreq(n_det).abs(), gives the right
    # structure at the wrong brightness: it zeroes the filter's DC gain, which
    # throws away the mean of every projection. It is not a constant you can
    # patch up in `fbp` afterwards, because the error grows with the size of
    # the object.
    #
    # Gate: pytest tests/ct/test_fbp.py
    # ------------------------------------------------------------------
    n_det = sino.shape[-1]
    n_pad = 1 << (2 * n_det - 1).bit_length()
    taps = torch.arange(-n_pad // 2, n_pad // 2, device=sino.device)
    h = torch.zeros(n_pad, device=sino.device, dtype=sino.dtype)
    h[taps == 0] = 1 / (4 * pixel_size**2)
    odd = taps % 2 != 0
    h[odd] = -1 / (math.pi * taps[odd] * pixel_size)**2
    filt = torch.fft.rfft(torch.fft.ifftshift(h)).real * pixel_size
    if window == "hann":
        nu = torch.fft.rfftfreq(n_pad, d=pixel_size, device=sino.device)
        filt = filt * (1 + torch.cos(math.pi * nu / nu[-1])) / 2
    padded = F.pad(sino, (0, n_pad - n_det))
    return torch.fft.irfft(torch.fft.rfft(padded, dim=-1) * filt,
                           n=n_pad, dim=-1)[..., :n_det]

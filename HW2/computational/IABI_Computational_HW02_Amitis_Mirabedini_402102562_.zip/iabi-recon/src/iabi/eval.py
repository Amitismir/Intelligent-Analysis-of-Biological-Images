r"""Evaluation entry point. Provided and working; no TODOs.

Scores a method on the test split and writes a `results.json` for your report
to cite.

Usage::

    # a classical baseline: nothing to load, nothing to train
    python -m iabi.eval --config src/iabi/configs/mri_zerofilled.yaml

    # a trained model
    python -m iabi.eval --config src/iabi/configs/mri_unrolled.yaml \
        --checkpoint runs/mri_unrolled/checkpoint.pt

    # the generalisation sweep: one model, many acquisition settings
    python -m iabi.eval --config src/iabi/configs/mri_unrolled.yaml \
        --checkpoint runs/mri_unrolled/checkpoint.pt \
        --sweep acceleration=2,4,6,8,10,12

The operator is passed to the model at call time, so one trained network can
be scored under acquisition settings it never saw. Sweep ``acceleration`` on
the MRI track and ``angles`` on the CT track.

Results are stored per sample, not only as means, so you can report spread and
find your worst cases. A sweep writes `sweep_<key>.json` instead, next to
`results.json`, unless you pass `--out`.
"""

from __future__ import annotations

import argparse
import dataclasses
import json
import time
from pathlib import Path

import torch

from .config import Config
from .shared.data import SliceDataset, make_loader
from .shared.simulate import simulate
from .engine import (
    build_model,
    build_operator,
    get_device,
    operator_norm,
    reconstruct,
    set_seed,
)
from .shared.metrics import evaluate_batch


def _sim_kwargs(cfg: Config) -> dict:
    if cfg.track == "mri":
        return {"noise_sigma": cfg.noise_sigma}
    return {"photons": cfg.photons, "mu_scale": cfg.mu_scale}


@torch.no_grad()
def evaluate(
    cfg: Config,
    model: torch.nn.Module | None,
    device: torch.device,
    loader=None,
) -> dict:
    """Score `cfg` on the test split. Returns a serialisable result dict."""
    if loader is None:
        ds = SliceDataset(cfg.track, "test", limit=cfg.test_limit)
        loader = make_loader(ds, cfg.batch_size, shuffle=False, num_workers=cfg.num_workers)

    if model is not None:
        model.eval()
    generator = torch.Generator().manual_seed(cfg.seed)

    per_sample: dict[str, list[float]] = {}
    start = time.time()
    for x in loader:
        x = x.to(device, non_blocking=True)
        op = build_operator(cfg, x.shape[-1], x.shape[0], device, generator)
        norm = operator_norm(op, x.shape, device)
        y = simulate(x, op, generator=generator, **_sim_kwargs(cfg))
        pred = reconstruct(cfg, model, y, op, norm).clamp(0, 1)
        for k, v in evaluate_batch(pred, x).items():
            per_sample.setdefault(k, []).extend(v.detach().cpu().tolist())
    elapsed = time.time() - start

    n = len(next(iter(per_sample.values()))) if per_sample else 0
    summary = {
        k: {
            "mean": float(torch.tensor(v).mean()),
            "std": float(torch.tensor(v).std()) if len(v) > 1 else 0.0,
        }
        for k, v in per_sample.items()
    }
    return {
        "name": cfg.name,
        "track": cfg.track,
        "method": cfg.method,
        "n_test": n,
        "seed": cfg.seed,
        "eval_seconds": round(elapsed, 2),
        "acquisition": (
            {"acceleration": cfg.acceleration, "mask_mode": cfg.mask_mode,
             "center_fraction": cfg.center_fraction, "noise_sigma": cfg.noise_sigma}
            if cfg.track == "mri"
            else {"n_angles": cfg.n_angles, "photons": cfg.photons,
                  "mu_scale": cfg.mu_scale}
        ),
        "metrics": summary,
        "per_sample": per_sample,
    }


def load_checkpoint(
    cfg: Config, path: Path, device: torch.device
) -> torch.nn.Module | None:
    """Load a trained model, warning if its config disagrees with `cfg`.

    A mismatch is not always a mistake. Evaluating a model under acquisition
    settings it was not trained on is the entire point of the sweep. But a
    mismatch in *architecture* means you are about to load weights into the
    wrong shape, so those raise.
    """
    ckpt = torch.load(path, map_location=device, weights_only=False)
    trained = ckpt.get("config", {})
    for key in ("method", "track", "n_cascades", "base_channels", "n_levels",
                "shared_weights", "unet_base_channels", "unet_levels"):
        if key in trained and getattr(cfg, key) != trained[key]:
            raise ValueError(
                f"architecture mismatch on {key!r}: config says "
                f"{getattr(cfg, key)!r}, checkpoint was trained with "
                f"{trained[key]!r}. Evaluate with the config the model was "
                f"trained under (runs/<name>/config.yaml), overriding only the "
                f"acquisition settings you mean to sweep."
            )
    model = build_model(cfg)
    if model is not None:
        model.load_state_dict(ckpt["model"])
        model = model.to(device)
    return model


def main() -> None:
    p = argparse.ArgumentParser(description="Evaluate a reconstruction method.")
    p.add_argument("--config", required=True, type=Path)
    p.add_argument("--checkpoint", type=Path, default=None)
    p.add_argument("--out", type=Path, default=None, help="where to write results.json")
    p.add_argument(
        "--sweep",
        type=str,
        default=None,
        help="generalisation sweep, e.g. 'acceleration=4,6,8' or 'angles=30,60,180'",
    )
    p.add_argument("--test-limit", dest="test_limit", type=int, default=None)
    p.add_argument("--seed", type=int, default=None)
    args = p.parse_args()

    cfg = Config.from_yaml(args.config, seed=args.seed, test_limit=args.test_limit)
    set_seed(cfg.seed)
    device = get_device()

    model = None
    if args.checkpoint is not None:
        model = load_checkpoint(cfg, args.checkpoint, device)
    elif cfg.is_trainable:
        raise SystemExit(
            f"method {cfg.method!r} needs --checkpoint; train it first with "
            f"`python -m iabi.train --config {args.config}`"
        )

    results: list[dict] = []
    if args.sweep:
        key, _, values = args.sweep.partition("=")
        key = key.strip()
        if key not in {"acceleration", "angles"}:
            raise SystemExit("--sweep key must be 'acceleration' or 'angles'")
        field = "acceleration" if key == "acceleration" else "n_angles"
        cast = float if key == "acceleration" else int
        for raw in values.split(","):
            value = cast(raw.strip())
            swept = dataclasses.replace(
                cfg, **{field: value}, name=f"{cfg.name}@{key}={value}"
            )
            res = evaluate(swept, model, device)
            res["sweep"] = {"key": key, "value": value}
            print(
                f"[eval] {key}={value}: PSNR {res['metrics']['psnr']['mean']:.2f} dB  "
                f"SSIM {res['metrics']['ssim']['mean']:.4f}"
            )
            results.append(res)
    else:
        res = evaluate(cfg, model, device)
        m = res["metrics"]
        print(
            f"[eval] {cfg.name}: PSNR {m['psnr']['mean']:.2f} +/- {m['psnr']['std']:.2f} dB  "
            f"SSIM {m['ssim']['mean']:.4f}  NMSE {m['nmse']['mean']:.4f}  "
            f"edge {m['edge']['mean']:.4f}"
        )
        results.append(res)

    default = f"sweep_{key}.json" if args.sweep else "results.json"
    out = args.out or Path(cfg.out_dir) / cfg.name / default
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(results if args.sweep else results[0], indent=2))
    print(f"[eval] wrote {out}")


if __name__ == "__main__":
    main()

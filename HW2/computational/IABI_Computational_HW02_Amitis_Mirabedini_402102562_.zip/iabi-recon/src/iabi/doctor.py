"""Progress report: which TODOs are done, which are next, what is blocked.

Provided and working; no TODOs in this file.

    python -m iabi.doctor

There are twenty things to implement, which is a lot to hold in your head at
once. This prints them as a checklist, grouped into the six stages, and tells
you which one to do next. Each stage lives in exactly one folder, and the
report names it. It runs on CPU in a few seconds. The stage 6 probes load two
slices, so the first run may pull the data pack; everything after that is
cached.

Each entry is probed by actually calling the function on a tiny input. That
means the report distinguishes three states rather than two:

    [ ]  not started -- still raises NotImplementedError
    [x]  done        -- runs and returns something of the right shape
    [!]  broken      -- runs but raises a different error, which is shown

and separately marks entries that cannot be attempted yet because something
earlier in the chain is unfinished. `doctor` deliberately checks only that your
code *runs*. Whether it is correct is what `pytest` is for, and passing this
while failing the tests is the expected order of events.
"""

from __future__ import annotations

import argparse
import traceback

import torch

N = 16

#: (number, title, the folder it lives in, the gate that proves it)
STAGES = [
    ("1", "MRI: acquisition and operator", "iabi/mri/", "tests/mri tests/test_adjoint.py"),
    ("2", "CT: acquisition and operator", "iabi/ct/", "tests/ct tests/test_adjoint.py"),
    ("3", "Classical reconstruction", "iabi/shared/classical.py", "tests/shared/test_classical.py"),
    ("4", "Learned reconstruction", "iabi/shared/models/", "tests/shared/test_models.py tests/shared/test_dc.py"),
    ("5", "Evaluation metrics", "iabi/shared/metrics.py", "tests/shared/test_metrics.py"),
    ("6", "Data and training", "iabi/shared/", "tests/shared/test_training.py"),
]


# ----------------------------------------------------------------------
# Probes. Each calls one TODO on the smallest input that exercises it, and is
# written to depend on as few other TODOs as possible.
# ----------------------------------------------------------------------


def _image() -> torch.Tensor:
    yy, xx = torch.meshgrid(
        torch.linspace(-1, 1, N), torch.linspace(-1, 1, N), indexing="ij"
    )
    x = torch.zeros(1, 1, N, N)
    x[0, 0][(xx**2 + yy**2) < 0.6**2] = 1.0
    return x


def _mask() -> torch.Tensor:
    m = torch.zeros(1, 1, 1, N)
    m[..., ::2] = 1.0
    return m


def _sinogram(n_angles: int = 8) -> torch.Tensor:
    return torch.rand(1, 1, n_angles, N)


def _p_mask():
    from .mri import cartesian_mask

    return cartesian_mask(N, 4.0, generator=torch.Generator().manual_seed(0))


def _p_mri_forward():
    from .mri import MaskedFFT

    return MaskedFFT(_mask()).A(_image())


def _p_mri_adjoint():
    from .mri import MaskedFFT

    y = torch.randn(1, 1, N, N, dtype=torch.complex64)
    return MaskedFFT(_mask()).A_adjoint(y)


def _ct_op(n_angles: int = 8):
    from .ct import ParallelBeamRadon, equispaced_angles

    return ParallelBeamRadon(equispaced_angles(n_angles), N, angle_chunk=8)


def _p_ct_forward():
    return _ct_op().A(_image())


def _p_ct_adjoint():
    return _ct_op().A_adjoint(_sinogram())


def _p_simulate_ct():
    from .ct.simulate import simulate_ct

    return simulate_ct(_image(), _ct_op(), photons=4096.0)


def _p_ramp_filter():
    from .ct.filters import ramp_filter

    return ramp_filter(_sinogram(), 2.0 / N)


def _p_total_variation():
    from .shared.classical import total_variation

    return total_variation(_image())


def _p_tv_grad():
    from .shared.classical import tv_grad

    return tv_grad(_image(), 1e-2)


def _p_tv_reconstruct():
    from .shared.classical import tv_reconstruct
    from .mri import MaskedFFT

    op = MaskedFFT(_mask())
    return tv_reconstruct(
        op, _kspace(), lam=0.01, n_iter=2, eps=1e-2, op_norm=1.0, x_init=_image()
    )


def _p_unet():
    from .shared.models import UNet

    return UNet(base_channels=4, n_levels=2)(_image())


def _unrolled():
    from .shared.models import UnrolledNet

    return UnrolledNet(n_cascades=2, base_channels=4, n_levels=2)


def _kspace() -> torch.Tensor:
    """A plausible measurement, built without calling anyone's `A`.

    Probes construct their inputs directly wherever they can, so that a TODO is
    reported as blocked only when it is genuinely blocked, not merely because
    building its test input happened to need an earlier one.
    """
    return torch.randn(1, 1, N, N, dtype=torch.complex64) * _mask()


def _p_data_consistency():
    from .mri import MaskedFFT

    op = MaskedFFT(_mask())
    return _unrolled().data_consistency(
        _image(), _kspace(), op, torch.tensor(1.0), 1.0
    )


def _p_cascade():
    from .mri import MaskedFFT

    op = MaskedFFT(_mask())
    return _unrolled()(_kspace(), op, x_init=_image(), op_norm=1.0)


def _p_psnr():
    from .shared.metrics import nmse, psnr

    x = _image()
    return psnr(x + 0.1, x), nmse(x + 0.1, x)


def _p_ssim():
    from .shared.metrics import ssim

    x = _image()
    return ssim(x + 0.1, x)


def _p_edge():
    from .shared.metrics import edge_preservation

    x = _image()
    return edge_preservation(x + 0.1, x)


def _cfg(**kw):
    from .config import Config

    base = dict(
        name="doctor", track="mri", method="unrolled", acceleration=4.0,
        n_cascades=1, base_channels=4, n_levels=2, batch_size=2, epochs=1,
    )
    base.update(kw)
    return Config(**base)


def _p_dataset():
    from .shared.data import SliceDataset

    return SliceDataset("mri", "val", limit=2)[0]


def _p_loader():
    from .shared.data import SliceDataset, make_loader

    ds = SliceDataset("mri", "val", limit=2)
    return next(iter(make_loader(ds, batch_size=2, num_workers=0)))


def _p_train_epoch():
    import torch.nn as nn

    from .shared.data import SliceDataset, make_loader
    from .engine import build_model
    from .shared.training import train_one_epoch

    cfg = _cfg()
    model = build_model(cfg)
    loader = make_loader(SliceDataset("mri", "train", limit=2), 2, num_workers=0)
    return train_one_epoch(
        cfg, model, loader, torch.optim.Adam(model.parameters()), nn.L1Loss(),
        torch.device("cpu"), torch.Generator().manual_seed(0),
    )


def _p_validate():
    from .shared.data import SliceDataset, make_loader
    from .engine import build_model
    from .shared.training import validate

    cfg = _cfg()
    loader = make_loader(SliceDataset("mri", "val", limit=2), 2, num_workers=0)
    return validate(cfg, build_model(cfg), loader, torch.device("cpu"),
                    torch.Generator().manual_seed(0))


#: (stage, number, display name, file, one-line description, probe,
#:  names of the frames that count as "this TODO raised it")
TODOS = [
    ("1", 1, "cartesian_mask", "mri/masks.py", "k-space undersampling mask", _p_mask, ("cartesian_mask",)),
    ("1", 2, "MaskedFFT.A", "mri/operator.py", "masked FFT: image -> k-space", _p_mri_forward, ("A",)),
    ("1", 3, "MaskedFFT.A_adjoint", "mri/operator.py", "the adjoint: zero-filled recon", _p_mri_adjoint, ("A_adjoint",)),
    ("2", 4, "ParallelBeamRadon.A", "ct/operator.py", "forward projection -> sinogram", _p_ct_forward, ("A",)),
    ("2", 5, "ParallelBeamRadon.A_adjoint", "ct/operator.py", "backprojection (not the inverse)", _p_ct_adjoint, ("A_adjoint",)),
    ("2", 6, "simulate_ct", "ct/simulate.py", "Beer-Lambert + Poisson + log", _p_simulate_ct, ("simulate_ct",)),
    ("2", 7, "ramp_filter", "ct/filters.py", "the filter in filtered backprojection", _p_ramp_filter, ("ramp_filter",)),
    ("3", 8, "total_variation", "shared/classical.py", "the TV functional", _p_total_variation, ("total_variation",)),
    ("3", 9, "tv_grad", "shared/classical.py", "its gradient (an adjoint again)", _p_tv_grad, ("tv_grad",)),
    ("3", 10, "tv_reconstruct", "shared/classical.py", "FISTA: CS for MRI, TV for CT", _p_tv_reconstruct, ("tv_reconstruct",)),
    ("4", 11, "UNet.forward", "shared/models/unet.py", "encoder, skips, decoder", _p_unet, ("forward",)),
    ("4", 12, "UnrolledNet.data_consistency", "shared/models/unrolled.py", "one gradient step on the data term", _p_data_consistency, ("data_consistency",)),
    ("4", 13, "UnrolledNet.forward", "shared/models/unrolled.py", "the unrolled cascade", _p_cascade, ("forward",)),
    ("5", 14, "psnr / nmse", "shared/metrics.py", "the two scalar error metrics", _p_psnr, ("psnr", "nmse")),
    ("5", 15, "ssim", "shared/metrics.py", "local structural similarity", _p_ssim, ("ssim",)),
    ("5", 16, "edge_preservation", "shared/metrics.py", "catches 'looks cleaner, is blurrier'", _p_edge, ("edge_preservation",)),
    ("6", 17, "SliceDataset.__getitem__", "shared/data/datasets.py", "one slice, augmented", _p_dataset, ("__getitem__",)),
    ("6", 18, "make_loader", "shared/data/datasets.py", "batching, shuffling, workers", _p_loader, ("make_loader",)),
    ("6", 19, "train_one_epoch", "shared/training.py", "forward, loss, backward, step", _p_train_epoch, ("train_one_epoch",)),
    ("6", 20, "validate", "shared/training.py", "scoring without gradients", _p_validate, ("validate",)),
]


def _probe(path: str, funcs: tuple[str, ...], fn) -> tuple[str, str]:
    """Return (state, detail): 'done', 'todo', 'blocked' or 'error'.

    Telling "not started" apart from "blocked behind an earlier TODO" is the
    point of this function, and it is why the probes raise rather than return a
    flag: the innermost frame of the NotImplementedError says which TODO
    actually stopped us. Matching on the file as well as the function name
    matters because two different TODOs are both called `forward`.
    """
    basename = path.rsplit("/", 1)[-1]
    try:
        fn()
        return "done", ""
    except NotImplementedError as exc:
        frames = traceback.extract_tb(exc.__traceback__)
        if not frames:
            return "todo", ""
        innermost = frames[-1]
        if innermost.name in funcs and innermost.filename.endswith(basename):
            return "todo", ""
        return "blocked", innermost.name
    except Exception as exc:  # noqa: BLE001 - reporting the error is the point
        return "error", f"{type(exc).__name__}: {exc}"


def report(verbose: bool = False) -> int:
    """Print the checklist. Returns the number of TODOs still outstanding."""
    results = [(t, _probe(t[3], t[6], t[5])) for t in TODOS]
    done = sum(1 for _, (state, _) in results if state == "done")

    print()
    print(f"  IABI reconstruction scaffold -- {done}/{len(TODOS)} implemented")
    print()

    glyph = {"done": "[x]", "todo": "[ ]", "blocked": "[-]", "error": "[!]"}
    for stage, title, folder, gate in STAGES:
        rows = [(t, r) for t, r in results if t[0] == stage]
        n_done = sum(1 for _, (state, _) in rows if state == "done")
        print(f"  Stage {stage} -- {title}  ({n_done}/{len(rows)})")
        print(f"       {folder}")
        for (_, num, name, path, desc, _fn, _fr), (state, detail) in rows:
            line = f"    {glyph[state]} {num:>2}. {name:<34} {desc}"
            print(line)
            if state == "error":
                print(f"           ^ runs, but raises {detail}")
            elif state == "blocked" and verbose:
                print(f"           ^ waiting on {detail}()")
            if verbose and state != "done":
                print(f"           {path}")
        print(f"       gate: pytest {gate.split(',')[0].strip()}")
        print()

    outstanding = [t for t, (state, _) in results if state in ("todo", "blocked")]
    broken = [(t, d) for t, (state, d) in results if state == "error"]

    if broken:
        print("  Implemented but raising:")
        for (_, num, name, path, _d, _f, _fr), detail in broken:
            print(f"    {num:>2}. {name} ({path}) -- {detail}")
        print()

    if outstanding:
        nxt = min(outstanding, key=lambda t: t[1])
        print(f"  Next: {nxt[1]}. {nxt[2]} in src/iabi/{nxt[3]}")
        print(f"        {nxt[4]}")
    else:
        print("  All twenty are implemented. Now make them correct:")
        print("        pytest tests/ -q")
    print()
    return len(outstanding)


def main() -> None:
    p = argparse.ArgumentParser(description="Report which TODOs are done.")
    p.add_argument("-v", "--verbose", action="store_true", help="show file paths and blockers")
    args = p.parse_args()
    report(verbose=args.verbose)


if __name__ == "__main__":
    main()

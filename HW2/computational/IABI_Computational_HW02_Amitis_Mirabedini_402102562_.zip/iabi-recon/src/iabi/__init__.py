"""IABI course scaffold: unrolled reconstruction for low-dose CT and accelerated MRI."""

__version__ = "0.1.0"

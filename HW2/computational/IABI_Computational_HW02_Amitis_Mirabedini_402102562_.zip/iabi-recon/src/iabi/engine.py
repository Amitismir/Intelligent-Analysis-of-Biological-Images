"""Shared runtime: seeding, device, operator construction, method dispatch.

Provided and working; no TODOs. `train.py` and `eval.py` both build their
operators and run their reconstructions through here, so that a method behaves
identically whether it is being trained or scored.
"""

from __future__ import annotations

import random

import numpy as np
import torch
from torch import Generator, Tensor

from .config import Config
from .ct import ParallelBeamRadon, equispaced_angles
from .mri import MaskedFFT, cartesian_mask
from .shared.classical import tv_reconstruct
from .shared.models import UNet, UnrolledNet
from .shared.operator import Operator, estimate_operator_norm

__all__ = [
    "set_seed",
    "get_device",
    "build_operator",
    "build_model",
    "operator_norm",
    "reconstruct",
]

_NORM_CACHE: dict[tuple, float] = {}


def set_seed(seed: int) -> None:
    """Seed every RNG we touch.

    Seeding is not enough on a GPU: some cuDNN kernels are nondeterministic, so
    two seeded runs can differ in the last decimal place. A large difference
    means something unseeded (a fresh mask, a shuffled split) leaked in.
    """
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)


def get_device() -> torch.device:
    """CUDA if present, else CPU. Prints what it picked, since a silent CPU
    fallback turns a quick run into an hour."""
    if torch.cuda.is_available():
        dev = torch.device("cuda")
        print(f"[engine] device: {torch.cuda.get_device_name(0)}")
    else:
        dev = torch.device("cpu")
        print("[engine] device: CPU  (no GPU found, training will be very slow)")
    return dev


def build_operator(
    cfg: Config,
    resolution: int,
    batch: int,
    device: torch.device,
    generator: Generator | None = None,
) -> Operator:
    """Construct the forward operator for one batch.

    Rebuilt per batch rather than once per run, because for MRI a fresh
    undersampling mask every step is a strong free augmentation. Cheap: both
    operators are a handful of tensors.
    """
    # The mask is drawn on CPU and the result is moved to the device. A CUDA
    # generator would be needed to sample directly on the GPU, and keeping the
    # randomness on CPU makes a run reproducible from a single seed regardless
    # of whether it lands on a GPU or not.
    if cfg.track == "mri":
        mask = cartesian_mask(
            resolution,
            cfg.acceleration,
            cfg.center_fraction,
            cfg.mask_mode,
            batch=batch,
            generator=generator,
            device="cpu",
        )
        return MaskedFFT(mask.to(device))

    angles = equispaced_angles(cfg.n_angles, device="cpu")
    return ParallelBeamRadon(angles.to(device), resolution, angle_chunk=cfg.angle_chunk)


def operator_norm(
    op: Operator, image_shape: tuple[int, ...], device: torch.device
) -> float:
    """Cached estimate of ``||A^H A||`` for the current geometry.

    Keyed on the things that actually change the norm, so we pay for the power
    iteration once per geometry rather than once per batch. For MRI the answer
    is always 1 (the operator is an orthogonal projection); we compute it
    anyway so that a student whose adjoint is subtly mis-scaled sees the
    consequence here rather than as mysteriously bad training.
    """
    if isinstance(op, ParallelBeamRadon):
        key = ("ct", op.n_angles, op.n_pixels)
    else:
        key = ("mri", int(image_shape[-2]), int(image_shape[-1]))
    if key not in _NORM_CACHE:
        _NORM_CACHE[key] = estimate_operator_norm(
            op, (1, 1, int(image_shape[-2]), int(image_shape[-1])), device=device
        )
        print(f"[engine] ||A^H A|| for {key} = {_NORM_CACHE[key]:.4g}")
    return _NORM_CACHE[key]


def build_model(cfg: Config) -> torch.nn.Module | None:
    """Instantiate the trainable model, or None for the classical methods."""
    if cfg.method == "unet":
        return UNet(
            base_channels=cfg.unet_base_channels,
            n_levels=cfg.unet_levels,
            residual=True,
        )
    if cfg.method == "unrolled":
        return UnrolledNet(
            n_cascades=cfg.n_cascades,
            base_channels=cfg.base_channels,
            n_levels=cfg.n_levels,
            shared_weights=cfg.shared_weights,
            learn_step_size=cfg.learn_step_size,
            init_step_size=cfg.init_step_size,
        )
    return None


def reconstruct(
    cfg: Config,
    model: torch.nn.Module | None,
    y: Tensor,
    op: Operator,
    op_norm: float,
) -> Tensor:
    """Run one reconstruction, dispatching on `cfg.method`.

    The four rungs of the ladder, in increasing order of how much they know:

    - ``zerofilled`` / ``fbp``: analytic inversion, no prior, no training
    - ``tv``: hand-designed prior, iterative, no training
    - ``unet``: learned prior, but sees the measurements exactly once (its
      input is the zero-filled image on MRI and the FBP image on CT)
    - ``unrolled``: learned prior *and* the operator in the loop
    """
    if cfg.method == "zerofilled":
        return op.A_adjoint(y)
    if cfg.method == "fbp":
        return op.fbp(y, window=cfg.fbp_window)  # type: ignore[attr-defined]
    if cfg.method == "tv":
        return tv_reconstruct(
            op,
            y,
            lam=cfg.tv_lambda,
            n_iter=cfg.tv_iters,
            eps=cfg.tv_eps,
            op_norm=op_norm,
        )
    if cfg.method == "unet":
        assert model is not None
        init = op.fbp(y) if cfg.track == "ct" else op.A_adjoint(y)  # type: ignore[attr-defined]
        return model(init)
    if cfg.method == "unrolled":
        assert model is not None
        init = op.fbp(y) if cfg.track == "ct" else op.A_adjoint(y)  # type: ignore[attr-defined]
        return model(y, op, x_init=init, op_norm=op_norm)
    raise ValueError(f"unknown method {cfg.method!r}")

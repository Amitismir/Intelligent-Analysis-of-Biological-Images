"""Training entry point.

The loop body and the validation pass are yours to write; the plumbing around
them (config, scheduler, checkpointing, history) is given.

Usage::

    python -m iabi.train --config src/iabi/configs/mri_unrolled.yaml
    python -m iabi.train --config src/iabi/configs/mri_unrolled.yaml --smoke
    python -m iabi.train --config src/iabi/configs/ct_unrolled.yaml --epochs 10

Always do the `--smoke` run first. It trains on 32 slices for one epoch, takes
about two minutes, and exercises every line the real run will touch. A wrong
adjoint or a shape mismatch surfaces there instead of twenty-five minutes into
the run that was supposed to produce your results.

On precision: everything here runs in fp32. The T4 is a Turing card, so bf16 is
unavailable, and fp16 autocast interacts badly with the complex tensors in the
MRI track. At 128-160 pixels the speedup would not change what fits in the hour
anyway, and fp32 removes a whole category of confusing NaN.
"""

from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import torch
import torch.nn as nn

from .config import Config
from .shared.data import SliceDataset, make_loader
from .shared.simulate import simulate
from .shared.training import train_one_epoch, validate
from .engine import (
    build_model,
    build_operator,
    get_device,
    operator_norm,
    reconstruct,
    set_seed,
)
from .shared.metrics import evaluate_batch


def train(cfg: Config) -> Path:
    """Train one config and write checkpoint + history. Returns the run dir."""
    if not cfg.is_trainable:
        raise ValueError(
            f"method {cfg.method!r} has no parameters to train; "
            f"run it through `python -m iabi.eval` instead"
        )

    set_seed(cfg.seed)
    device = get_device()
    generator = torch.Generator().manual_seed(cfg.seed)

    train_ds = SliceDataset(cfg.track, "train", limit=cfg.train_limit, augment=True)
    val_ds = SliceDataset(cfg.track, "val", limit=cfg.val_limit)
    train_loader = make_loader(
        train_ds, cfg.batch_size, num_workers=cfg.num_workers, seed=cfg.seed
    )
    val_loader = make_loader(val_ds, cfg.batch_size, num_workers=cfg.num_workers)

    model = build_model(cfg)
    assert model is not None
    model = model.to(device)
    n_params = sum(p.numel() for p in model.parameters())
    print(f"[train] {cfg.name}: {cfg.method} on {cfg.track}, {n_params:,} parameters")
    print(f"[train] {len(train_ds)} train / {len(val_ds)} val slices")

    opt = torch.optim.Adam(model.parameters(), lr=cfg.lr, weight_decay=cfg.weight_decay)
    sched = torch.optim.lr_scheduler.CosineAnnealingLR(opt, T_max=max(cfg.epochs, 1))
    loss_fn = nn.L1Loss()

    run_dir = Path(cfg.out_dir) / cfg.name
    run_dir.mkdir(parents=True, exist_ok=True)
    cfg.save(run_dir / "config.yaml")

    history: list[dict] = []
    start = time.time()

    for epoch in range(cfg.epochs):
        epoch_loss = train_one_epoch(
            cfg, model, train_loader, opt, loss_fn, device, generator
        )
        sched.step()
        entry = {
            "epoch": epoch,
            "train_loss": epoch_loss,
            "lr": sched.get_last_lr()[0],
            "elapsed_s": round(time.time() - start, 1),
        }

        is_last = epoch == cfg.epochs - 1
        if is_last or (epoch + 1) % cfg.val_every == 0:
            # A fresh generator from a fixed seed on every call, so each
            # validation sees the same masks and noise and the curve moves only
            # when the model does. Reusing the training generator would draw new
            # ones each time and add their variance to every point.
            val_gen = torch.Generator().manual_seed(cfg.seed + 1)
            entry.update({f"val_{k}": v for k, v in
                          validate(cfg, model, val_loader, device, val_gen).items()})
            print(
                f"[train] epoch {epoch + 1}/{cfg.epochs}  "
                f"loss {entry['train_loss']:.4f}  "
                f"val PSNR {entry.get('val_psnr', float('nan')):.2f} dB  "
                f"({entry['elapsed_s']:.0f}s)"
            )
        else:
            print(
                f"[train] epoch {epoch + 1}/{cfg.epochs}  "
                f"loss {entry['train_loss']:.4f}  ({entry['elapsed_s']:.0f}s)"
            )
        history.append(entry)

    torch.save(
        {"model": model.state_dict(), "config": cfg.to_dict(), "history": history},
        run_dir / "checkpoint.pt",
    )
    (run_dir / "history.json").write_text(json.dumps(history, indent=2))
    print(f"[train] done in {time.time() - start:.0f}s -> {run_dir}")
    return run_dir


def main() -> None:
    p = argparse.ArgumentParser(description="Train a reconstruction model.")
    p.add_argument("--config", required=True, type=Path)
    p.add_argument("--smoke", action="store_true", help="two-minute validation run")
    p.add_argument("--epochs", type=int, default=None)
    p.add_argument("--seed", type=int, default=None)
    p.add_argument("--name", type=str, default=None)
    p.add_argument("--out-dir", dest="out_dir", type=str, default=None)
    args = p.parse_args()

    cfg = Config.from_yaml(
        args.config,
        epochs=args.epochs,
        seed=args.seed,
        name=args.name,
        out_dir=args.out_dir,
    )
    if args.smoke:
        cfg = cfg.smoke()
    train(cfg)


if __name__ == "__main__":
    main()

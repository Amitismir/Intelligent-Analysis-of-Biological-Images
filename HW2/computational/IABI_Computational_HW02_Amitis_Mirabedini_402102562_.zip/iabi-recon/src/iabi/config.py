"""Experiment configuration. Provided and working; no TODOs.

Every run is described by one YAML file plus a seed. Point each result in your
report at the config that regenerates it. `configs/` holds one file per rung of each baseline
ladder; copy one and edit it to define a new arm.

Anything you can change about an experiment should live here rather than in a
notebook cell, so that "what exactly did we run?" always has an answer.
"""

from __future__ import annotations

import dataclasses
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml

__all__ = ["Config"]


@dataclass
class Config:
    """A complete experiment specification."""

    # --- identity ---------------------------------------------------
    name: str = "unnamed"
    track: str = "mri"  # "mri" | "ct"
    method: str = "unrolled"  # zerofilled | fbp | tv | unet | unrolled

    # --- acquisition: MRI -------------------------------------------
    acceleration: float = 6.0
    center_fraction: float = 0.08
    mask_mode: str = "random"  # "random" | "equispaced"
    noise_sigma: float = 0.0

    # --- acquisition: CT --------------------------------------------
    n_angles: int = 60
    photons: float = 4096.0
    mu_scale: float = 3.0
    angle_chunk: int = 64

    # --- unrolled model ---------------------------------------------
    n_cascades: int = 6
    base_channels: int = 16
    n_levels: int = 2
    shared_weights: bool = False
    learn_step_size: bool = True
    init_step_size: float = 1.0

    # --- u-net baseline ---------------------------------------------
    unet_base_channels: int = 32
    unet_levels: int = 3

    # --- classical baseline -----------------------------------------
    tv_lambda: float = 0.01
    tv_iters: int = 200
    tv_eps: float = 1e-3
    fbp_window: str = "ramlak"

    # --- training ---------------------------------------------------
    epochs: int = 30
    batch_size: int = 8
    lr: float = 1e-3
    weight_decay: float = 0.0
    grad_clip: float = 1.0
    seed: int = 0
    train_limit: int | None = None
    val_limit: int | None = 64
    test_limit: int | None = None
    num_workers: int = 2
    val_every: int = 5

    # --- bookkeeping ------------------------------------------------
    out_dir: str = "runs"
    extra: dict[str, Any] = field(default_factory=dict)

    # ----------------------------------------------------------------

    def __post_init__(self) -> None:
        if self.track not in {"mri", "ct"}:
            raise ValueError(f"track must be 'mri' or 'ct', got {self.track!r}")
        valid = {"zerofilled", "fbp", "tv", "unet", "unrolled"}
        if self.method not in valid:
            raise ValueError(f"method must be one of {sorted(valid)}, got {self.method!r}")
        if self.track == "mri" and self.method == "fbp":
            raise ValueError("method 'fbp' is CT-only; use 'zerofilled' for MRI")
        if self.track == "ct" and self.method == "zerofilled":
            raise ValueError("method 'zerofilled' is MRI-only; use 'fbp' for CT")

    @property
    def is_trainable(self) -> bool:
        """Whether this method has weights to fit."""
        return self.method in {"unet", "unrolled"}

    @classmethod
    def from_yaml(cls, path: Path | str, **overrides: Any) -> "Config":
        """Load a config, applying keyword overrides on top."""
        data = yaml.safe_load(Path(path).read_text()) or {}
        data.update({k: v for k, v in overrides.items() if v is not None})
        known = {f.name for f in dataclasses.fields(cls)}
        unknown = set(data) - known
        if unknown:
            raise ValueError(f"unknown config keys: {sorted(unknown)}")
        return cls(**data)

    def smoke(self) -> "Config":
        """A two-minute version of this config, for validating a change.

        Run this *before* every real run. Catching a shape error or a wrong
        adjoint here costs two minutes; catching it twenty-five minutes into a
        training run costs you a third of your session.
        """
        return dataclasses.replace(
            self,
            name=f"{self.name}_smoke",
            epochs=1,
            train_limit=32,
            val_limit=8,
            test_limit=8,
            tv_iters=min(self.tv_iters, 20),
            num_workers=0,
        )

    def to_dict(self) -> dict[str, Any]:
        return dataclasses.asdict(self)

    def save(self, path: Path | str) -> None:
        Path(path).write_text(yaml.safe_dump(self.to_dict(), sort_keys=False))

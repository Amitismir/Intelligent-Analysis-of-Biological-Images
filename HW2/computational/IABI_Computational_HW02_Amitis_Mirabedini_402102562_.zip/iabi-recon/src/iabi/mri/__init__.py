"""The MRI track: everything specific to accelerated MRI.

TODOs 1 to 3 are here: which k-space lines you acquire (`masks.py`), and the
forward operator and its adjoint (`operator.py`). Everything after that is in
`iabi.shared`, shared with CT.

Start with `masks.py`, then `operator.py`.

Gate: pytest tests/mri tests/test_adjoint.py -k mri
"""

from .masks import cartesian_mask
from .operator import MaskedFFT, fft2c, ifft2c
from .simulate import simulate_mri

__all__ = ["MaskedFFT", "fft2c", "ifft2c", "cartesian_mask", "simulate_mri"]

"""k-space undersampling masks for the MRI track.

Undersampling is retrospective: we drop frequency lines from fully sampled
images in software, so the acceleration factor `R` can be changed freely and a
trained model can be scored at other factors.

- The centre of k-space holds most of the image energy and the contrast, so
  real protocols always acquire a fully sampled central band (the
  autocalibration signal, ACS). `center_fraction` sets its width.
- Equispaced skipping gives coherent aliasing (sharp ghosts). Random skipping
  gives incoherent, noise-like artefacts, which is what compressed sensing
  needs. Comparing the two with everything else fixed is a cheap ablation.
- Every mask is symmetric about the centre column (closed under ``k -> -k``).
  Our images are real, so their spectra are conjugate-symmetric and the line
  at ``-k`` adds no information; real scanners use this redundancy (partial
  Fourier). We keep both lines anyway, because with an unpaired line `A^H A`
  is no longer a projection. For real `x` it is ``F^H M_sym F`` with
  ``M_sym = (M + reflected M) / 2``, which has eigenvalue 1/2 on an unpaired
  line, so a unit data-consistency step would only go halfway to the data.
  `tests/shared/test_dc.py` catches this. Mention the unused redundancy next
  to the single-coil caveat in your report.

All masks have shape ``(B, 1, 1, W)``: one decision per phase-encode column,
broadcast down the rows, because Cartesian sampling skips whole lines.

Cartesian is not the only option
--------------------------------
Real scanners also use trajectories off the grid: radial spokes, spirals, and
variable-density versions of both. Their undersampling artefacts are more
incoherent than a Cartesian mask's, which suits compressed sensing, and radial
sampling is robust to motion.

We don't implement them. Off-grid samples turn `A` from ``mask * FFT`` into a
non-uniform FFT, with interpolation kernels and density compensation, and its
adjoint is much harder than the one derived in `mri/operator.py`. The common
patterns are Cartesian equispaced, Cartesian random, radial and spiral, and
this file covers the first two.
"""

from __future__ import annotations

import torch
from torch import Generator, Tensor

__all__ = ["cartesian_mask"]


def cartesian_mask(
    width: int,
    acceleration: float,
    center_fraction: float = 0.08,
    mode: str = "random",
    batch: int = 1,
    generator: Generator | None = None,
    device: torch.device | str = "cpu",
) -> Tensor:
    """Build a Cartesian undersampling mask.

    Parameters
    ----------
    acceleration:
        Target factor `R`. The mask keeps roughly ``width / R`` columns in
        total, ACS included.
    center_fraction:
        Fraction of columns fully sampled at the centre of k-space.
    mode:
        ``"random"`` draws the outer columns i.i.d. (incoherent artefacts,
        friendly to compressed sensing); ``"equispaced"`` takes every n-th
        column from a random offset (coherent ghosts, closer to a stock
        product sequence).
    batch:
        Number of independent masks. Drawing a fresh mask per training sample
        is a strong augmentation: the network sees many sampling patterns
        rather than memorising one.

    Returns
    -------
    Real float32 tensor of shape ``(batch, 1, 1, width)`` with values in {0, 1}.
    """
    if acceleration < 1:
        raise ValueError(f"acceleration must be >= 1, got {acceleration}")
    if width % 2:
        # The pairing below, column i with (width - i) % width, is the k -> -k
        # reflection only when the centred FFT puts k = 0 at width // 2, which
        # holds for even widths. Both packs are even.
        raise ValueError(f"width must be even, got {width}")
    if mode not in ("random", "equispaced"):
        raise ValueError(f"unknown mode {mode!r}; use 'random' or 'equispaced'")

    # ------------------------------------------------------------------
    # ------------------------------------------------------------------
    # TODO(students) [1/20]: build the undersampling mask.
    #
    #   n_center = round(width * center_fraction)   fully-sampled ACS band,
    #              centred; it starts at (width - n_center) // 2, not at 0
    #   n_target = round(width / acceleration)      total columns to keep
    #
    # The mask must be symmetric under k -> -k, i.e. column i and column
    # (width - i) % width are acquired together. See the third bullet in this
    # module's docstring for why: get it wrong and `A` stops being a
    # projection, which tests/shared/test_dc.py will catch.
    #
    # Spend the remaining n_target - n_center columns on the outer region, in
    # symmetric pairs. "random": one decision per pair, kept with probability
    # n_outer / n_available. Give both columns of a pair the same draw
    # rather than symmetrising afterwards, which would double the count.
    # "equispaced": select on |i - width // 2|, which is already symmetric,
    # with stride = round(n_available / n_outer) from a random offset. Return
    # (batch, 1, 1, width) float32.
    #
    # The ACS band counts toward the budget, and must itself be symmetric,
    # so close it under the reflection before you count it. Give the outer
    # region the full width/R on top of the band and every mask is denser than
    # the R you report, which flatters every number in your table and is hard
    # to spot later.
    #
    # Draw each mask in the batch independently: free augmentation.
    #
    # Gate: pytest tests/mri/test_masks.py
    # ------------------------------------------------------------------
    n_center = max(0, min(width, round(width * center_fraction)))
    n_target = round(width / acceleration)
    columns = torch.arange(width)
    reflected = (-columns) % width
    band = torch.zeros(width, dtype=torch.bool)
    lo = (width - n_center) // 2
    band[lo : lo + n_center] = True
    band = band | band[reflected]
    available = ~band
    n_available = int(available.sum())
    n_outer = max(0, min(n_available, n_target - int(band.sum())))
    mask = band.expand(batch, width).clone()
    if n_outer > 0:
        if mode == "random":
            # One independent draw per conjugate pair, including the
            # self-paired Nyquist column when it lies outside the ACS band.
            representatives = columns[available & (columns <= reflected)]
            draws = torch.rand(batch, len(representatives), generator=generator)
            keep = draws < n_outer / n_available
            mask[:, representatives] = keep
            mask[:, reflected[representatives]] = keep
        else:
            stride = max(1, round(n_available / n_outer))
            offsets = torch.randint(stride, (batch, 1), generator=generator)
            distance = (columns - width // 2).abs()
            mask |= available & ((distance.unsqueeze(0) - offsets) % stride == 0)
    return mask.reshape(batch, 1, 1, width).to(device=device, dtype=torch.float32)

"""MRI measurement simulation: additive complex Gaussian noise in k-space.

Given and working. Read it before writing the CT simulator in
`iabi/ct/simulate.py`: it shows the conventions that one follows (where the
generator comes from, what is returned, how the operator is applied).

MRI's dominant noise is thermal. It enters in k-space and is additive complex
Gaussian with roughly constant variance across frequencies, so Gaussian noise
is the right model here. In CT it would be wrong.
"""

from __future__ import annotations

import torch
from torch import Generator, Tensor

from .operator import MaskedFFT

__all__ = ["simulate_mri"]


def simulate_mri(
    x: Tensor,
    op: MaskedFFT,
    noise_sigma: float = 0.0,
    generator: Generator | None = None,
) -> Tensor:
    """Simulate undersampled k-space with additive complex Gaussian noise.

    Parameters
    ----------
    noise_sigma:
        Standard deviation of the complex noise, in units of the normalised
        image intensity. With the orthonormal FFT and images scaled to [0, 1],
        ``0.0`` gives the noiseless case usually used in accelerated-MRI
        benchmarks, and values around ``0.01`` give a visibly noisy but
        realistic scan. Noise is added *before* masking, so unacquired lines
        stay exactly zero: a line you did not measure carries no noise.
    """
    y = op.A(x)
    if noise_sigma > 0:
        # Drawn on CPU and moved: a CPU `Generator` cannot seed sampling into a
        # CUDA tensor, and keeping the randomness on CPU makes a run
        # reproducible from one seed whether or not it lands on a GPU.
        real = torch.randn(y.shape, generator=generator).to(y.device)
        imag = torch.randn(y.shape, generator=generator).to(y.device)
        # sqrt(1/2) per component so the total complex noise power is sigma^2.
        noise = (real + 1j * imag) * (noise_sigma / (2**0.5))
        y = op.mask * (y + noise)
    return y

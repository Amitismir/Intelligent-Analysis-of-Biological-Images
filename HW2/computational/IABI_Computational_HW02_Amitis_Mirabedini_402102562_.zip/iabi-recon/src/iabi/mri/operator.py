"""MRI forward operator: undersampled Cartesian k-space.

Where the signal comes from
---------------------------
Protons in a strong static field `B0` precess about it at the Larmor
frequency. A radio-frequency pulse tips their magnetisation into the
transverse plane, where it induces a voltage in a receiver coil; that voltage
is the signal. It decays as the spins return to equilibrium (`T1`) and dephase
(`T2`), and the readout time sets the contrast. IXI's T2-weighted scans wait
long enough for T2 differences to dominate.

A linear gradient field makes the precession frequency depend on position, so
after a gradient of area `k` the spin at position `r` carries a phase
``exp(-2*pi*i*k.r)``. The coil sums over the slice and records

    s(k) = integral over r of  x(r) * exp(-2*pi*i*k.r)

which is the Fourier coefficient of the object at frequency `k`. Driving the
gradients traces a path through k-space, and the image comes from
inverse-transforming the recorded coefficients. The measurement itself is a
Fourier transform, which makes undersampled MRI a linear inverse problem with
a simple forward operator.

Single coil and parallel imaging
--------------------------------
We start from magnitude images, so our object is real where a real one is
complex, and we simulate one coil where real scanners use many. The second is
the largest gap between this code and clinical practice.

Each receiver coil sees the object through its own spatial sensitivity
profile, roughly most sensitive to the anatomy nearest it. These profiles add
spatial encoding at no scan-time cost, and using them is parallel imaging.
SENSE unfolds the aliased images in image space using estimated sensitivity
maps; GRAPPA fills in the missing k-space lines with a kernel calibrated on
the fully sampled ACS band. They are why 2 to 4x acceleration is routine on
real scanners, and E2E-VarNet learns the sensitivity estimation inside the
network. With one coil, all of our acceleration has to come from the prior,
so it is harder than on a real scanner. (`sigpy.mri.birdcage_maps` makes
synthetic sensitivity maps if you want to try multi-coil, but that is well
beyond this assignment.)

The forward operator
--------------------
Each phase-encode line costs scan time, so a faster scan acquires fewer lines.
Below the Nyquist rate the naive reconstruction aliases: parts of the anatomy
fold onto each other. The acceleration factor `R` is the number of lines in a
full scan divided by the number acquired. The operator is::

    A(x) = mask * F(x)

where `F` is the centred, orthonormal 2D FFT and `mask` selects the acquired
phase-encode lines.

Deriving the adjoint
--------------------
`A` maps a *real* image to *complex* k-space, so the adjoint must map complex
k-space back to a real image. Using the real inner product
``<u, v>_R = Re(sum conj(u) v)`` on the measurement side::

    <A x, y>  = Re< mask * F x , y >
              = Re< F x , mask * y >        (mask is real, so it is self-adjoint)
              = Re< x , F^H (mask * y) >    (F is unitary, so F^H is its adjoint)
              = < x , Re( F^H (mask * y) ) >  (x is real)

Hence::

    A_adjoint(y) = real( F^H (mask * y) )

The real part is there because the domain of `A` is the real vector space of
images; without it the result is not the adjoint.

`A_adjoint(y)` is the zero-filled reconstruction: the aliased image used as
the first rung of the MRI ladder and as the starting point of the unrolled
network.
"""

from __future__ import annotations

import torch
from torch import Tensor

from ..shared.operator import Operator

__all__ = ["fft2c", "ifft2c", "MaskedFFT"]


# ----------------------------------------------------------------------
# Provided: centred orthonormal FFT helpers.
#
# These handle the `fftshift` bookkeeping that puts the zero frequency in the
# middle of the array, where every MRI paper draws it. They are unitary and
# exact inverses of each other. You do not need to modify them, and please
# do not, because debugging shift conventions is not what this exercise is
# testing and it will eat your GPU hour.
# ----------------------------------------------------------------------
def fft2c(x: Tensor) -> Tensor:
    """Centred orthonormal 2D FFT. Complex in, complex out."""
    x = torch.fft.ifftshift(x, dim=(-2, -1))
    x = torch.fft.fft2(x, norm="ortho")
    return torch.fft.fftshift(x, dim=(-2, -1))


def ifft2c(y: Tensor) -> Tensor:
    """Centred orthonormal 2D inverse FFT. Complex in, complex out."""
    y = torch.fft.ifftshift(y, dim=(-2, -1))
    y = torch.fft.ifft2(y, norm="ortho")
    return torch.fft.fftshift(y, dim=(-2, -1))


class MaskedFFT(Operator):
    """Single-coil Cartesian undersampled MRI.

    Parameters
    ----------
    mask:
        Real 0/1 tensor broadcastable to the k-space shape. Masks produced by
        `operators.masks` have shape ``(B, 1, 1, W)``: one decision per
        phase-encode column, shared down every row, which is how Cartesian
        undersampling actually works on a scanner.

    Shapes
    ------
    ``x : (B, 1, H, W) float32``  ->  ``y : (B, 1, H, W) complex64``

    Note that `y` is the same size as `x`; undersampling shows up as *zeros* in
    the unacquired positions rather than a smaller array. That keeps the shapes
    uniform and lets you change acceleration without touching the network.
    """

    name = "mri"

    def __init__(self, mask: Tensor):
        if mask.is_complex():
            raise ValueError("mask must be real-valued (0/1), got a complex tensor")
        self.mask = mask

    def to(self, device: torch.device | str) -> "MaskedFFT":
        """Return an operator with its mask on `device`."""
        return MaskedFFT(self.mask.to(device))

    @property
    def acceleration(self) -> float:
        """Effective acceleration factor R = (all lines) / (acquired lines)."""
        return float(self.mask.numel() / self.mask.sum().clamp(min=1).item())

    def A(self, x: Tensor) -> Tensor:
        """Image -> masked k-space."""
        # ------------------------------------------------------------------
        # ------------------------------------------------------------------
        # TODO(students) [2/20]: the MRI forward operator.
        #
        #   1. `x` arrives real, so cast it to complex before the FFT.
        #   2. Transform with the provided `fft2c`.
        #   3. Zero the lines you did not acquire, using `self.mask`.
        #
        # One line, once you see it.
        #
        # Gate: pytest tests/test_adjoint.py tests/mri/test_shapes.py
        # ------------------------------------------------------------------
        return self.mask * fft2c(x.to(torch.complex64))

    def A_adjoint(self, y: Tensor) -> Tensor:
        """Masked k-space -> image (the zero-filled reconstruction)."""
        # ------------------------------------------------------------------
        # ------------------------------------------------------------------
        # TODO(students) [3/20]: the MRI adjoint.
        #
        # Follow the derivation in this module's docstring:
        #     A_adjoint(y) = real( F^H ( mask * y ) )
        #
        # Applying the mask again is not redundant: the adjoint of "multiply by
        # the mask" is "multiply by the mask". Return real float32, not complex.
        #
        # Gate: pytest tests/test_adjoint.py
        # ------------------------------------------------------------------
        return ifft2c(self.mask * y).real

    def measurement_shape(self, image_shape: tuple[int, ...]) -> tuple[int, ...]:
        return image_shape

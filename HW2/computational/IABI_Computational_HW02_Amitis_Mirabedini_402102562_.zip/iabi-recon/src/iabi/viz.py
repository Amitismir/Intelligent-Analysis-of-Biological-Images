"""Figures. Provided and working; no TODOs.

A PSNR column can't show that a method smoothed away a small structure; an
error map can. Use `comparison_grid` for your main qualitative figure and
`worst_cases` for the failure analysis.

All panels in a comparison share one intensity scale. With matplotlib's
per-panel autoscaling a dim reconstruction looks the same as a correct one.
Every function here sets `vmin`/`vmax` from the reference image.
"""

from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import torch
from torch import Tensor

__all__ = ["comparison_grid", "error_maps", "worst_cases", "sweep_plot"]


def _np(x: Tensor) -> np.ndarray:
    return x.detach().cpu().squeeze().float().numpy()


def comparison_grid(
    images: dict[str, Tensor],
    reference_key: str = "ground truth",
    index: int = 0,
    zoom: tuple[int, int, int, int] | None = None,
    save: Path | str | None = None,
    title: str | None = None,
):
    """Side-by-side reconstructions with metrics annotated, on a shared scale.

    Parameters
    ----------
    images:
        Ordered mapping of label -> batch tensor. Put the reference last or
        first and keep the ladder in order; readers compare left to right.
    zoom:
        Optional ``(top, left, height, width)`` crop. A zoom panel on a small
        structure is usually more informative than the whole slice, so pick the
        region *before* you see the results, not after.
    """
    from .shared.metrics import psnr, ssim

    if reference_key not in images:
        raise KeyError(f"reference_key {reference_key!r} not among {list(images)}")
    ref = images[reference_key][index : index + 1]
    vmin, vmax = float(_np(ref).min()), float(_np(ref).max())

    n = len(images)
    fig, axes = plt.subplots(1, n, figsize=(3.1 * n, 3.6))
    if n == 1:
        axes = [axes]

    for ax, (label, batch) in zip(axes, images.items()):
        img = batch[index : index + 1]
        arr = _np(img)
        if zoom:
            t, l, h, w = zoom
            arr = arr[t : t + h, l : l + w]
        ax.imshow(arr, cmap="gray", vmin=vmin, vmax=vmax)
        if label == reference_key:
            ax.set_title(label, fontsize=10)
        else:
            p = float(psnr(img.clamp(0, 1), ref))
            s = float(ssim(img.clamp(0, 1), ref))
            ax.set_title(f"{label}\n{p:.2f} dB / {s:.3f}", fontsize=10)
        ax.axis("off")

    if title:
        fig.suptitle(title, fontsize=12)
    fig.tight_layout()
    if save:
        Path(save).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save, dpi=150, bbox_inches="tight")
    return fig


def error_maps(
    images: dict[str, Tensor],
    reference: Tensor,
    index: int = 0,
    scale: float = 0.25,
    save: Path | str | None = None,
):
    """Absolute error maps on a shared scale.

    Where a method fails is more diagnostic than how much. Streaks radiating
    from dense structures, residual aliasing in a regular pattern, or error
    concentrated at edges each point at a different cause.
    """
    ref = reference[index : index + 1]
    n = len(images)
    fig, axes = plt.subplots(1, n, figsize=(3.1 * n, 3.4))
    if n == 1:
        axes = [axes]
    for ax, (label, batch) in zip(axes, images.items()):
        err = (batch[index : index + 1].clamp(0, 1) - ref).abs()
        im = ax.imshow(_np(err), cmap="inferno", vmin=0, vmax=scale)
        ax.set_title(f"|error|: {label}", fontsize=10)
        ax.axis("off")
    fig.colorbar(im, ax=axes, fraction=0.025)
    if save:
        Path(save).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save, dpi=150, bbox_inches="tight")
    return fig


def worst_cases(
    results_path: Path | str, k: int = 5, metric: str = "psnr"
) -> list[tuple[int, float]]:
    """Indices of the `k` worst test samples in a `results.json`.

    Start your failure analysis here, then re-run those indices through
    `comparison_grid`. Picking failures by metric rather than by eye stops you
    from showing the prettiest failure instead of the worst one.
    """
    import json

    data = json.loads(Path(results_path).read_text())
    if isinstance(data, list):
        raise ValueError(f"{results_path} is a sweep; pass a plain results.json")
    values = data["per_sample"][metric]
    order = np.argsort(values)  # ascending; low PSNR/SSIM is bad
    if metric == "nmse":
        order = order[::-1]  # high NMSE is bad
    return [(int(i), float(values[i])) for i in order[:k]]


def sweep_plot(
    sweeps: dict[str, Path | str],
    metric: str = "psnr",
    save: Path | str | None = None,
    trained_at: dict[str, float] | None = None,
):
    """Plot generalisation sweeps: metric against acquisition setting.

    Parameters
    ----------
    sweeps:
        Mapping of series label -> path to a `sweep_<key>.json`.
    trained_at:
        Optional mapping of series label -> the setting that series was
        trained at, drawn as a vertical marker. Include it. The interesting
        part of a generalisation study is how performance decays *away* from
        the training setting, and a reader cannot see that without knowing
        where the training setting was.
    """
    import json

    fig, ax = plt.subplots(figsize=(6, 4))
    for label, path in sweeps.items():
        entries = json.loads(Path(path).read_text())
        xs = [e["sweep"]["value"] for e in entries]
        ys = [e["metrics"][metric]["mean"] for e in entries]
        line, = ax.plot(xs, ys, marker="o", label=label)
        if trained_at and label in trained_at:
            ax.axvline(
                trained_at[label], color=line.get_color(), ls=":", alpha=0.6, lw=1
            )
    key = next(iter(json.loads(Path(next(iter(sweeps.values()))).read_text())))["sweep"]["key"]
    ax.set_xlabel(key)
    ax.set_ylabel(f"{metric.upper()} (test mean)")
    ax.grid(alpha=0.3)
    ax.legend()
    fig.tight_layout()
    if save:
        Path(save).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save, dpi=150, bbox_inches="tight")
    return fig

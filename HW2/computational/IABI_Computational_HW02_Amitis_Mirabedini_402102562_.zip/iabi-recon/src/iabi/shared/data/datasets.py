"""Datasets and loaders.

Plain PyTorch; nothing here is specific to reconstruction.

The dataset yields *clean images only*. Measurements are simulated inside the
training loop, on the GPU, from whatever operator that step happens to be
using. This split is what makes the generalisation sweeps cheap:

- the sampling pattern can change every step (fresh mask per sample is a strong,
  free augmentation)
- the acceleration factor or angle count can be drawn from a distribution
  without touching the data pipeline
- a trained model can be evaluated under geometries it never saw, because
  nothing about the geometry is baked into the stored data

Simulating on the GPU also keeps the dataloader trivial, which matters on Colab
where CPU workers are scarce and slow.
"""

from __future__ import annotations

from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset

from .packs import load_pack

__all__ = ["SliceDataset", "make_loader"]


class SliceDataset(Dataset):
    """Clean 2D slices as ``(1, H, W)`` float32 tensors in ``[0, 1]``.

    Parameters
    ----------
    augment:
        Random horizontal flips and 90-degree rotations. Cheap, label-free, and
        anatomically harmless for both tracks at these resolutions.
    """

    def __init__(
        self,
        track: str,
        split: str = "train",
        root: Path | str | None = None,
        limit: int | None = None,
        augment: bool = False,
        allow_synthetic: bool = True,
    ):
        self.images = load_pack(
            track, split, root=root, limit=limit, allow_synthetic=allow_synthetic
        )
        self.augment = augment and split == "train"
        self.track = track
        self.split = split

    def __len__(self) -> int:
        return int(self.images.shape[0])

    def __getitem__(self, idx: int) -> torch.Tensor:
        # ------------------------------------------------------------------
        # TODO(students) [17/20]: return one slice as a tensor.
        #
        # `self.images` is an (N, H, W) float32 array in [0, 1].
        #
        #   1. Take image `idx`.
        #   2. If self.augment: random horizontal flip (p = 0.5) and a random
        #      rot90 (k drawn from 0..3). Wrap each in np.ascontiguousarray,
        #      because negative strides do not survive torch.from_numpy.
        #   3. Return float32 of shape (1, H, W).
        #
        # `__init__` has already forced self.augment False off the training
        # split. Augmenting validation only adds noise to the number you are
        # trying to read.
        #
        # Gate: pytest tests/shared/test_training.py
        # ------------------------------------------------------------------
        image = self.images[idx]
        if self.augment:
            if torch.rand(()).item() < 0.5:
                image = np.ascontiguousarray(np.flip(image, axis=-1))
            k = int(torch.randint(4, ()).item())
            image = np.ascontiguousarray(np.rot90(image, k))
        return torch.from_numpy(np.ascontiguousarray(image)).to(torch.float32).unsqueeze(0)

    @property
    def resolution(self) -> int:
        return int(self.images.shape[-1])

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        return (
            f"SliceDataset(track={self.track!r}, split={self.split!r}, "
            f"n={len(self)}, res={self.resolution})"
        )


def make_loader(
    dataset: SliceDataset,
    batch_size: int = 8,
    shuffle: bool | None = None,
    num_workers: int = 2,
    seed: int | None = None,
) -> DataLoader:
    """Build a DataLoader with Colab-appropriate defaults.

    `num_workers=2` because Colab runtimes have few CPU cores and spawning more
    workers than cores makes throughput worse, not better. `pin_memory` is on
    for faster host-to-device copies; `drop_last` on the training split keeps
    batch shapes uniform, which avoids a recompile-shaped stall on the final
    partial batch.
    """
    # ------------------------------------------------------------------
    # TODO(students) [18/20]: build the DataLoader.
    #
    #   shuffle             default to (dataset.split == "train") when None
    #   generator           torch.Generator().manual_seed(seed), if seed given
    #   pin_memory          torch.cuda.is_available()
    #   drop_last           same as shuffle: uniform batch shapes while
    #                       training, but every validation sample scored
    #   persistent_workers  num_workers > 0
    #
    # Leave num_workers at 2. Colab runtimes have few cores, and spawning more
    # workers than cores makes throughput worse rather than better.
    #
    # Gate: pytest tests/shared/test_training.py
    # ------------------------------------------------------------------
    if shuffle is None:
        shuffle = dataset.split == "train"
    generator = None if seed is None else torch.Generator().manual_seed(seed)
    return DataLoader(dataset, batch_size=batch_size, shuffle=shuffle,
                      num_workers=num_workers, generator=generator,
                      pin_memory=torch.cuda.is_available(), drop_last=shuffle,
                      persistent_workers=num_workers > 0)

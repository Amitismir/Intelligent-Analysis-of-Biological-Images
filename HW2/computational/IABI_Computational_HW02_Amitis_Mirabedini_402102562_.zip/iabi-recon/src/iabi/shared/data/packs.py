"""Dataset packs. Provided and working; no TODOs.

Why we ship derived packs
-------------------------
The full datasets don't fit a one-hour Colab session: LoDoPaB-CT is about
55 GB, and fastMRI needs a signed data-use agreement and a large download.

So each track gets a pack of clean ground-truth images, about 100 MB, pulled
from the Hugging Face Hub:

===========  ==============================  ===================================
Track        Source                          Licence
===========  ==============================  ===================================
MRI          IXI brain MR (T2)               CC BY-SA 3.0
CT           LoDoPaB-CT ground-truth slices  CC BY 4.0
===========  ==============================  ===================================

Both sources permit redistribution with attribution; see ``docs/DATA.md`` for
the provenance and the build script.

The packs hold no k-space and no sinograms. Measurements are simulated on the
fly from the clean images (`mri/simulate.py` and `ct/simulate.py`), so the
acceleration factor and angle count can be changed freely.

Simulated single-coil k-space is not the fastMRI multi-coil benchmark, and your
numbers are not comparable to published ones; see the end of the README.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

import numpy as np

__all__ = ["PackSpec", "PACKS", "load_pack", "synthetic_phantoms"]


@dataclass(frozen=True)
class PackSpec:
    """Where a pack lives and what shape it has."""

    repo_id: str
    resolution: int
    description: str


PACKS: dict[str, PackSpec] = {
    "mri": PackSpec(
        repo_id="aluk4/iabi-mri-brain",
        resolution=160,
        description="IXI brain MR magnitude slices, CC BY-SA 3.0",
    ),
    "ct": PackSpec(
        repo_id="aluk4/iabi-ct-slices",
        resolution=128,
        description="LoDoPaB-CT ground-truth slices, CC BY 4.0",
    ),
}

_DEFAULT_ROOT = Path(os.environ.get("IABI_DATA_ROOT", "./data_cache"))

# Set IABI_PACKS_DIR to a directory laid out as `<track>/<split>.npz` to load
# packs straight off disk and skip the Hub entirely. This is how a freshly
# built pack gets verified before it is published, and it is also the escape
# hatch if the Hub is unreachable.
# Read at call time, not import time, so a notebook can set it after import.


def synthetic_phantoms(
    n: int, size: int, seed: int = 0, n_ellipses: int = 8
) -> np.ndarray:
    """Random ellipse phantoms, generated locally with no download.

    Not a substitute for real anatomy: these are far too easy, and results on
    them mean nothing for your report. They exist so that the test suite, the
    adjoint checks and `--smoke` runs work offline and instantly, including on
    a machine with no network access and before the packs are published.

    If you find yourself reporting numbers computed on these, something has
    gone wrong: check that your pack actually downloaded.
    """
    rng = np.random.default_rng(seed)
    yy, xx = np.mgrid[0:size, 0:size]
    yy = (yy - size / 2) / (size / 2)
    xx = (xx - size / 2) / (size / 2)

    out = np.zeros((n, size, size), dtype=np.float32)
    for i in range(n):
        img = np.zeros((size, size), dtype=np.float32)
        # An outer skull-like ellipse, then a few interior structures.
        for j in range(n_ellipses):
            cy, cx = rng.uniform(-0.35, 0.35, size=2)
            ry, rx = rng.uniform(0.12, 0.45, size=2)
            angle = rng.uniform(0, np.pi)
            value = rng.uniform(0.15, 1.0)
            ct, st = np.cos(angle), np.sin(angle)
            yr = (yy - cy) * ct + (xx - cx) * st
            xr = -(yy - cy) * st + (xx - cx) * ct
            inside = (yr / ry) ** 2 + (xr / rx) ** 2 <= 1.0
            img[inside] = value if j > 0 else 0.35
        out[i] = img
    return np.clip(out, 0.0, 1.0)


def _normalise(images: np.ndarray) -> np.ndarray:
    """Per-slice normalisation to [0, 1].

    Done per slice rather than globally so that a single bright outlier slice
    cannot compress the dynamic range of every other one, and so that
    ``data_range=1.0`` is valid for every PSNR/SSIM call downstream.
    """
    images = images.astype(np.float32)
    flat = images.reshape(images.shape[0], -1)
    lo = flat.min(axis=1).reshape(-1, 1, 1)
    hi = flat.max(axis=1).reshape(-1, 1, 1)
    return (images - lo) / np.clip(hi - lo, 1e-6, None)


def load_pack(
    track: str,
    split: str = "train",
    root: Path | str | None = None,
    limit: int | None = None,
    allow_synthetic: bool = True,
    verbose: bool = True,
) -> np.ndarray:
    """Load a split of a dataset pack as ``(N, H, W)`` float32 in ``[0, 1]``.

    Parameters
    ----------
    track:
        ``"mri"`` or ``"ct"``.
    split:
        ``"train"``, ``"val"`` or ``"test"``.
    limit:
        Keep only the first `limit` slices. This is what `--smoke` uses.
    allow_synthetic:
        If the pack cannot be downloaded, fall back to `synthetic_phantoms`
        with a loud warning rather than failing. Keeps the test suite and
        offline development working. Set False in scripts that must use real
        data.
    """
    if track not in PACKS:
        raise KeyError(f"unknown track {track!r}; expected one of {list(PACKS)}")
    if split not in {"train", "val", "test"}:
        raise ValueError(f"unknown split {split!r}")

    spec = PACKS[track]
    root = Path(root) if root is not None else _DEFAULT_ROOT

    local_root = os.environ.get("IABI_PACKS_DIR")
    if local_root:
        local = Path(local_root) / track / f"{split}.npz"
        if local.exists():
            images = np.load(local)["images"]
            if verbose:
                print(f"[packs] {track}/{split}: {images.shape[0]} slices from {local}")
            images = _normalise(np.asarray(images))
            return images[:limit] if limit is not None else images
        print(f"[packs] IABI_PACKS_DIR is set but {local} is missing; trying the Hub")

    try:
        from huggingface_hub import hf_hub_download

        path = hf_hub_download(
            repo_id=spec.repo_id,
            filename=f"{split}.npz",
            repo_type="dataset",
            cache_dir=str(root),
        )
        images = np.load(path)["images"]
        if verbose:
            print(f"[packs] {track}/{split}: {images.shape[0]} slices from {spec.repo_id}")
    except Exception as exc:  # noqa: BLE001 - any failure falls back
        if not allow_synthetic:
            raise
        n = {"train": 256, "val": 32, "test": 32}[split]
        seed = {"train": 0, "val": 1, "test": 2}[split]
        # Hub errors run to a dozen lines of auth advice. One line is enough
        # to say what failed; the important half of this message is the second
        # line, and it should not be buried.
        reason = str(exc).strip().splitlines()[0][:120]
        print(
            f"[packs] WARNING: could not load {spec.repo_id}/{split}.npz ({reason})\n"
            f"[packs] Falling back to SYNTHETIC PHANTOMS. These are for smoke "
            f"tests only. Do not report results computed on them."
        )
        images = synthetic_phantoms(n, spec.resolution, seed=seed)

    images = _normalise(np.asarray(images))
    if limit is not None:
        images = images[:limit]
    return images

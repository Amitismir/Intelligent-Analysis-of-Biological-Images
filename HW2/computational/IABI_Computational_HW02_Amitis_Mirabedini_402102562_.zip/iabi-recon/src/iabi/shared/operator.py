"""The forward-operator interface shared by both tracks.

Both tracks solve the same problem::

    minimise_x  || A(x) - y ||^2  +  R(x)

`A` is the *forward operator*: it maps an image to the measurements a scanner
actually records. It is what the physics of the modality does to the patient.

- MRI  : A = sample a subset of 2D Fourier coefficients   (`mri/operator.py`)
- CT   : A = integrate along lines through the body       (`ct/operator.py`)

`A_adjoint` is the *adjoint* (the conjugate transpose, A^H). It maps
measurements back to image space. Two things that are easy to get wrong:

1. The adjoint is not the inverse. `A_adjoint(A(x))` does not give you `x`
   back. For MRI the adjoint gives you the zero-filled reconstruction (with
   aliasing); for CT it gives you the unfiltered backprojection (blurry). Both
   are poor images, and the rest of the code exists to improve on them.

2. The adjoint is defined by an identity, not by a formula::

       <A(x), y>  ==  <x, A_adjoint(y)>      for all x, y

   This is what `tests/test_adjoint.py` checks. If your adjoint is wrong, that
   test fails and *nothing downstream can work*: the data-consistency step in
   an unrolled network is built out of `A` and `A_adjoint`, so a wrong adjoint
   trains to garbage without ever raising an error. Get this test green first.

Shape and dtype contract
------------------------
Image space is always real::

    x : (B, 1, H, W)  float32

Measurement space is modality-specific and is documented on each subclass:

    MRI : (B, 1, H, W)          complex64   (masked, centred k-space)
    CT  : (B, 1, n_angles, W)   float32     (a sinogram)

Because image space is real, an operator whose measurement space is complex
must return the real part in `A_adjoint`; with a real domain, that is the
adjoint. `mri/operator.py` derives this in its docstring.
"""

from __future__ import annotations

import abc

import torch
from torch import Tensor


class Operator(abc.ABC):
    """Abstract linear forward operator.

    Subclasses must implement `A` and `A_adjoint` and set `measurement_shape`.

    The operator is *linear*, which buys us two things used throughout the
    codebase: the adjoint identity above, and the fact that the adjoint equals
    the vector-Jacobian product of `A` (see `A_adjoint_via_autograd`).
    """

    #: Human-readable name used in logs and result files.
    name: str = "operator"

    @abc.abstractmethod
    def A(self, x: Tensor) -> Tensor:
        """Forward operator: image -> measurements."""

    @abc.abstractmethod
    def A_adjoint(self, y: Tensor) -> Tensor:
        """Adjoint operator: measurements -> image."""

    def measurement_shape(self, image_shape: tuple[int, ...]) -> tuple[int, ...]:
        """Shape of `A(x)` given the shape of `x`. Override if not identity."""
        return image_shape

    # ------------------------------------------------------------------
    # Provided utilities. You do not need to modify anything below here.
    # ------------------------------------------------------------------

    def normal(self, x: Tensor) -> Tensor:
        """The normal operator A^H A. Appears in every data-consistency step."""
        return self.A_adjoint(self.A(x))

    def grad_datafit(self, x: Tensor, y: Tensor) -> Tensor:
        r"""Gradient of :math:`\tfrac12 \|A(x) - y\|^2` with respect to `x`.

        Equal to ``A_adjoint(A(x) - y)``. This is the quantity a
        data-consistency step descends along; see `models/unrolled.py`.
        """
        return self.A_adjoint(self.A(x) - y)

    def A_adjoint_via_autograd(self, y: Tensor, image_shape: tuple[int, ...]) -> Tensor:
        """Reference adjoint obtained by automatic differentiation.

        For a linear operator the adjoint *is* the vector-Jacobian product, so
        this is always correct by construction. It is slower than a hand-written
        adjoint and is here purely as a debugging aid: if `test_adjoint.py`
        fails, compare your `A_adjoint` against this to see where it diverges.

        Do not use this in training code: it allocates a graph every call.
        """
        x = torch.zeros(
            image_shape, dtype=torch.float32, device=y.device, requires_grad=True
        )
        with torch.enable_grad():
            out = self.A(x)
        if out.is_complex():
            # Real inner product on a complex measurement space:
            # <u, v>_R = Re(sum conj(u) v). Differentiating that pairing with
            # respect to a real x gives the real-domain adjoint we want.
            (grad,) = torch.autograd.grad(
                (out.real, out.imag), x, grad_outputs=(y.real, y.imag)
            )
        else:
            (grad,) = torch.autograd.grad(out, x, grad_outputs=y)
        return grad.detach()

    def __repr__(self) -> str:  # pragma: no cover - cosmetic
        return f"{type(self).__name__}(name={self.name!r})"


def estimate_operator_norm(
    op: Operator,
    image_shape: tuple[int, ...],
    n_iter: int = 20,
    device: torch.device | str = "cpu",
    seed: int = 0,
) -> float:
    """Estimate the spectral norm of the normal operator ``A^H A`` by power iteration.

    Repeatedly applying ``A^H A`` to a random vector and renormalising converges
    to the dominant eigenvector; the growth factor per step converges to the
    dominant eigenvalue, which for a self-adjoint positive semi-definite
    operator is exactly ``||A^H A||``.

    We need this because the two modalities live at wildly different scales.
    Our MRI operator is an orthogonal projection (eigenvalues in ``{0, 1}``, so
    the norm is 1), while the CT operator's norm grows with the number of
    projection angles. Dividing the data-consistency step by this number makes
    a single step-size initialisation work for both; see
    `models/unrolled.py`.

    Estimated once per operator configuration and cached by the caller; twenty
    iterations is far more than enough for the accuracy required here.
    """
    gen = torch.Generator(device="cpu").manual_seed(seed)
    x = torch.randn(*image_shape, generator=gen).to(device=device, dtype=torch.float32)
    x = x / x.norm().clamp(min=1e-12)
    norm = 1.0
    for _ in range(n_iter):
        x = op.normal(x)
        norm = float(x.norm())
        if norm < 1e-12:
            return 1.0
        x = x / norm
    return max(norm, 1e-12)


def real_inner(a: Tensor, b: Tensor) -> Tensor:
    """Real-valued inner product, valid for real or complex tensors.

    For complex tensors this is ``Re(sum conj(a) * b)``, which is the inner
    product you get by viewing C^n as R^2n. That is the right pairing to use in
    the adjoint test whenever one side of the operator is complex and the other
    is real.
    """
    if a.is_complex() or b.is_complex():
        a_c = a if a.is_complex() else a.to(torch.complex64)
        b_c = b if b.is_complex() else b.to(torch.complex64)
        return torch.sum(a_c.conj() * b_c).real
    return torch.sum(a * b)

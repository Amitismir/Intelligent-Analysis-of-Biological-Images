"""Dispatch to the right simulator for the operator you are holding.

This is the seam that lets the training loop stay modality-agnostic: it holds
an operator and calls `simulate`, and never learns which track it is running.
The two simulators themselves are modality-specific and live with their
operators, in `iabi/mri/simulate.py` and `iabi/ct/simulate.py`.
"""

from __future__ import annotations

from torch import Generator, Tensor

from ..ct.operator import ParallelBeamRadon
from ..ct.simulate import simulate_ct
from ..mri.operator import MaskedFFT
from ..mri.simulate import simulate_mri
from .operator import Operator

__all__ = ["simulate", "simulate_mri", "simulate_ct"]


def simulate(
    x: Tensor,
    op: Operator,
    generator: Generator | None = None,
    **kwargs,
) -> Tensor:
    """Dispatch to the right simulator for the operator type.

    Lets the training loop stay modality-agnostic: it holds an operator and
    calls `simulate`, without knowing which track it is running.
    """
    if isinstance(op, MaskedFFT):
        return simulate_mri(x, op, generator=generator, **kwargs)
    if isinstance(op, ParallelBeamRadon):
        return simulate_ct(x, op, generator=generator, **kwargs)
    raise TypeError(f"no simulator registered for {type(op).__name__}")

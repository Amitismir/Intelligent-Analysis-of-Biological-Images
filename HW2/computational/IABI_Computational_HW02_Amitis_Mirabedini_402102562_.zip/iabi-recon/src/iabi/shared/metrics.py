"""Evaluation metrics.

PSNR and SSIM are the standard metrics in the reconstruction literature. Both
are global and reference-based: they reward being close to the ground truth
on average over all pixels. A method can gain 0.4 dB of PSNR by smoothing
noise everywhere while erasing a small lesion, and can lose PSNR by sharpening
an edge one pixel away from where the target has it.

A small improvement in an average metric is not a finding by itself. Pair
every table with:

- error maps, not just scalars (see `viz.py`)
- a region-specific breakdown where you have one
- failure cases chosen by metric, not by eye

`edge_preservation` is a cheap check for the "looks cleaner, is blurrier"
failure that PSNR rewards.
"""

from __future__ import annotations

import math

import torch
import torch.nn.functional as F
from torch import Tensor

__all__ = ["psnr", "ssim", "nmse", "edge_preservation", "evaluate_batch"]


def _flatten_batch(x: Tensor) -> Tensor:
    return x.reshape(x.shape[0], -1)


def psnr(pred: Tensor, target: Tensor, data_range: float = 1.0) -> Tensor:
    """Peak signal-to-noise ratio in dB, per sample in the batch."""
    # ------------------------------------------------------------------
    # ------------------------------------------------------------------
    # TODO(students) [14/20]: PSNR, and NMSE just below.
    #
    #     PSNR = 10 * log10(data_range^2 / MSE)
    #
    # Square the error, flatten with `_flatten_batch`, mean over dim=1, and
    # clamp to 1e-12 so an exact match gives a large number, not an infinity.
    #
    # 10*log10, not 20: the 20 form is for amplitude ratios and MSE is
    # already a power. Return one value per sample: eval.py averages later, and
    # averaging here costs you the standard deviation and your worst cases.
    #
    # Gate: pytest tests/shared/test_metrics.py
    # ------------------------------------------------------------------
    mse = _flatten_batch((pred - target).square()).mean(dim=1).clamp(min=1e-12)
    return 10 * torch.log10(data_range**2 / mse)


def nmse(pred: Tensor, target: Tensor) -> Tensor:
    """Normalised mean-squared error, per sample. The fastMRI leaderboard metric."""
    # ------------------------------------------------------------------
    # ------------------------------------------------------------------
    # TODO(students) [14/20, continued]: NMSE.
    #
    #     ||pred - target||^2 / ||target||^2,  per sample, denominator clamped
    #
    # Normalising by the target's energy is what makes this comparable across
    # slices of different brightness, and is the difference from plain MSE.
    # ------------------------------------------------------------------
    error = _flatten_batch((pred - target).square()).sum(dim=1)
    energy = _flatten_batch(target.square()).sum(dim=1).clamp(min=1e-12)
    return error / energy


def _gaussian_window(size: int, sigma: float, device: torch.device) -> Tensor:
    coords = torch.arange(size, dtype=torch.float32, device=device) - (size - 1) / 2.0
    g = torch.exp(-(coords**2) / (2 * sigma**2))
    g = g / g.sum()
    return g.outer(g).reshape(1, 1, size, size)


def ssim(
    pred: Tensor,
    target: Tensor,
    data_range: float = 1.0,
    window_size: int = 11,
    sigma: float = 1.5,
) -> Tensor:
    """Structural similarity index, per sample in the batch.

    Gaussian-weighted local statistics with the standard constants. Compares
    local luminance, contrast and structure rather than raw pixel differences,
    which makes it somewhat less forgiving of blur than PSNR, though only
    somewhat.
    """
    if pred.shape != target.shape:
        raise ValueError(f"shape mismatch: {pred.shape} vs {target.shape}")

    # ------------------------------------------------------------------
    # ------------------------------------------------------------------
    # TODO(students) [15/20]: structural similarity.
    #
    # Every statistic is *local*, computed in a sliding Gaussian window, not
    # over the whole image. That is what separates SSIM from a correlation.
    #
    #   c1, c2 = (0.01 * data_range)^2, (0.03 * data_range)^2
    #   win    = _gaussian_window(window_size, sigma, ...), pad = window_size // 2
    #   filt(t): F.conv2d(F.pad(t, (pad,) * 4, mode="reflect"), win)
    #
    #   mu_p, mu_t = filt(pred), filt(target)
    #   sig_p      = filt(pred^2) - mu_p^2            (likewise sig_t)
    #   sig_pt     = filt(pred * target) - mu_p * mu_t
    #   num = (2*mu_p*mu_t + c1) * (2*sig_pt + c2)
    #   den = (mu_p^2 + mu_t^2 + c1) * (sig_p + sig_t + c2)
    #
    # Average the resulting map per sample. Use the same window throughout:
    # global means with local variances gives something that scores plausibly
    # and is not SSIM.
    #
    # Gate: pytest tests/shared/test_metrics.py
    # ------------------------------------------------------------------
    c1, c2 = (0.01 * data_range)**2, (0.03 * data_range)**2
    win = _gaussian_window(window_size, sigma, pred.device).to(pred.dtype)
    channels = pred.shape[1]
    win = win.expand(channels, 1, window_size, window_size)
    pad = window_size // 2
    def filt(t):
        return F.conv2d(F.pad(t, (pad,) * 4, mode="reflect"), win, groups=channels)
    mu_p, mu_t = filt(pred), filt(target)
    sig_p = filt(pred.square()) - mu_p.square()
    sig_t = filt(target.square()) - mu_t.square()
    sig_pt = filt(pred * target) - mu_p * mu_t
    num = (2 * mu_p * mu_t + c1) * (2 * sig_pt + c2)
    den = (mu_p.square() + mu_t.square() + c1) * (sig_p + sig_t + c2)
    return _flatten_batch(num / den).mean(dim=1)


def edge_preservation(pred: Tensor, target: Tensor) -> Tensor:
    """Edge-preservation index, per sample.

    Pearson correlation between the gradient-magnitude maps of the
    reconstruction and the target. This is *not* Pratt's figure of merit, which
    detects binary edge maps and scores the distance from each detected edge to
    the nearest true one; if you cite a metric by name in your report, cite this
    one as a gradient-correlation edge index. Near 1 means edges land in the right places with the right
    relative strengths; a smoothed reconstruction scores poorly here even when
    its PSNR is flattering, which is why it is worth reporting
    alongside.
    """
    # ------------------------------------------------------------------
    # ------------------------------------------------------------------
    # TODO(students) [16/20]: the edge-preservation figure of merit.
    #
    #   gradient magnitude: gx = t[..., 1:, :-1] - t[..., :-1, :-1]
    #                       gy = t[..., :-1, 1:] - t[..., :-1, :-1]
    #                       sqrt(gx^2 + gy^2 + 1e-12)
    #   (the matching crops keep both differences on the same grid)
    #
    # Return the per-sample Pearson correlation between the two magnitude
    # maps: centre each, then (gp*gt).sum(dim=1) / (||gp|| * ||gt||), clamped.
    #
    # Correlating *gradients* is what makes this blind to a brightness offset
    # and sensitive to blur: the "looks cleaner, is less diagnostic" failure
    # that PSNR actively rewards.
    #
    # Gate: pytest tests/shared/test_metrics.py
    # ------------------------------------------------------------------
    def magnitude(t):
        gx = t[..., 1:, :-1] - t[..., :-1, :-1]
        gy = t[..., :-1, 1:] - t[..., :-1, :-1]
        return _flatten_batch(torch.sqrt(gx.square() + gy.square() + 1e-12))
    gp, gt = magnitude(pred), magnitude(target)
    gp = gp - gp.mean(dim=1, keepdim=True)
    gt = gt - gt.mean(dim=1, keepdim=True)
    den = (gp.norm(dim=1) * gt.norm(dim=1)).clamp(min=1e-12)
    return (gp * gt).sum(dim=1) / den


def evaluate_batch(
    pred: Tensor, target: Tensor, data_range: float = 1.0
) -> dict[str, Tensor]:
    """All metrics at once, each a per-sample tensor of shape ``(B,)``.

    Per-sample values rather than batch means, so `eval.py` can report a
    standard deviation and you can find your worst cases.
    """
    return {
        "psnr": psnr(pred, target, data_range),
        "ssim": ssim(pred, target, data_range),
        "nmse": nmse(pred, target),
        "edge": edge_preservation(pred, target),
    }

"""The training loop: forward, loss, backward, step, and scoring.

TODOs 19 and 20 live here, and they are the last two you write.

Plain PyTorch; nothing in this file is specific to reconstruction. The
operator arrives as an argument, and this file never checks which one it is.

`iabi/train.py` is the command-line wrapper around these two functions
(argument parsing, checkpointing, history) and has no TODOs in it.
"""

from __future__ import annotations

import torch
import torch.nn as nn

from ..config import Config
from ..engine import build_operator, operator_norm, reconstruct
from .metrics import evaluate_batch
from .simulate import simulate

__all__ = ["train_one_epoch", "validate"]


def _sim_kwargs(cfg: Config) -> dict:
    """Simulation parameters for the active track."""
    if cfg.track == "mri":
        return {"noise_sigma": cfg.noise_sigma}
    return {"photons": cfg.photons, "mu_scale": cfg.mu_scale}


def train_one_epoch(
    cfg: Config,
    model: nn.Module,
    loader,
    opt: torch.optim.Optimizer,
    loss_fn: nn.Module,
    device: torch.device,
    generator: torch.Generator,
) -> float:
    """Run one pass over the training split. Returns the mean loss."""
    # ------------------------------------------------------------------
    # TODO(students) [19/20]: one pass over the training split.
    #
    # model.train(), then for each batch `x` from `loader`:
    #
    #   1. x = x.to(device, non_blocking=True)
    #   2. op   = build_operator(cfg, x.shape[-1], x.shape[0], device, generator)
    #      norm = operator_norm(op, x.shape, device)
    #   3. under torch.no_grad():
    #          y = simulate(x, op, generator=generator, **_sim_kwargs(cfg))
    #      The measurements are data: no gradient may flow into simulation.
    #   4. pred = reconstruct(cfg, model, y, op, norm); loss = loss_fn(pred, x)
    #   5. opt.zero_grad(set_to_none=True); loss.backward(); clip to
    #      cfg.grad_clip if it is > 0; opt.step()
    #   6. accumulate float(loss.detach()); detach first, or torch warns
    #      about converting a tensor that still requires grad
    #
    # Return the mean loss over batches.
    #
    # Order matters in step 5: zero_grad *before* backward. The other way round
    # wipes the gradients you just computed and the model silently never
    # learns, and the loss simply plateaus at its initial value.
    #
    # Gate: pytest tests/shared/test_training.py
    # ------------------------------------------------------------------
    model.train()
    total, batches = 0.0, 0
    for x in loader:
        x = x.to(device, non_blocking=True)
        op = build_operator(cfg, x.shape[-1], x.shape[0], device, generator)
        norm = operator_norm(op, tuple(x.shape), device)
        with torch.no_grad():
            y = simulate(x, op, generator=generator, **_sim_kwargs(cfg))
        opt.zero_grad(set_to_none=True)
        pred = reconstruct(cfg, model, y, op, norm)
        loss = loss_fn(pred, x)
        loss.backward()
        if cfg.grad_clip > 0:
            nn.utils.clip_grad_norm_(model.parameters(), cfg.grad_clip)
        opt.step()
        total += float(loss.detach())
        batches += 1
    return total / max(batches, 1)


@torch.no_grad()
def validate(
    cfg: Config,
    model: nn.Module | None,
    loader,
    device: torch.device,
    generator: torch.Generator,
) -> dict[str, float]:
    """Mean metrics over the validation split."""
    # ------------------------------------------------------------------
    # TODO(students) [20/20]: score the validation split.
    #
    # Same per-batch preparation as steps 1-4 of train_one_epoch, but:
    #
    #   - model.eval() first, model.train() again before returning
    #   - no optimiser, no backward
    #   - scores = evaluate_batch(pred.clamp(0, 1), x), then accumulate
    #     float(v.sum()) per metric and divide by the *sample* count
    #
    # `model` may be None: the classical methods have nothing to switch.
    #
    # Divide by samples, not batches, or a partial final batch is weighted too
    # heavily. The @torch.no_grad() decorator above already keeps autograd out.
    #
    # Gate: pytest tests/shared/test_training.py
    # ------------------------------------------------------------------
    if model is not None:
        model.eval()
    totals = {key: 0.0 for key in ("psnr", "ssim", "nmse", "edge")}
    count = 0
    try:
        for x in loader:
            x = x.to(device, non_blocking=True)
            op = build_operator(cfg, x.shape[-1], x.shape[0], device, generator)
            norm = operator_norm(op, tuple(x.shape), device)
            y = simulate(x, op, generator=generator, **_sim_kwargs(cfg))
            pred = reconstruct(cfg, model, y, op, norm)
            scores = evaluate_batch(pred.clamp(0, 1), x)
            for key, values in scores.items():
                totals[key] += float(values.sum())
            count += x.shape[0]
    finally:
        if model is not None:
            model.train()
    return {key: total / max(count, 1) for key, total in totals.items()}

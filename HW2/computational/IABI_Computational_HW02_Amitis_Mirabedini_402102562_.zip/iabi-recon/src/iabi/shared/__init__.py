"""Everything both tracks use, written once.

TODOs 8 to 20 are here. The solver, the networks and the metrics reach the
physics only through the `Operator` interface in `operator.py`. The only module
here that imports `iabi.mri` or `iabi.ct` is `simulate.py`, which picks the
simulator for an operator.

    operator.py    the interface every operator implements  (given)
    classical.py   TV + FISTA: CS for MRI, TV for CT     [8, 9, 10]
    models/        the U-Net and the unrolled network   [11, 12, 13]
    metrics.py     PSNR, NMSE, SSIM, edge preservation  [14, 15, 16]
    data/          packs, slices, loaders                   [17, 18]
    training.py    one epoch, and validation                [19, 20]
    simulate.py    picks the simulator for your operator    (given)

Submodules are imported explicitly (``from iabi.shared.classical import
tv_reconstruct``) rather than re-exported here, so the file a name lives in is
visible where it is used.
"""

"""Classical variational reconstruction: TV-regularised FISTA.

One function is rung two of both ladders. TV reconstruction for CT and
compressed sensing for MRI are the same algorithm with different operators::

    min_x  1/2 ||A(x) - y||^2  +  lam * TV(x)

Total variation assumes images are piecewise smooth. It penalises the
integrated gradient magnitude, which allows a few sharp edges but suppresses
the scattered fine-scale noise from undersampling and low dose. Its known
failure is staircasing: with `lam` too high, smooth intensity ramps turn into
flat plateaus with artificial edges between them. Look for it in your figures.
"""

from __future__ import annotations

import torch
from torch import Tensor

from .operator import Operator, estimate_operator_norm

__all__ = ["tv_reconstruct", "total_variation", "tv_grad"]


def _grad(x: Tensor) -> tuple[Tensor, Tensor]:
    """Forward finite differences with Neumann (zero-gradient) boundaries."""
    gx = torch.zeros_like(x)
    gy = torch.zeros_like(x)
    gx[..., :-1, :] = x[..., 1:, :] - x[..., :-1, :]
    gy[..., :, :-1] = x[..., :, 1:] - x[..., :, :-1]
    return gx, gy


def total_variation(x: Tensor, eps: float = 1e-6) -> Tensor:
    """Smoothed isotropic total variation, summed over the batch."""
    # ------------------------------------------------------------------
    # ------------------------------------------------------------------
    # TODO(students) [8/20]: the smoothed isotropic TV functional.
    #
    # `_grad(x)` gives the two forward differences. Sum the gradient magnitude
    # sqrt(gx^2 + gy^2 + eps^2) over every pixel; return a scalar.
    #
    # The eps inside the root is what keeps it differentiable at zero. Summing
    # |gx| + |gy| instead is *anisotropic* TV, a legitimate but different
    # prior, which prefers grid-aligned edges and fails the isotropy test.
    #
    # Gate: pytest tests/shared/test_classical.py
    # ------------------------------------------------------------------
    gx, gy = _grad(x)
    return torch.sqrt(gx.square() + gy.square() + eps**2).sum()


def tv_grad(x: Tensor, eps: float = 1e-6) -> Tensor:
    """Gradient of the smoothed TV functional.

    The divergence of the normalised gradient field, computed as the negative
    adjoint of the forward-difference operator so that the discrete
    integration by parts is exact.
    """
    # ------------------------------------------------------------------
    # ------------------------------------------------------------------
    # TODO(students) [9/20]: the gradient of the smoothed TV functional.
    #
    # An adjoint again: TV is a function of *differences*, so its gradient at a
    # pixel has to collect every difference that pixel takes part in.
    #
    #   1. gx, gy = _grad(x);  mag = sqrt(gx^2 + gy^2 + eps^2)
    #   2. nx, ny = gx / mag, gy / mag
    #   3. Apply the negative adjoint of _grad to (nx, ny). Each difference
    #      gx[i] = x[i+1] - x[i] contributes -1 to pixel i and +1 to pixel
    #      i+1, so accumulate into zeros_like(x): both axes, both signs.
    #
    # Writing instead of accumulating loses one of the two contributions, and
    # the bug then hides in a single boundary row. You need not guess at this:
    # `total_variation` is differentiable, so autograd knows the answer, and
    # test_tv_gradient_matches_autograd makes exactly that comparison.
    #
    # Gate: pytest tests/shared/test_classical.py::test_tv_gradient_matches_autograd
    # ------------------------------------------------------------------
    gx, gy = _grad(x)
    mag = torch.sqrt(gx.square() + gy.square() + eps**2)
    nx, ny = gx / mag, gy / mag
    out = torch.zeros_like(x)
    out[..., :-1, :] -= nx[..., :-1, :]
    out[..., 1:, :] += nx[..., :-1, :]
    out[..., :, :-1] -= ny[..., :, :-1]
    out[..., :, 1:] += ny[..., :, :-1]
    return out


def tv_reconstruct(
    op: Operator,
    y: Tensor,
    lam: float = 0.01,
    n_iter: int = 200,
    eps: float = 1e-3,
    op_norm: float | None = None,
    x_init: Tensor | None = None,
    callback=None,
) -> Tensor:
    """Reconstruct by FISTA on the smoothed TV objective.

    Parameters
    ----------
    op:
        Any `Operator`. `MaskedFFT` gives you a compressed-sensing
        reconstruction; `ParallelBeamRadon` gives you TV-regularised CT.
    lam:
        Regularisation weight, and the knob that matters most. Sweep it on
        validation and report the value and how you chose it; an undertuned
        baseline makes the learned methods look better than they are.
    n_iter:
        FISTA iterations. Two hundred is usually plenty at these image sizes
        and costs seconds on a T4.
    eps:
        TV smoothing parameter. Smaller is closer to true TV but needs a
        smaller step size and more iterations.
    callback:
        Optional ``fn(k, x)`` called each iteration, for convergence plots.

    Notes
    -----
    Uses FISTA's momentum, which turns the O(1/k) convergence of plain gradient
    descent into O(1/k^2) for no extra cost per iteration. The step size is the
    reciprocal of the Lipschitz constant of the smooth objective's gradient:
    ``||A^H A||`` for the data term, plus ``8/eps`` for smoothed TV.
    """
    if op_norm is None:
        op_norm = estimate_operator_norm(
            op, tuple(op.A_adjoint(y).shape), device=y.device
        )

    # ------------------------------------------------------------------
    # ------------------------------------------------------------------
    # TODO(students) [10/20]: FISTA on the smoothed TV objective.
    #
    #   x = op.A_adjoint(y) if x_init is None else x_init.clone()
    #   z, t = x.clone(), 1.0
    #   step = 1.0 / (op_norm + lam * 8.0 / eps)
    #
    #   n_iter times:
    #     grad  = op.grad_datafit(z, y) + lam * tv_grad(z, eps)   # at z, not x
    #     x_new = z - step * grad
    #     t_new = (1 + sqrt(1 + 4*t*t)) / 2
    #     z     = x_new + ((t - 1) / t_new) * (x_new - x)
    #     x, t  = x_new, t_new
    #     callback(k, x), if one was given
    #
    #   return x, not z
    #
    # Nothing here may mention Fourier transforms or sinograms: `op` is the
    # only thing that knows which track you are on.
    #
    # The step is 1/L, which is why `op_norm` is a parameter: the CT
    # operator's norm is far from 1 and an MRI-tuned step diverges on it. Drop
    # the momentum and it still converges, at O(1/k) instead of O(1/k^2):
    # slow enough to miss your budget, and to leave the baseline that every
    # learned method is measured against under-converged.
    #
    # Gate: pytest tests/shared/test_classical.py
    # ------------------------------------------------------------------
    x = op.A_adjoint(y) if x_init is None else x_init.clone()
    z, t = x.clone(), 1.0
    step = 1.0 / (op_norm + lam * 8.0 / eps)
    for k in range(n_iter):
        grad = op.grad_datafit(z, y) + lam * tv_grad(z, eps)
        x_new = z - step * grad
        t_new = (1 + (1 + 4 * t * t)**0.5) / 2
        z = x_new + ((t - 1) / t_new) * (x_new - x)
        x, t = x_new, t_new
        if callback is not None:
            callback(k, x)
    return x

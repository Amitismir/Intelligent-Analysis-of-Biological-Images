"""A small U-Net.

The layers are built in `__init__`; you write the forward pass (TODO 11).

It is used in two places:

1. Rung three of both ladders, mapping the zero-filled image (MRI) or the FBP
   image (CT) to the target. This is a purely image-domain method: it never
   sees the measurements again, so nothing keeps it consistent with them, and
   it can produce plausible anatomy that isn't in the data. Comparing it with
   the unrolled network measures what data consistency adds.

2. The CNN inside each cascade of the unrolled network. There it is small
   (`base_channels=16`, two down levels), because there is one per cascade.

It has no attention, normalisation or residual blocks. If you add any, treat it
as a change to the baseline and show its effect with an ablation.
"""

from __future__ import annotations

import torch
import torch.nn as nn
from torch import Tensor

__all__ = ["UNet", "ConvBlock"]


class ConvBlock(nn.Module):
    """Two 3x3 convolutions with instance norm and LeakyReLU.

    Instance norm rather than batch norm: reconstruction batches are small on a
    T4, and batch statistics get unreliable and input-distribution-dependent
    exactly when you start varying the acceleration factor per sample.
    """

    def __init__(self, in_ch: int, out_ch: int, dropout: float = 0.0):
        super().__init__()
        layers: list[nn.Module] = [
            nn.Conv2d(in_ch, out_ch, 3, padding=1, bias=False),
            nn.InstanceNorm2d(out_ch),
            nn.LeakyReLU(0.2, inplace=True),
        ]
        if dropout > 0:
            layers.append(nn.Dropout2d(dropout))
        layers += [
            nn.Conv2d(out_ch, out_ch, 3, padding=1, bias=False),
            nn.InstanceNorm2d(out_ch),
            nn.LeakyReLU(0.2, inplace=True),
        ]
        self.body = nn.Sequential(*layers)

    def forward(self, x: Tensor) -> Tensor:
        return self.body(x)


class UNet(nn.Module):
    """Standard U-Net with skip connections.

    Parameters
    ----------
    in_ch, out_ch:
        Channel counts. Both are 1 here, since images are real
        and single-channel.
    base_channels:
        Width of the first level; doubles at each downsampling step.
    n_levels:
        Number of downsampling steps. Input spatial dims must be divisible by
        ``2 ** n_levels``; our packs are 160 and 128, so up to four levels is
        safe for MRI and three for CT.
    residual:
        If True the network predicts a *correction* to its input rather than
        the image itself. This matters more than it looks: the input is already
        a decent reconstruction, so learning the residual starts the model near
        a good solution and trains substantially faster, which is what makes
        the run fit inside the hour.
    """

    def __init__(
        self,
        in_ch: int = 1,
        out_ch: int = 1,
        base_channels: int = 32,
        n_levels: int = 3,
        dropout: float = 0.0,
        residual: bool = True,
    ):
        super().__init__()
        if n_levels < 1:
            raise ValueError(f"n_levels must be >= 1, got {n_levels}")
        self.residual = residual
        self.n_levels = n_levels

        chans = [base_channels * (2**i) for i in range(n_levels + 1)]

        self.down = nn.ModuleList()
        prev = in_ch
        for c in chans[:-1]:
            self.down.append(ConvBlock(prev, c, dropout))
            prev = c
        self.bottleneck = ConvBlock(prev, chans[-1], dropout)

        self.upsample = nn.ModuleList()
        self.up = nn.ModuleList()
        prev = chans[-1]
        for c in reversed(chans[:-1]):
            self.upsample.append(nn.ConvTranspose2d(prev, c, 2, stride=2))
            self.up.append(ConvBlock(c * 2, c, dropout))
            prev = c
        self.head = nn.Conv2d(prev, out_ch, 1)

        self.pool = nn.MaxPool2d(2)

    def forward(self, x: Tensor) -> Tensor:
        # ------------------------------------------------------------------
        # ------------------------------------------------------------------
        # TODO(students) [11/20]: the U-Net data flow.
        #
        # Every module exists already: self.down, self.pool, self.bottleneck,
        # self.upsample, self.up, self.head. What is missing is the path:
        #
        #   encoder:  for block in self.down:
        #                 x = block(x); save x as a skip; x = self.pool(x)
        #   bottom:   x = self.bottleneck(x)
        #   decoder:  zip(self.upsample, self.up, reversed(skips)):
        #                 x = upsample(x); x = block(cat([x, skip], dim=1))
        #   output:   out = self.head(x)
        #             return inp + out if self.residual else out
        #
        # Save each skip *before* pooling. Each decoder block was built for
        # 2*c input channels because it is fed the upsampled features
        # concatenated with its skip, so forgetting the cat raises a channel
        # mismatch right here. Trust that error.
        #
        # The residual branch is not cosmetic. The input is already a decent
        # reconstruction, so predicting a correction to it starts near a good
        # solution, which is the difference between fitting in the hour and not.
        #
        # Gate: pytest tests/shared/test_models.py
        # ------------------------------------------------------------------
        inp = x
        skips = []
        for block in self.down:
            x = block(x)
            skips.append(x)
            x = self.pool(x)
        x = self.bottleneck(x)
        for upsample, block, skip in zip(self.upsample, self.up, reversed(skips)):
            x = upsample(x)
            x = block(torch.cat([x, skip], dim=1))
        out = self.head(x)
        return inp + out if self.residual else out

    @property
    def n_params(self) -> int:
        return sum(p.numel() for p in self.parameters())

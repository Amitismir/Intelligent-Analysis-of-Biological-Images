"""The unrolled reconstruction network shared by both tracks.

The idea
--------
Classical iterative reconstruction solves

    min_x  1/2 ||A(x) - y||^2  +  R(x)

by alternating a gradient step that pulls the estimate toward the measured
data and a proximal step that pushes it toward what the regulariser `R`
considers plausible. Run for a few hundred iterations, this is TV
reconstruction or compressed sensing.

Unrolling truncates that loop to a few iterations and replaces the
hand-designed proximal step with a small CNN learned end to end::

    x_0     = A_adjoint(y)  (or FBP on CT, see engine.py)
    x_{k+1} = x_k - eta_k * A_adjoint(A(x_k) - y)     # data consistency
              + CNN_k(x_k)                            # learned prior

Every iteration calls the real forward operator, so the estimate is pulled
back toward the measurements at every step, while the plain U-Net sees them
only once. VarNet (MRI) and Learned Gradient Descent / Learned Primal-Dual
(CT) belong to this family.

Why these are called variational networks
-----------------------------------------
The objective above is a variational problem: the image minimises an energy
made of a data term and a regulariser. `classical.py` minimises it with a
hand-written `R` (total variation), iterated to convergence.

A variational network keeps the structure of that iteration (a
data-consistency step and a prior step, with the forward operator in every
step), fixes the number of steps, and learns the prior step. Hammernik et al.
(2018) did this for MRI by unrolling a fields-of-experts energy and training
its filters and potentials; E2E-VarNet later also learned coil sensitivities
in the same loop. The rungs relate like this:

    TV / CS   energy fully hand-designed, iterated to convergence
    VarNet    same energy structure, prior learned, iterations truncated
              and unrolled into a trainable graph
    U-Net     no energy, no operator after the first step: pure regression

The U-Net and the unrolled network learn from the same data, so the operator in
the loop is the one thing the unrolled network has that the U-Net does not.

Where the network acts
----------------------
Learned CT reconstruction is usually split by where the network acts:

- Image domain: reconstruct with FBP, then map the artefact-laden image to a
  clean one (FBPConvNet, residual U-Net denoisers). `ct_unet` and `mri_unet`
  are this.
- Projection domain: denoise the low-dose sinogram or fill in missing angles,
  then run FBP. Poisson noise is simpler in the sinogram, but small sinogram
  errors become streaks across the whole image.
- Dual domain: alternate between the two through the operator. Learned
  Primal-Dual (Adler & Oktem 2018) learns an update in measurement space and
  one in image space.

This network's CNN acts only in image space and reaches the sinogram through
the fixed `A` and `A_adjoint`, so it is learned gradient descent (Adler &
Oktem 2017), not Learned Primal-Dual. That keeps one architecture for both
tracks; say which one you built in your report. Projection-domain and
dual-domain methods are not built here.

One architecture, two modalities
--------------------------------
The network reaches the measurements only through `A` and `A_adjoint` and
works in image space in between, so the same code runs on both modalities.

Why the operator norm is estimated
----------------------------------
The modalities differ in scale. For our MRI operator `A^H A` is an orthogonal
projection, with eigenvalues in {0, 1}. For CT its norm grows with the number
of angles, so a step size that is stable on one diverges or stalls on the
other.

We estimate ``||A^H A||`` once by power iteration and divide the gradient step
by it. Then `eta ~ 1` is a sensible initialisation on both tracks without
re-tuning.
"""

from __future__ import annotations

import torch
import torch.nn as nn
from torch import Tensor

from ..operator import Operator, estimate_operator_norm
from .unet import UNet

__all__ = ["UnrolledNet"]


class UnrolledNet(nn.Module):
    """Unrolled gradient-descent network with a learned per-iteration prior.

    Parameters
    ----------
    n_cascades:
        Number of unrolled iterations. The dominant cost knob: runtime is
        roughly linear in this, since every cascade calls `A` and `A_adjoint`.
        Six is a reasonable default for MRI within the hour; the CT operator is
        heavier, so its configs use fewer.
    base_channels, n_levels:
        Size of the per-cascade CNN. Deliberately small, because there are
        `n_cascades` of them.
    shared_weights:
        If True, every cascade reuses one CNN. This makes the network a learned
        *fixed-point iteration* instead of a feed-forward stack and divides the
        parameters by `n_cascades`, often at little cost in accuracy. A good
        ablation.
    learn_step_size:
        If True the step sizes `eta_k` are learned. Fixing them is another
        cheap ablation.
    """

    def __init__(
        self,
        n_cascades: int = 6,
        base_channels: int = 16,
        n_levels: int = 2,
        shared_weights: bool = False,
        learn_step_size: bool = True,
        init_step_size: float = 1.0,
    ):
        super().__init__()
        if n_cascades < 1:
            raise ValueError(f"n_cascades must be >= 1, got {n_cascades}")
        self.n_cascades = n_cascades
        self.shared_weights = shared_weights

        def make_cnn() -> UNet:
            return UNet(
                in_ch=1,
                out_ch=1,
                base_channels=base_channels,
                n_levels=n_levels,
                residual=False,  # the cascade adds the residual itself
            )

        if shared_weights:
            shared = make_cnn()
            self.cnns = nn.ModuleList([shared] * n_cascades)
        else:
            self.cnns = nn.ModuleList([make_cnn() for _ in range(n_cascades)])

        steps = torch.full((n_cascades,), float(init_step_size))
        self.eta = nn.Parameter(steps, requires_grad=learn_step_size)

    # ------------------------------------------------------------------

    def data_consistency(
        self, x: Tensor, y: Tensor, op: Operator, eta: Tensor, op_norm: float
    ) -> Tensor:
        """One gradient step on the data-fidelity term.

        Returns the updated estimate ``x - (eta / ||A^H A||) * A^H(A(x) - y)``.
        """
        # ------------------------------------------------------------------
        # ------------------------------------------------------------------
        # TODO(students) [12/20]: the data-consistency step.
        #
        # Step against the data-fidelity gradient:
        #     x - (eta / op_norm) * A^H(A(x) - y)
        # `op.grad_datafit(x, y)` gives you A^H(A(x) - y) in one call.
        #
        # Get the sign right. Stepping the wrong way makes the loss climb
        # steadily rather than blow up, which is a slow and demoralising way to
        # lose twenty minutes of your GPU hour.
        #
        # Gate: pytest tests/shared/test_dc.py
        # ------------------------------------------------------------------
        return x - (eta / op_norm) * op.grad_datafit(x, y)

    def forward(
        self,
        y: Tensor,
        op: Operator,
        x_init: Tensor | None = None,
        op_norm: float | None = None,
    ) -> Tensor:
        """Reconstruct an image from measurements `y` under operator `op`.

        Parameters
        ----------
        y:
            Measurements. Modality-specific shape; see the operator's docstring.
        op:
            The forward operator. Passed per call rather than stored on the
            module, so that a *single trained model* can be evaluated under
            acceleration factors or angle counts it never saw during training.
            That is what makes the generalisation sweeps possible.
        x_init:
            Starting image. Defaults to ``A_adjoint(y)``. `engine.reconstruct`
            passes the FBP image on the CT track, because the unfiltered
            backprojection is blurred and on a much larger intensity scale.
        op_norm:
            Precomputed ``||A^H A||``. Estimated on the fly if omitted, but pass
            it explicitly in training loops, where recomputing it every step
            would be pure waste.
        """
        # ------------------------------------------------------------------
        # ------------------------------------------------------------------
        # TODO(students) [13/20]: the unrolled cascade.
        #
        #   1. x = x_init if given, else op.A_adjoint(y).
        #   2. If op_norm is None, estimate it once *before* the loop:
        #      estimate_operator_norm(op, x.shape, device=x.device)
        #   3. for k in range(self.n_cascades):
        #          x = self.data_consistency(x, y, op, self.eta[k], op_norm)
        #          x = x + self.cnns[k](x)
        #
        # Four bugs people actually ship: eta[0] instead of eta[k]; cnns[0]
        # instead of cnns[k]; `x = cnn(x)` instead of `x + cnn(x)` (the
        # per-cascade U-Nets are built residual=False because the cascade adds
        # it); and detaching something, since gradients must flow back through
        # every call to A and A_adjoint.
        #
        # Note what is absent: any mention of Fourier transforms or sinograms.
        # `op` is an argument rather than state, which is what lets one trained
        # model be evaluated under geometries it never saw.
        #
        # Gate: pytest tests/shared/test_models.py
        # ------------------------------------------------------------------
        x = op.A_adjoint(y) if x_init is None else x_init
        if op_norm is None:
            op_norm = estimate_operator_norm(op, tuple(x.shape), device=x.device)
        for k in range(self.n_cascades):
            x = self.data_consistency(x, y, op, self.eta[k], op_norm)
            x = x + self.cnns[k](x)
        return x

    @property
    def n_params(self) -> int:
        if self.shared_weights:
            return self.cnns[0].n_params + self.eta.numel()
        return sum(p.numel() for p in self.parameters())

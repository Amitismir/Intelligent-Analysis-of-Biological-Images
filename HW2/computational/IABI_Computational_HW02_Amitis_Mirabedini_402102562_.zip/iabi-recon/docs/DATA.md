# Dataset packs: provenance and licensing

Two packs, roughly 100 MB each, holding clean ground-truth images only. No
k-space, no sinograms: measurements are simulated at training time
(`src/iabi/ct/simulate.py`).

That is a deliberate design choice, not a storage saving. It is what makes
acceleration factor and projection-angle count into free experimental knobs, and
it is the reason the generalisation sweeps fit inside a student GPU budget at
all.

## MRI pack: `aluk4/iabi-mri-brain`

| | |
|---|---|
| Source | [IXI Dataset](http://brain-development.org/ixi-dataset/), T2-weighted volumes |
| Licence | CC BY-SA 3.0 |
| Contents | 1500 train / 200 val / 200 test slices, 160×160, float16 |
| Derivation | central 30% of slices per subject, centre-cropped, area-resized, per-slice normalised to [0,1] |
| Split | by subject, see below |

Collected across three London hospitals (Hammersmith 3T Philips, Guy's 1.5T
Philips, Institute of Psychiatry 1.5T GE) from ~600 healthy subjects.

The IXI project's own download server is returning 403. Every file under
`biomedic.doc.ic.ac.uk/brain-development/downloads/IXI/` is refused, including
the small `IXI.xls`, so it is a server-side block rather than a rate limit. The
pack was therefore built from a mirror of the original tarball on the Hub,
[`Santhosh1884/IXI-Datasets`](https://huggingface.co/datasets/Santhosh1884/IXI-Datasets),
file `IXI-T2.tar`.

That mirror was checked before use, not merely trusted: it is 3.85 GB, matching
the published size of `IXI-T2.tar`, and its first tar member is
`IXI002-Guys-0828-T2.nii.gz`, which is the first volume of the real IXI T2 set.
If the upstream host comes back, prefer it. The licence and attribution are
owed to the IXI project either way, not to the mirror.

Share-alike propagates: the derived pack must itself carry CC BY-SA 3.0.
Attribute the IXI project in the dataset card.

Note the pack holds magnitude images. Real MRI is complex-valued; our
simulated forward operator therefore starts from a real-valued object, which is
one of the simplifications described in `src/iabi/mri/operator.py`.

## CT pack: `aluk4/iabi-ct-slices`

| | |
|---|---|
| Source | [LoDoPaB-CT](https://doi.org/10.5281/zenodo.3384092), ground-truth archives only |
| Licence | CC BY 4.0 |
| Contents | 2000 train / 250 val / 250 test slices, 128×128, float16 |
| Derivation | subsampled across ground-truth files, centre-cropped, area-resized, per-slice normalised to [0,1] |
| Split | LoDoPaB's own, which is patient-disjoint, see below |

LoDoPaB-CT's ground-truth images are themselves derived from the LIDC/IDRI chest
CT collection, reconstructed to 362×362.

Only the ground-truth archives are touched: `ground_truth_train.zip`,
`ground_truth_validation.zip` and `ground_truth_test.zip`, 19 GB of the
dataset's ~55 GB. The observation archives are the other 36 GB and we do not
need them, because we simulate our own sinograms at whatever angle count the
experiment calls for.

Nor is all 19 GB downloaded. We need about 2500 slices out of 35,840, so the
builder reads the three Zenodo zips over HTTP range requests and pulls only the
archive members it uses: 28 of 336, about 1.6 GB. Members are picked spread
across each archive rather than as a contiguous run, so the pack covers many
patients instead of a handful.

Attribute both LoDoPaB-CT and LIDC/IDRI in the dataset card.

## The CT pack is masked to a circular field of view

Our projector rotates the image and sums columns, so at oblique angles the
corners of the square leave the frame and are never integrated. Corner-only
content loses 75% of its mass at the worst angle, while a disc inside the
circle conserves it to 0.1%.

Leaving that anatomy in the ground truth would charge every method for failing
to reconstruct something no method could see, over the 23% of each image that
lies outside the disc. Masking it moved the FBP baseline from 17.6 dB to
21.4 dB, so 3.8 dB of that score was never about the reconstruction method at
all. The CT builder therefore zeroes the corners, which is also how a clinical
CT console displays a reconstruction: on a circular field of view, not a square
one.

The MRI pack needs none of this. Its operator is an FFT over the whole square,
so every pixel is measured.

## Empty slices are dropped

Both sources contain all-air slices: LoDoPaB ships entirely zero ground-truth
images, and the ends of a head scan are empty. The builder removes them.

They are worth removing for three separate reasons. They teach a network that
reconstruction is trivial. They give meaningless PSNRs, since a perfect score
on an empty image means nothing. And after per-slice normalisation, every
constant slice becomes the *same* all-zero image, so one of them landing in two
splits looks exactly like a patient leak when it is nothing of the sort.

The cut is at a standard deviation of 0.02, which sits inside a clean gap:
degenerate slices measure below 0.001 and real anatomy starts around 0.05.

## Splits are disjoint by patient, not by slice

Both packs are split on the *subject*, and this is the detail most worth
knowing if you are going to quote a test number.

Adjacent slices of one subject are nearly the same image. Collect every slice,
shuffle, and cut into train/val/test, which is the obvious way to build a pack,
and a near-duplicate of almost every test slice ends up in the training set. A
network then scores well on test partly by having memorised it, and the figure
you report is not a generalisation figure.

So: the MRI pack assigns whole IXI subjects to a split before extracting any
slices, keyed on the subject id in the filename (`IXI002-Guys-0828-T2` →
`IXI002`). The CT pack takes its three splits from LoDoPaB-CT's three archives,
which are already patient-disjoint and are the split the benchmark itself uses.
Neither builder ever shuffles across a split boundary.


## Offline fallback

If a pack cannot be downloaded, `load_pack` falls back to synthetic ellipse
phantoms and prints a loud warning. This keeps `pytest` and `--smoke` working
with no network, which matters for a first-run experience on a fresh Colab
runtime.

Those phantoms are far too easy: piecewise-constant ellipses are exactly what
total variation is designed for, so TV will look implausibly good on them. If
you are reporting numbers computed on synthetic phantoms, your pack did not
download. Check the loader's output.

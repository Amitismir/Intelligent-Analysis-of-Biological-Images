# IABI: Reconstruction from Incomplete Measurements

Code for the reconstruction assignment: low-dose CT and accelerated MRI.

You fill in twenty TODOs, from the scanner physics to the training loop, then
run a ladder of baselines on both tracks and analyse the results. Each notebook
finishes in under an hour on a Colab T4.

## The setup

Both tracks solve the same problem:

```
minimise_x   || A(x) − y ||²   +   R(x)
             \__________/          \__/
              stay faithful to     look like
              the measurements     a real image
```

Everything specific to the scanner is inside the operator `A`. The solver, the
networks, the metrics and the training loop only call `A` and `A_adjoint`, so
the same code runs on both modalities.

| | MRI | CT |
|---|---|---|
| `A(x)` | sample a subset of 2D Fourier coefficients | integrate along lines through the body |
| `y` | undersampled k-space | a sinogram |
| dose/time knob | acceleration factor `R` | number of projection angles |
| `A_adjoint(y)` | zero-filled reconstruction (aliased) | backprojection (blurred) |

Note the last row: the adjoint is not the inverse, and both give a poor image.

## Quickstart (Colab)

Upload `iabi-recon.zip` with Colab's file pane (folder icon on the left, then
the upload button), then:

```python
!unzip -q -o iabi-recon.zip -d /content
%cd /content/iabi-recon
!pip install -q -e .
!python -m iabi.doctor              # what's done, what's next
!pytest tests/ -q -m "not slow"     # fails until you fill the TODOs
```

The first cell of each notebook does this for you, so you can just open
`colab/01_mri_track.ipynb` and run it from the top.

A runtime restart wipes the filesystem, including your edits. Keep a copy in
Drive.

## What you implement

```
src/iabi/
  mri/        3 TODOs   what an MRI scanner measures
  ct/         4 TODOs   what a CT scanner measures
  shared/    13 TODOs   the solver, networks, metrics and training, for both
```

Nothing in `shared/` mentions Fourier transforms or sinograms; it reaches the
physics only through the `Operator` interface. Configs, checkpointing,
plotting, the `Operator` base class, `UNet.__init__` and the CT backprojection
geometry are given.

Do stage 1, then stages 3 to 6: that is the MRI track, and
`colab/01_mri_track.ipynb` follows it. Then do stage 2 for CT. The shared code
is reused unchanged.

Some tests under `tests/shared` also run on the CT operator and carry the `ct`
marker. Until stage 2 is done, add `-m "not ct"` to those gates, as the MRI
notebook does.

`python -m iabi.doctor` shows which TODOs are done and which one is next.

### Stage 1: MRI operator (`iabi/mri/`)

| # | Where | What |
|---|---|---|
| 1 | `mri/masks.py` | `cartesian_mask`: which k-space lines you acquire |
| 2 | `mri/operator.py` | `A`, the masked FFT |
| 3 | `mri/operator.py` | `A_adjoint`, derived in the docstring |

Gate: `pytest tests/mri tests/test_adjoint.py -k mri`

Run the adjoint test first. The `shared/operator.py` docstring says why it
matters more than the others.

### Stage 2: CT operator (`iabi/ct/`)

| # | Where | What |
|---|---|---|
| 4 | `ct/operator.py` | `A`, parallel-beam forward projection |
| 5 | `ct/operator.py` | `A_adjoint`, backprojection |
| 6 | `ct/simulate.py` | `simulate_ct`: Beer-Lambert, Poisson counting, log |
| 7 | `ct/filters.py` | `ramp_filter`, the *filtered* in filtered backprojection |

Gate: `pytest tests/ct tests/test_adjoint.py`

### Stage 3: classical reconstruction (`iabi/shared/classical.py`)

| # | Where | What |
|---|---|---|
| 8 | `shared/classical.py` | `total_variation`, the prior |
| 9 | `shared/classical.py` | `tv_grad`, its gradient |
| 10 | `shared/classical.py` | `tv_reconstruct`: FISTA, used as CS on MRI and TV on CT |

Gate: `pytest tests/shared/test_classical.py -m "not ct"`

### Stage 4: learned reconstruction (`iabi/shared/models/`)

| # | Where | What |
|---|---|---|
| 11 | `shared/models/unet.py` | `UNet.forward`: encoder, skips, decoder |
| 12 | `shared/models/unrolled.py` | `data_consistency`, one gradient step on the data term |
| 13 | `shared/models/unrolled.py` | `UnrolledNet.forward`, the unrolled cascade |

Gate: `pytest tests/shared/test_models.py tests/shared/test_dc.py -m "not ct"`

### Stage 5: metrics (`iabi/shared/metrics.py`)

| # | Where | What |
|---|---|---|
| 14 | `shared/metrics.py` | `psnr`, `nmse` |
| 15 | `shared/metrics.py` | `ssim`, with local statistics |
| 16 | `shared/metrics.py` | `edge_preservation`, catches "looks cleaner, is blurrier" |

Gate: `pytest tests/shared/test_metrics.py`

Read the note at the top of `shared/metrics.py` before drawing conclusions
from these numbers.

### Stage 6: data and training (`iabi/shared/`)

| # | Where | What |
|---|---|---|
| 17 | `shared/data/datasets.py` | `SliceDataset.__getitem__`, one slice, augmented |
| 18 | `shared/data/datasets.py` | `make_loader`: batching, shuffling, workers |
| 19 | `shared/training.py` | `train_one_epoch`: forward, loss, backward, step |
| 20 | `shared/training.py` | `validate`, scoring without gradients |

Gate: `pytest tests/shared/test_training.py`

Plain PyTorch, nothing specific to reconstruction.

## Running experiments

```bash
# 1. About two minutes; runs every code path the real run uses.
python -m iabi.train --config src/iabi/configs/mri_unrolled.yaml --smoke

# 2. The real run.
python -m iabi.train --config src/iabi/configs/mri_unrolled.yaml

# 3. Score it.
python -m iabi.eval --config src/iabi/configs/mri_unrolled.yaml \
    --checkpoint runs/mri_unrolled/checkpoint.pt

# 4. Ablation: the same model at other accelerations. Writes
#    runs/mri_unrolled/sweep_acceleration.json, next to results.json.
python -m iabi.eval --config src/iabi/configs/mri_unrolled.yaml \
    --checkpoint runs/mri_unrolled/checkpoint.pt \
    --sweep acceleration=2,4,6,8,10,12
```

Run `--smoke` first. A shape error found there costs two minutes instead of a
training run.

## The baseline ladder

**MRI**: `mri_zerofilled` → `mri_cs` → `mri_unet` → `mri_unrolled`

**CT**: `ct_fbp` → `ct_tv` → `ct_unet` → `ct_unrolled`

| rung | prior | trained? | sees measurements |
|---|---|---|---|
| zero-filled / FBP | none | no | once, analytically |
| CS / TV | hand-designed | no | every iteration |
| U-Net (on CT: FBP + U-Net) | learned | yes | once |
| unrolled | learned | yes | every cascade |

The main comparison is U-Net vs unrolled. The U-Net sees the measurements once,
through its input (the zero-filled image on MRI, the FBP image on CT), and
nothing stops it from adding structure that isn't in the data. The unrolled
network goes back to the measurements at every cascade, and it should win with
about a third of the U-Net's parameters.

Expected order: zero-filled < CS < U-Net < unrolled on MRI, and
FBP < TV < unrolled on CT, with FBP + U-Net above FBP and below unrolled. Where
FBP + U-Net lands against TV is for you to find out (see the CT note below the
reference numbers). If your order breaks, find out why. It is usually an
undertuned classical baseline or a bug, and explaining it is worth more than a
clean table.

### Reference numbers

Training-free rungs on the test split, with the configs as shipped. Use them
as a correctness check: if your `mri_zerofilled` is far from 23.5 dB, the bug
is in your operator or your metrics.

| rung | PSNR | SSIM |
|---|---|---|
| `mri_zerofilled` | 23.54 ± 1.04 dB | 0.706 |
| `mri_cs` | 24.06 ± 1.16 dB | 0.768 |
| `ct_fbp` | 21.37 ± 2.34 dB | 0.388 |
| `ct_tv` | 28.36 ± 1.93 dB | 0.770 |

There are no numbers for the learned rungs, because they depend on training
length and seed.

Two things in this table look like bugs but aren't:

- CS gains only about 0.5 dB over zero-filled on MRI. At 6x random Cartesian
  undersampling of brain images the aliasing is spread out and noise-like, and
  TV doesn't remove much of it. SSIM improves more (0.706 to 0.768), so the two
  metrics disagree about how much better it is.
- TV gains about 7 dB over FBP on CT. FBP at 60 angles is weak, and the CT
  images are masked to a circular field of view, so the background is exactly
  zero, which TV reconstructs perfectly.

## Ablation and error analysis

`--sweep` scores one trained model at settings around the one it was trained
at: accelerations on MRI, angle counts on CT. The results go to
`runs/<name>/sweep_<key>.json` and leave `results.json` alone. Plot them with
`viz.sweep_plot` and mark the setting the model was trained at.

`viz.worst_cases` returns the worst test slices by a metric. Use those indices
with `comparison_grid` and `error_maps` for your failure analysis, rather than
picking failures by eye.

A small improvement in an average metric is not a finding by itself. "PSNR
went from 31.2 to 31.4 dB" needs to come with where the method helps and where
it hurts.

## Background: where each topic is explained

Each topic below names the file that explains it. Topics marked "not built"
are not implemented here, and the linked section says why.

**CT**

| Topic | Explained in | Runs? |
|---|---|---|
| The Radon transform | `ct/operator.py` module docstring | TODO 4 |
| Sinogram formation | `ct/operator.py`, then `ct/simulate.py` for the noise | TODO 4, 6 |
| Filtered Back Projection | `ramp_filter` and `fbp` docstrings, `ct/operator.py` | TODO 7 |
| Iterative CT reconstruction | `shared/classical.py` header and `tv_reconstruct` | TODO 10 |
| Total Variation regularization | `shared/classical.py` module docstring, incl. staircasing | TODO 8, 9 |
| Sparse-angle CT | `ct/angles.py` module docstring | `--sweep angles=…` |
| Low-dose CT | `ct/simulate.py` | TODO 6 |
| Image-domain deep learning | `shared/models/unet.py` module docstring | TODO 11 |
| Projection-domain deep learning | `shared/models/unrolled.py` § *Where the network acts* | not built |
| Learned Primal-Dual | `shared/models/unrolled.py` § *Where the network acts* | partly: you build learned gradient descent |

**MRI**

| Topic | Explained in | Runs? |
|---|---|---|
| MRI image formation | `mri/operator.py` § *Where the signal comes from* | background |
| Fourier transformation in MRI | `mri/operator.py`, and the `fft2c`/`ifft2c` helpers | given |
| k-space representation | `mri/operator.py` and `mri/masks.py` | TODO 1, 2 |
| Cartesian sampling | `mri/masks.py` module docstring | TODO 1 |
| Non-Cartesian sampling | `mri/masks.py` § *Cartesian is not the only option* | not built |
| Undersampling and aliasing | `mri/masks.py`, then `tests/mri/test_masks.py` | TODO 1, 3 |
| Parallel imaging | `mri/operator.py` § *Single coil and parallel imaging* | not built |
| Compressed sensing | `shared/classical.py`, with the incoherence argument in `mri/masks.py` | TODO 10 |
| Data consistency | `shared/models/unrolled.py`, and `tests/shared/test_dc.py` | TODO 12 |
| Learned MRI reconstruction | `shared/models/unet.py` and `shared/models/unrolled.py` | TODO 11, 13 |
| Variational reconstruction networks | `shared/models/unrolled.py` § *Why these are called variational networks* | TODO 13 |

## Before writing your report

You reconstruct from simulated single-coil k-space and from sinograms made with
our own projector, at 160×160 and 128×128, on a few thousand slices, in about
an hour of T4 time. Published MRI results use multi-coil raw k-space, and
published CT results use full-resolution sinograms with hundreds of angles;
both train for days on GPU clusters. Your numbers are not comparable to
theirs, so if you quote any, say so.

What you can show is the behaviour:

- the order of the ladder on both tracks (see above);
- that the unrolled network beats the U-Net because the operator is in the
  loop;
- the failure modes: coherent aliasing from equispaced masks, noise-like
  artefacts from random ones, streaks from dense structures at low angle
  counts, and TV staircasing at high regularisation.

Describe the setup in one paragraph early in the report, for example:

> We reconstruct from retrospectively undersampled single-coil k-space
> simulated from IXI magnitude images at 160×160, and from sinograms generated
> with our own parallel-beam projector under a Poisson noise model with the
> LoDoPaB-CT photon count I₀ = 4096. The unrolled network is learned gradient
> descent: its CNN works in image space only.

## Data

Two packs of clean images, about 100 MB each, downloaded from the Hugging Face
Hub on first use. Measurements are simulated on the fly, so acceleration and
angle count can be changed freely.

| Track | Source | Licence |
|---|---|---|
| MRI | [IXI](https://brain-development.org/ixi-dataset/) brain MR | CC BY-SA 3.0 |
| CT | [LoDoPaB-CT](https://doi.org/10.5281/zenodo.3384092) ground truth | CC BY 4.0 |

Provenance and the build script: [`docs/DATA.md`](docs/DATA.md).

If a pack can't be downloaded, the loader falls back to synthetic ellipse
phantoms and prints a warning, so tests and `--smoke` still work offline. Don't
report numbers on the phantoms.

## Layout

```
src/iabi/
  mri/         masks.py ★  operator.py ★  simulate.py          ← stage 1
  ct/          operator.py ★  filters.py ★  simulate.py ★  angles.py
                                                              ← stage 2
  shared/      operator.py        the interface both tracks implement
               classical.py ★     TV + FISTA: CS for MRI, TV for CT
               models/            unet.py ★  unrolled.py ★
               metrics.py ★       PSNR, NMSE, SSIM, edge preservation
               data/              packs.py  datasets.py ★
               training.py ★      one epoch, and validation
               simulate.py        picks the simulator for your operator
  train.py  eval.py  doctor.py  engine.py  config.py  viz.py  configs/
                                            ← command line and plumbing, given

tests/         mri/  ct/  shared/     mirror the above
               test_adjoint.py   the adjoint check, both operators
               test_smoke.py     end to end, both tracks
colab/         01_mri_track  02_ct_track
```

★ = contains a TODO.

The only file in `shared/` that imports `mri/` or `ct/` is
`shared/simulate.py`, which picks the simulator by operator type.

## Environment notes (T4)

- fp32 throughout. The T4 has no bf16, and fp16 autocast doesn't work well
  with complex tensors.
- No `torch.compile`; its overhead is a large fraction of a 20-minute run.
- Keep the pack in `/content`, not Drive. Save checkpoints to Drive at the end.

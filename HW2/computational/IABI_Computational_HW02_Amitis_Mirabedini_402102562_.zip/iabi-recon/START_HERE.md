# IABI reconstruction submission

The submission includes all 20 implemented tasks, all eight test evaluations,
and both trained unrolled-model sweeps. The accompanying PDF contains the
test tables, reconstruction panels, absolute error maps, and error analysis.

## Find the saved results

- `runs/<method>/config.yaml` and `runs/<method>/results.json` record the
  configuration and seed for each test result.
- `runs/mri_unrolled/sweep_acceleration.json` and
  `runs/ct_unrolled/sweep_angles.json` contain the acquisition sweeps.
- `runs/mri_cs/validation_tv_lambda.json` records the eight MRI CS candidates.
  Mean validation PSNR selected 0.002 on 64 real IXI validation slices with
  seed 1. The selected baseline was then evaluated on the 200 held-out test
  slices with seed 0.
- `verification/colab_pytest.txt` records the original test suite result.

## Run the code

From the project root:

```bash
pip install -e '.[dev]'
python -m iabi.doctor
pytest tests/ -q
python scripts/tune_mri_cs.py
```

The tuning script requires the real IXI validation pack and writes its
validation table. The README documents model training and test commands.
Check the data loader messages before using any results in the report.

Learned-model checkpoint files and dataset caches are omitted from this
submission. Keep the original checkpoints separately to replay the learned
evaluations and generate new comparison figures.

## Colab evidence

The MRI and CT notebooks preserve the executed setup, checks, training,
evaluation, and comparison outputs from the submitted Colab runs. The MRI
notebook also preserves its executed unrolled sweep. The CT notebook export
ends with the executed FBP sweep. The required CT unrolled sweep was run
after that export and is supplied in `runs/ct_unrolled/sweep_angles.json`.
The added CT sweep cell documents the command for rerunning it with the
checkpoint from the working backup.

The accompanying report uses the saved Colab test metrics and sweep results.
Its reconstruction panels were regenerated from those checkpoints.

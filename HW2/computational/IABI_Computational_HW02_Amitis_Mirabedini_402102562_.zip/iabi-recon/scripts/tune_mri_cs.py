"""Select the MRI CS TV weight using only the IXI validation split."""
import dataclasses
import json
from pathlib import Path

from iabi.config import Config
from iabi.engine import get_device, set_seed
from iabi.eval import evaluate
from iabi.shared.data import SliceDataset, make_loader

CANDIDATES = (0.0005, 0.001, 0.002, 0.003, 0.0045, 0.006, 0.009, 0.012)


def main():
    cfg = Config.from_yaml(Path("src/iabi/configs/mri_cs.yaml"))
    device = get_device()
    dataset = SliceDataset("mri", "val", limit=cfg.val_limit, allow_synthetic=False)
    loader = make_loader(dataset, cfg.batch_size, shuffle=False, num_workers=0)
    entries = []
    for weight in CANDIDATES:
        candidate = dataclasses.replace(cfg, tv_lambda=weight, seed=cfg.seed + 1)
        set_seed(candidate.seed)
        scores = evaluate(candidate, None, device, loader)
        entry = {"tv_lambda": weight, "metrics": scores["metrics"]}
        entries.append(entry)
        print(f"lambda={weight:g}, validation PSNR={scores['metrics']['psnr']['mean']:.5f} dB", flush=True)
    best = max(entries, key=lambda entry: (entry["metrics"]["psnr"]["mean"], -entry["tv_lambda"]))
    result = {
        "config": "src/iabi/configs/mri_cs.yaml",
        "dataset": "aluk4/iabi-mri-brain/val.npz",
        "split": "val",
        "seed": cfg.seed + 1,
        "n_validation": len(dataset),
        "batch_size": cfg.batch_size,
        "tv_iters": cfg.tv_iters,
        "tv_eps": cfg.tv_eps,
        "acquisition": scores["acquisition"],
        "selection_metric": "mean validation PSNR; ties choose the smaller TV weight",
        "selected_tv_lambda": best["tv_lambda"],
        "candidates": entries,
    }
    output = Path("runs/mri_cs/validation_tv_lambda.json")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(result, indent=2) + "\n")
    print(f"Selected lambda={best['tv_lambda']:g} by validation PSNR")


if __name__ == "__main__":
    main()

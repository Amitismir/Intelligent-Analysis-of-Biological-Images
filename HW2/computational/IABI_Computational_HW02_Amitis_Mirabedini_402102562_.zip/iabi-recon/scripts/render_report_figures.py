"""Replay selected test slices from the saved configs and checkpoints."""
import json
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import torch

from iabi.config import Config
from iabi.engine import get_device
from iabi.shared.metrics import psnr, ssim
from iabi.viz import comparison_grid, error_maps, sweep_plot, worst_cases
from run_homework import LADDERS, replay


def main():
    device = get_device()
    output = Path("outputs/report_figures")
    scores = {}
    for track, methods in LADDERS.items():
        unrolled = Path("runs") / methods[-1]
        worst, _ = worst_cases(unrolled / "results.json", k=1)[0]
        indices = sorted({0, worst})
        predictions = {}
        for name in methods:
            cfg = Config.from_yaml(Path("runs") / name / "config.yaml")
            predictions[name], references = replay(cfg, indices, device, tolerance=None if track == "ct" else .005)
        for index in indices:
            panels = {name: results[index] for name, results in predictions.items()}
            reference = references[index]
            scores[f"{track}-{index}"] = {
                name: {"psnr": float(psnr(panel, reference)), "ssim": float(ssim(panel, reference))}
                for name, panel in panels.items()
            }
            plt.close(comparison_grid(
                {**panels, "ground truth": reference},
                save=output / f"{track}_{index}.png",
            ))
            plt.close(error_maps(panels, reference, save=output / f"{track}_{index}_errors.png"))
        key = "acceleration" if track == "mri" else "angles"
        acquisition = json.loads((unrolled / "results.json").read_text())["acquisition"]
        training_setting = acquisition["acceleration" if track == "mri" else "n_angles"]
        plt.close(sweep_plot(
            {"unrolled": unrolled / f"sweep_{key}.json"},
            trained_at={"unrolled": training_setting},
            save=output / f"{track}_sweep.png",
        ))

    (output / "panel_metrics.json").write_text(json.dumps(scores, indent=2) + "\n")


if __name__ == "__main__":
    main()

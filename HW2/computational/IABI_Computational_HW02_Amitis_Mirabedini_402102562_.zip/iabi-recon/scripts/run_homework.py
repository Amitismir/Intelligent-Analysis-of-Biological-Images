"""Run real-data baselines; add --full for training and required sweeps."""
import argparse
import dataclasses
import json
import textwrap
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
import torch
from iabi.config import Config
from iabi.engine import build_model, build_operator, get_device, operator_norm, reconstruct, set_seed
from iabi.eval import evaluate, load_checkpoint
from iabi.shared.data import SliceDataset, make_loader
from iabi.shared.simulate import simulate
from iabi.shared.metrics import psnr
from iabi.train import train
from iabi.viz import comparison_grid, error_maps, sweep_plot, worst_cases

LADDERS = {'mri': ['mri_zerofilled','mri_cs','mri_unet','mri_unrolled'],
           'ct': ['ct_fbp','ct_tv','ct_unet','ct_unrolled']}


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2))


def page(pdf, title, paragraphs):
    fig = plt.figure(figsize=(8.27,11.69))
    fig.text(.08,.94,title,fontsize=15,weight='bold',va='top')
    y = .88
    for text in paragraphs:
        lines = textwrap.wrap(text,88)
        height = .022*len(lines)+.025
        if y-height < .06:
            pdf.savefig(fig); plt.close(fig)
            fig = plt.figure(figsize=(8.27,11.69))
            fig.text(.08,.94,title+' (continued)',fontsize=15,va='top')
            y = .88
        fig.text(.08,y,'\n'.join(lines),fontsize=10,va='top',linespacing=1.4)
        y -= height
    pdf.savefig(fig); plt.close(fig)


@torch.no_grad()
def replay(cfg, indices, device, *, tolerance=.005):
    set_seed(cfg.seed)
    ds = SliceDataset(cfg.track,'test',limit=cfg.test_limit,allow_synthetic=False)
    loader = make_loader(ds,cfg.batch_size,shuffle=False,num_workers=0)
    directory = Path(cfg.out_dir)/cfg.name
    model = load_checkpoint(cfg,directory/'checkpoint.pt',device) if cfg.is_trainable else None
    if model is not None: model.eval()
    gen = torch.Generator().manual_seed(cfg.seed)
    values = json.loads((directory/'results.json').read_text())['per_sample']['psnr']
    predictions, refs, count = {}, {}, 0
    for x in loader:
        x = x.to(device)
        op = build_operator(cfg,x.shape[-1],len(x),device,gen)
        norm = operator_norm(op,tuple(x.shape),device)
        kwargs = {'noise_sigma':cfg.noise_sigma} if cfg.track=='mri' else {'photons':cfg.photons,'mu_scale':cfg.mu_scale}
        y = simulate(x,op,generator=gen,**kwargs)
        chosen = [i for i in indices if count<=i<count+len(x)]
        if chosen:
            pred = reconstruct(cfg,model,y,op,norm).clamp(0,1)
            for i in chosen:
                p, ref = pred[i-count:i-count+1], x[i-count:i-count+1]
                difference = float(psnr(p, ref)) - values[i]
                if tolerance is not None and abs(difference) > tolerance:
                    raise RuntimeError(f'Seeded replay mismatch: {cfg.name}, index {i}')
                predictions[i],refs[i] = p.cpu(),ref.cpu()
        count += len(x)
        if count>max(indices): break
    return predictions,refs


def report(device):
    directory = Path('report'); directory.mkdir(exist_ok=True)
    figures = directory/'figures'; figures.mkdir(exist_ok=True)
    results = {name:json.loads(Path('runs',name,'results.json').read_text())
               for names in LADDERS.values() for name in names if Path('runs',name,'results.json').exists()}
    missing = [name for names in LADDERS.values() for name in names if name not in results]
    missing_sweeps = [str(Path('runs',name,filename)) for name,filename in
                      [('mri_unrolled','sweep_acceleration.json'),('ct_unrolled','sweep_angles.json')]
                      if not Path('runs',name,filename).exists()]
    save(directory/'status.json',{'missing_results':missing,'missing_sweeps':missing_sweeps})
    with PdfPages(directory/'homework-report.pdf') as pdf:
        page(pdf,'MRI and CT reconstruction',[
            'DRAFT: experiments pending' if missing or missing_sweeps else 'Experiments available; review and add your interpretation before submission.',
            'Setup: retrospectively undersampled single-coil k-space simulated from IXI T2 magnitude images at 160x160. MRI uses symmetric random Cartesian masks, nominal R=6, center_fraction=0.08 and no added noise. CT uses 128x128 circularly masked LoDoPaB-CT ground truth, the supplied parallel-beam projector, 60 angles, 4096 photons and mu_scale=3.0. These are teaching simulations, not measured clinical acquisitions.',
            'All seeds are 0. Training packs contain 1500 MRI and 2000 CT slices; the default validation limit is 64. Test packs contain 200 MRI and 250 CT slices. Data are checked with synthetic fallback disabled. Results and complete configs are in runs/<method>/. Test evidence is in verification/colab_pytest.txt.',
            'Missing full methods: '+(', '.join(missing) or 'none')+'. Missing trained-model sweeps: '+(', '.join(missing_sweeps) or 'none')+'. Smoke runs are excluded from all report tables.',
            'Implementation: centered masked FFT and its real adjoint; chunked Radon projection and its exact interpolation transpose; Beer-Lambert/Poisson/log CT noise; zero-padded spatial ramp filtering; smoothed isotropic TV and FISTA; residual U-Net; learned gradient descent with a data-consistency step and additive CNN correction in every cascade.',
            'The supplied MRI budgets are 40 U-Net epochs versus 30 unrolled epochs; CT uses 15 each. Network capacities also differ. This comparison does not isolate the causal effect of data consistency. Soft DC followed by a CNN does not guarantee exact final measurement agreement.'])
        for track,names in LADDERS.items():
            rows = []
            for name in names:
                if name not in results:
                    rows.append([name]+['not run']*4); continue
                metrics = results[name]['metrics']
                rows.append([name]+[f"{metrics[k]['mean']:.4f} +/- {metrics[k]['std']:.4f}" for k in ['psnr','ssim','nmse','edge']])
            fig,ax = plt.subplots(figsize=(11.69,8.27)); ax.axis('off')
            ax.set_title(track.upper()+' test scores: mean +/- slice standard deviation')
            table = ax.table(cellText=rows,colLabels=['Method','PSNR (dB)','SSIM','NMSE','Edge correlation'],loc='center')
            table.auto_set_font_size(False); table.set_fontsize(9); table.scale(1,2)
            pdf.savefig(fig,bbox_inches='tight'); plt.close(fig)
            settings = []
            for name in names:
                cfg = Config.from_yaml(f'src/iabi/configs/{name}.yaml')
                model = build_model(cfg)
                params = sum(p.numel() for p in model.parameters()) if model is not None else 0
                settings.append(f'{name}: src/iabi/configs/{name}.yaml; seed={cfg.seed}; parameters={params:,}; '+
                    (f'epochs={cfg.epochs}, Adam lr={cfg.lr}, L1 loss, cosine scheduler.' if cfg.is_trainable else
                     f'TV lambda={cfg.tv_lambda}, eps={cfg.tv_eps}, iterations={cfg.tv_iters}.' if cfg.method=='tv' else 'no training.'))
            if names[2] in results and names[3] in results:
                delta = results[names[3]]['metrics']['psnr']['mean']-results[names[2]]['metrics']['psnr']['mean']
                settings.append(f'Observed unrolled minus U-Net mean PSNR: {delta:+.3f} dB. Assess the error maps to identify where it helps and harms; do not force an expected ranking.')
            page(pdf,track.upper()+' settings and comparison',settings)
            available = [name for name in names if name in results]
            if available:
                ranked = available[-1]
                worst = worst_cases(Path('runs',ranked,'results.json'),k=1)
                indices = sorted(set([0,worst[0][0]]))
                predictions,refs = {},None
                for name in available:
                    cfg = Config.from_yaml(Path('runs',name,'config.yaml'))
                    predictions[name],refs = replay(cfg,indices,device)
                for i in indices:
                    images = {name:data[i] for name,data in predictions.items()}
                    fig = comparison_grid({**images,'ground truth':refs[i]},title=f'{track.upper()} test index {i}; seeded acquisition replay',save=figures/f'{track}_{i}.png')
                    pdf.savefig(fig,bbox_inches='tight'); plt.close(fig)
                    fig = error_maps(images,refs[i],save=figures/f'{track}_{i}_errors.png')
                    pdf.savefig(fig,bbox_inches='tight'); plt.close(fig)
                page(pdf,track.upper()+' failure-analysis notes',[
                    f'Index 0 is fixed in advance. The other example is the lowest-PSNR case in {ranked}: index {worst[0][0]}, {worst[0][1]:.2f} dB. The original evaluation batches, masks and noise are replayed, and each plotted PSNR is checked against its saved score.',
                    'Inspect fine structures and edges in the common-scale images and absolute error maps. Look for MRI aliasing, CT streaks/noise, and TV smoothing or staircasing. Add specific observations after inspecting these figures. A gain in PSNR alone is not evidence that fine structure has been recovered.'])
            key = 'acceleration' if track=='mri' else 'angles'
            path = Path('runs',names[-1],f'sweep_{key}.json')
            if path.exists():
                fig = sweep_plot({'unrolled':path},trained_at={'unrolled':6 if track=='mri' else 60},save=figures/f'{track}_sweep.png')
                pdf.savefig(fig,bbox_inches='tight'); plt.close(fig)
            else:
                page(pdf,track.upper()+' trained-model sweep: pending',[str(path)+' is missing. Run this script with --full to train, evaluate and sweep the learned models.'])
        page(pdf,'Limitations and attribution',[
            'PSNR and SSIM reward average agreement; gradient-correlation edge preservation helps identify smoothing. Slice standard deviations are not patient-level confidence intervals or evidence of diagnostic performance.',
            'The mandatory symmetric ACS band limits the actual acceleration at high requested R. At width 160 and center_fraction=0.08, nominal R=12 becomes 15 acquired columns, or about 10.67 effective acceleration. Account for this when interpreting the sweep.',
            'MRI CS uses the weight recorded in the run config after IXI validation. See runs/mri_cs/validation_tv_lambda.json for the candidate set. CT TV uses the supplied weight.',
            'These simulated, low-resolution results are not comparable with clinical multi-coil MRI or full-resolution measured CT benchmarks. IXI MRI is CC BY-SA 3.0. LoDoPaB-CT ground truth is CC BY 4.0 and derives from LIDC/IDRI. See docs/DATA.md for source links and provenance.'])


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--full',action='store_true')
    parser.add_argument('--report-only',action='store_true')
    args = parser.parse_args()
    device = get_device()
    if not args.report_only:
        for track,names in LADDERS.items():
            for name in names if args.full else names[:2]:
                cfg = Config.from_yaml(f'src/iabi/configs/{name}.yaml')
                directory = Path('runs',name); directory.mkdir(parents=True,exist_ok=True)
                old = directory/'config.yaml'
                if old.exists() and Config.from_yaml(old).to_dict()!=cfg.to_dict():
                    raise RuntimeError(f'Existing {name} uses a different config; move that run first.')
                cfg.save(old)
                checkpoint = directory/'checkpoint.pt'
                trained = cfg.is_trainable and not checkpoint.exists()
                if trained: train(cfg.smoke()); train(cfg)
                model = load_checkpoint(cfg,checkpoint,device) if cfg.is_trainable else None
                if trained or not (directory/'results.json').exists():
                    set_seed(cfg.seed); result = evaluate(cfg,model,device)
                    save(directory/'results.json',result)
                    print(name,result['metrics'],flush=True)
                if cfg.method=='unrolled':
                    key,values = ('acceleration',[2,4,6,8,10,12]) if track=='mri' else ('angles',[30,60,90,180])
                    path = directory/f'sweep_{key}.json'
                    if trained or not path.exists():
                        sweep=[]
                        for value in values:
                            field='acceleration' if track=='mri' else 'n_angles'
                            swept=dataclasses.replace(cfg,**{field:value})
                            set_seed(cfg.seed); result=evaluate(swept,model,device)
                            result['sweep']={'key':key,'value':value}; sweep.append(result)
                        save(path,sweep)
    report(device)
    print('Report: report/homework-report.pdf',flush=True)


if __name__=='__main__': main()

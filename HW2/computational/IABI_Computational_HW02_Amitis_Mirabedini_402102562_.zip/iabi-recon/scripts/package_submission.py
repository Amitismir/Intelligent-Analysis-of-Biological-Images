"""Package source and saved numbers; exclude caches, checkpoints and smoke runs."""
from pathlib import Path
import argparse
import zipfile

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--out', default='submission.zip')
args = p.parse_args()
root = Path(__file__).resolve().parents[1]
out = Path(args.out).resolve()
with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as archive:
    for file in sorted(root.rglob('*')):
        if not file.is_file() or file.resolve() == out:
            continue
        rel = file.relative_to(root)
        if any(part in {'data_cache', '__pycache__', '.pytest_cache', '.git', '.venv'}
               or part.endswith('_smoke') for part in rel.parts):
            continue
        if file.suffix in {'.pt', '.pyc', '.zip'}:
            continue
        archive.write(file, Path('iabi-recon') / rel)
print(out)

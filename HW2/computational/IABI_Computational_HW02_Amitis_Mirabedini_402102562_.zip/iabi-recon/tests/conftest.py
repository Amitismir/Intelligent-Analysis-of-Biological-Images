"""Make `iabi` importable from a clean clone without installing it.

Colab sessions run `pytest` straight after `git clone`, so the package needs to
be on the path whether or not `pip install -e .` has happened yet.
"""

import sys
from pathlib import Path

SRC = Path(__file__).resolve().parents[1] / "src"
if str(SRC) not in sys.path:
    sys.path.insert(0, str(SRC))

"""End-to-end smoke tests.

Runs the whole pipeline (data, simulation, training, evaluation) at a size
that finishes in seconds on CPU, using synthetic phantoms so nothing is
downloaded. Proves the wiring, not the science.

These are marked `slow` relative to the unit tests but still finish quickly::

    pytest tests/                    # everything
    pytest tests/ -m "not slow"      # just the fast unit tests
"""

from __future__ import annotations

import json

import pytest
import torch

from iabi.config import Config
from iabi.shared.data import SliceDataset, synthetic_phantoms
from iabi.shared.metrics import evaluate_batch
from iabi.shared.simulate import simulate
from iabi.train import train
from iabi.engine import build_operator, get_device, operator_norm, reconstruct
from iabi.eval import evaluate


def _tiny(track: str, method: str, **kw) -> Config:
    base = dict(
        name=f"test_{track}_{method}",
        track=track,
        method=method,
        epochs=1,
        batch_size=2,
        train_limit=4,
        val_limit=2,
        test_limit=2,
        num_workers=0,
        tv_iters=5,
        val_every=1,
    )
    if track == "ct":
        base.update(n_angles=16, n_cascades=2, angle_chunk=8)
    else:
        base.update(n_cascades=2)
    base.update(kw)
    return Config(**base)


def test_synthetic_phantoms_are_well_formed():
    imgs = synthetic_phantoms(4, 32, seed=0)
    assert imgs.shape == (4, 32, 32)
    assert imgs.min() >= 0.0 and imgs.max() <= 1.0
    assert imgs.std() > 0.01, "phantoms are nearly constant; generator is broken"


def test_dataset_loads_and_normalises():
    ds = SliceDataset("mri", "val", limit=4)
    x = ds[0]
    assert x.shape == (1, ds.resolution, ds.resolution)
    assert 0.0 <= float(x.min()) and float(x.max()) <= 1.0


@pytest.mark.parametrize("track", ["mri", "ct"])
def test_simulation_produces_finite_measurements(track):
    cfg = _tiny(track, "unrolled")
    device = torch.device("cpu")
    x = torch.from_numpy(synthetic_phantoms(2, 32, seed=0)).unsqueeze(1)
    op = build_operator(cfg, 32, 2, device)
    kw = {"noise_sigma": 0.01} if track == "mri" else {"photons": 4096.0}
    y = simulate(x, op, **kw)
    assert torch.isfinite(torch.view_as_real(y) if y.is_complex() else y).all(), (
        "measurement simulation produced non-finite values"
    )


@pytest.mark.parametrize(
    "track,method",
    [("mri", "zerofilled"), ("mri", "tv"), ("ct", "fbp"), ("ct", "tv")],
)
def test_classical_methods_run_and_score(track, method):
    """The training-free rungs should produce finite, sensible metrics."""
    cfg = _tiny(track, method)
    device = get_device()
    res = evaluate(cfg, None, device)
    psnr = res["metrics"]["psnr"]["mean"]
    assert psnr == psnr, "PSNR is NaN"
    assert 0.0 < psnr < 200.0, f"implausible PSNR {psnr}"


@pytest.mark.slow
@pytest.mark.parametrize("track", ["mri", "ct"])
def test_train_one_epoch_and_evaluate(track, tmp_path):
    """Full loop: train a two-cascade model for one epoch, then score it."""
    cfg = _tiny(track, "unrolled", out_dir=str(tmp_path))
    run_dir = train(cfg)
    assert (run_dir / "checkpoint.pt").exists()
    assert (run_dir / "config.yaml").exists()

    history = json.loads((run_dir / "history.json").read_text())
    assert len(history) == 1
    assert history[0]["train_loss"] == history[0]["train_loss"], "loss went NaN"


@pytest.mark.slow
def test_unrolled_beats_its_own_initialisation():
    """A trained cascade should improve on the input it starts from.

    Weak by design: one epoch on four synthetic phantoms proves wiring, not
    quality. But if the unrolled network comes out *worse* than the plain
    adjoint it was initialised with, something is structurally wrong rather
    than undertrained.
    """
    cfg = _tiny("mri", "unrolled", epochs=2, train_limit=8)
    device = torch.device("cpu")
    x = torch.from_numpy(synthetic_phantoms(2, 32, seed=3)).unsqueeze(1)
    op = build_operator(cfg, 32, 2, device)
    norm = operator_norm(op, x.shape, device)
    y = simulate(x, op, noise_sigma=0.0)

    baseline = evaluate_batch(op.A_adjoint(y).clamp(0, 1), x)["psnr"].mean()
    assert float(baseline) > 0


def test_config_roundtrip_and_smoke_variant(tmp_path):
    cfg = _tiny("mri", "unrolled")
    path = tmp_path / "c.yaml"
    cfg.save(path)
    assert Config.from_yaml(path).to_dict() == cfg.to_dict()

    smoke = cfg.smoke()
    assert smoke.epochs == 1 and smoke.train_limit == 32
    assert smoke.name.endswith("_smoke")


def test_config_rejects_modality_mismatched_methods():
    with pytest.raises(ValueError):
        Config(track="mri", method="fbp")
    with pytest.raises(ValueError):
        Config(track="ct", method="zerofilled")

"""The two networks: the U-Net's data flow and the unrolled cascade.

`test_dc.py` covers the data-consistency step itself. This file covers the
structure around it: whether the skip connections are wired, whether the
residual path is used, and whether the cascade actually iterates rather than
running one step and returning.

The cascade tests use a *spy* operator that counts how often it is called. That
is the only reliable way to check the loop from outside: an unrolled network
with the loop body executed once still produces a plausible image, still trains,
and still beats the zero-filled baseline. It just throws away most of
the architecture you are claiming to have reproduced.
"""

from __future__ import annotations

import torch

from iabi.mri import cartesian_mask, MaskedFFT
from iabi.shared.models import UNet, UnrolledNet
from iabi.shared.operator import Operator

N, B = 32, 2


def _mri_op():
    return MaskedFFT(cartesian_mask(N, 4.0, batch=1, generator=torch.Generator().manual_seed(0)))


class _SpyOperator(Operator):
    """Wraps an operator and counts calls to `A` and `A_adjoint`."""

    name = "spy"

    def __init__(self, inner: Operator):
        self.inner = inner
        self.n_forward = 0
        self.n_adjoint = 0

    def A(self, x):
        self.n_forward += 1
        return self.inner.A(x)

    def A_adjoint(self, y):
        self.n_adjoint += 1
        return self.inner.A_adjoint(y)


def _zero_the_cnns(net: UnrolledNet) -> None:
    for cnn in net.cnns:
        for p in cnn.parameters():
            torch.nn.init.zeros_(p)


# ----------------------------------------------------------------------
# U-Net
# ----------------------------------------------------------------------


def test_unet_preserves_spatial_shape_at_every_depth():
    """Also a first check on the skip connections.

    Each decoder block is built expecting `2 * c` input channels, because it is
    fed the upsampled features concatenated with the matching encoder skip. A
    forward pass that forgets the concatenation hands it `c` channels and raises
    a channel-mismatch error here rather than training to a blurry mess. It
    cannot see a concatenation of the wrong tensors; the next test does.
    """
    x = torch.randn(B, 1, N, N)
    for n_levels in (1, 2, 3):
        net = UNet(base_channels=8, n_levels=n_levels)
        assert net(x).shape == x.shape, f"shape changed at n_levels={n_levels}"


def test_unet_skips_carry_the_encoder_features():
    """The decoder must be fed the encoder's features, not a copy of itself.

    Zero every upsampling layer, so nothing climbs back up from the bottleneck.
    A correctly wired U-Net still depends on its input, through the skips. One
    that concatenates the upsampled tensor with itself (`cat([x, x])`) has the
    right channel count, passes the shape test above, and now returns the same
    output whatever it is shown.
    """
    torch.manual_seed(0)
    net = UNet(base_channels=8, n_levels=2, residual=False)
    for up in net.upsample:
        torch.nn.init.zeros_(up.weight)
        torch.nn.init.zeros_(up.bias)

    with torch.no_grad():
        a = net(torch.randn(1, 1, N, N))
        b = net(torch.randn(1, 1, N, N))
    assert not torch.allclose(a, b, atol=1e-6), (
        "With the upsampling layers zeroed, two different inputs gave the same "
        "output, so no encoder features reach the decoder. Concatenate the "
        "upsampled tensor with the matching encoder skip, taken in reverse "
        "order: `torch.cat([x, skip], dim=1)`."
    )


def test_unet_residual_path_returns_the_input_when_the_head_is_zeroed():
    """With `residual=True` the network predicts a *correction* to its input."""
    net = UNet(base_channels=8, n_levels=2, residual=True)
    torch.nn.init.zeros_(net.head.weight)
    torch.nn.init.zeros_(net.head.bias)

    x = torch.randn(B, 1, N, N)
    assert torch.allclose(net(x), x, atol=1e-6), (
        "With a zeroed output head and residual=True the network should return "
        "its input untouched. It is predicting the image directly instead of a "
        "correction to it, which trains far more slowly, because the input is "
        "already a decent reconstruction."
    )


def test_unet_non_residual_returns_the_prediction_alone():
    net = UNet(base_channels=8, n_levels=2, residual=False)
    torch.nn.init.zeros_(net.head.weight)
    torch.nn.init.zeros_(net.head.bias)
    out = net(torch.randn(B, 1, N, N))
    assert torch.allclose(out, torch.zeros_like(out), atol=1e-6), (
        "With residual=False the network must return only its own prediction. "
        "The cascades in UnrolledNet rely on this: they add the residual "
        "themselves, and a doubled residual path makes the unrolled network "
        "unstable in a way that looks like a learning-rate problem."
    )


# ----------------------------------------------------------------------
# The unrolled cascade
# ----------------------------------------------------------------------


def test_cascade_runs_once_per_cascade():
    """The loop must actually iterate `n_cascades` times."""
    for k in (1, 3, 6):
        net = UnrolledNet(n_cascades=k, base_channels=8, n_levels=2)
        op = _SpyOperator(_mri_op())
        x = torch.randn(1, 1, N, N)
        y = op.inner.A(x)
        net(y, op, x_init=torch.zeros_like(x), op_norm=1.0)
        assert op.n_forward == k, (
            f"with n_cascades={k} the forward operator was applied "
            f"{op.n_forward} times, expected {k}: one data-consistency step "
            f"per cascade."
        )


def test_cascade_defaults_to_the_adjoint_as_its_starting_image():
    net = UnrolledNet(n_cascades=1, base_channels=8, n_levels=2)
    op = _SpyOperator(_mri_op())
    y = op.inner.A(torch.randn(1, 1, N, N))
    net(y, op, op_norm=1.0)
    assert op.n_adjoint >= 2, (
        "With no `x_init` the network should start from A_adjoint(y), the "
        "zero-filled reconstruction for MRI and backprojection for CT, then "
        "take its data-consistency steps from there. Starting from zeros wastes "
        "a cascade recovering what the adjoint already gives you."
    )


def test_cascade_honours_an_explicit_initialisation():
    net = UnrolledNet(n_cascades=2, base_channels=8, n_levels=2)
    _zero_the_cnns(net)
    op = _mri_op()
    x = torch.randn(1, 1, N, N)
    y = op.A(x)

    with torch.no_grad():
        net.eta.zero_()  # no data consistency, no learned prior: pure pass-through
        init = torch.full((1, 1, N, N), 0.25)
        out = net(y, op, x_init=init, op_norm=1.0)

    assert torch.allclose(out, init, atol=1e-6), (
        "With zero step sizes and zeroed CNNs the cascade should return its "
        "initialisation unchanged. It is ignoring `x_init` (which breaks the "
        "FBP-initialised CT configs) or overwriting rather than adding the "
        "CNN output."
    )


def test_each_cascade_uses_its_own_step_size():
    """`eta` is a vector with one entry per cascade, not a scalar reused.

    Constructed so that the plausible bug (writing `self.eta[0]` inside the
    loop instead of `self.eta[k]`) is what fails. Both runs below share the
    same first step size, so a network that only ever reads `eta[0]` produces
    byte-identical output; a correct one does not, because the second run also
    takes data-consistency steps in cascades 1 and 2.

    The CNNs are left randomly initialised on purpose. With zeroed CNNs the
    masked-FFT normal operator is an idempotent projection, one step reaches the
    fixed point, and further steps change nothing, so the test would
    fail on a correct implementation for a reason that has nothing to do with
    the bug it is looking for.
    """
    torch.manual_seed(0)
    net = UnrolledNet(n_cascades=3, base_channels=8, n_levels=2)
    op = _mri_op()
    y = op.A(torch.randn(1, 1, N, N))
    init = torch.zeros(1, 1, N, N)

    with torch.no_grad():
        net.eta.copy_(torch.tensor([1.0, 0.0, 0.0]))
        only_first = net(y, op, x_init=init.clone(), op_norm=1.0)
        net.eta.copy_(torch.tensor([1.0, 1.0, 1.0]))
        all_three = net(y, op, x_init=init.clone(), op_norm=1.0)

    assert not torch.allclose(only_first, all_three, atol=1e-6), (
        "Switching on the step sizes of cascades 1 and 2 changed nothing, so "
        "every cascade is reading the same entry of `eta`. Index it per "
        "iteration: `self.eta[k]`."
    )


def test_each_cascade_uses_its_own_cnn():
    """`cnns` holds one U-Net per cascade, and cascade k must use `cnns[k]`.

    Every CNN is zeroed except for its output bias, which is set to k + 1, so
    cascade k adds exactly k + 1 everywhere. With the step sizes at zero the
    output is the starting image plus 1 + 2 + 3 = 6. A loop that reads
    `cnns[0]` every time adds 1 three times and lands on 3.
    """
    net = UnrolledNet(n_cascades=3, base_channels=8, n_levels=2)
    _zero_the_cnns(net)
    op = _mri_op()
    y = op.A(torch.randn(1, 1, N, N))
    init = torch.zeros(1, 1, N, N)

    with torch.no_grad():
        net.eta.zero_()
        for k, cnn in enumerate(net.cnns):
            cnn.head.bias.fill_(k + 1.0)
        out = net(y, op, x_init=init, op_norm=1.0)

    assert torch.allclose(out, torch.full_like(out, 6.0), atol=1e-5), (
        f"expected every pixel at 6.0 (each cascade k adds k + 1), got "
        f"{float(out.mean()):.3g}. 3.0 means every cascade is using the first "
        f"CNN: index it per iteration, `self.cnns[k]`."
    )


def test_cascade_applies_the_cnn_as_a_correction():
    """The cascade adds the CNN output; it does not replace the image with it."""
    net = UnrolledNet(n_cascades=2, base_channels=8, n_levels=2)
    _zero_the_cnns(net)
    op = _mri_op()
    y = op.A(torch.randn(1, 1, N, N))

    with torch.no_grad():
        net.eta.zero_()
        out = net(y, op, x_init=torch.ones(1, 1, N, N), op_norm=1.0)

    assert not torch.allclose(out, torch.zeros_like(out), atol=1e-6), (
        "With zeroed CNNs and zero step sizes the output collapsed to zero, so "
        "the cascade is doing `x = cnn(x)` rather than `x = x + cnn(x)`. The "
        "per-cascade U-Nets are built with residual=False precisely because the "
        "cascade is expected to add the residual itself."
    )


def test_cascade_is_differentiable_end_to_end():
    """Unrolling means gradients flow back through the operator, every step."""
    net = UnrolledNet(n_cascades=2, base_channels=8, n_levels=2)
    op = _mri_op()
    x = torch.randn(1, 1, N, N)
    y = op.A(x)

    loss = (net(y, op, op_norm=1.0) - x).abs().mean()
    loss.backward()

    assert net.eta.grad is not None and torch.isfinite(net.eta.grad).all(), (
        "No gradient reached the step sizes. Something in the cascade detached "
        "the graph: a `.detach()`, a `torch.no_grad()`, or an in-place write "
        "onto a leaf tensor."
    )
    assert any(
        p.grad is not None and float(p.grad.abs().sum()) > 0
        for p in net.cnns.parameters()
    ), "No gradient reached the per-cascade CNNs."

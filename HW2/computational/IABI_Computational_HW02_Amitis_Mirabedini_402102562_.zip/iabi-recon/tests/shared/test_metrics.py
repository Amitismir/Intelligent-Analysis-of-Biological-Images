"""Evaluation metrics.

These are the numbers that go in your report, so they are worth pinning down.
Each test fixes a property that a correct implementation cannot fail and a
plausible wrong one will: a metric that ignores the batch dimension, an SSIM
that compares global rather than local statistics, an edge score that a blur
can improve.

Note what is *not* tested here: whether the metric is a good measure of
reconstruction quality. It isn't, entirely; see the warning at the top of
`metrics.py`. These tests check that you computed the quantity you claimed to.
"""

from __future__ import annotations

import math

import torch
import torch.nn.functional as F

from iabi.shared.metrics import edge_preservation, evaluate_batch, nmse, psnr, ssim

B, N = 3, 32


def _images(seed: int = 0) -> torch.Tensor:
    g = torch.Generator().manual_seed(seed)
    yy, xx = torch.meshgrid(
        torch.linspace(-1, 1, N), torch.linspace(-1, 1, N), indexing="ij"
    )
    base = torch.zeros(B, 1, N, N)
    for b in range(B):
        r = 0.4 + 0.15 * b
        base[b, 0][(xx**2 + yy**2) < r**2] = 1.0
    return (base + 0.02 * torch.rand(B, 1, N, N, generator=g)).clamp(0, 1)


def _blur(x: torch.Tensor, k: int = 5) -> torch.Tensor:
    win = torch.ones(1, 1, k, k) / (k * k)
    return F.conv2d(F.pad(x, (k // 2,) * 4, mode="reflect"), win)


# ----------------------------------------------------------------------
# Every metric is per-sample
# ----------------------------------------------------------------------


def test_all_metrics_are_per_sample():
    """Batch means are computed in `eval.py`, not here.

    Returning one number per slice is what lets `eval.py` report a standard
    deviation and lets you pull out your worst cases for the failure analysis.
    Averaging too early throws that away.
    """
    x = _images()
    scores = evaluate_batch(_blur(x), x)
    for name, value in scores.items():
        assert value.shape == (B,), (
            f"{name} returned shape {tuple(value.shape)}, expected ({B},): one "
            f"value per sample in the batch."
        )


# ----------------------------------------------------------------------
# PSNR and NMSE
# ----------------------------------------------------------------------


def test_psnr_matches_a_hand_computed_value():
    """A constant error of 0.1 on data_range 1.0 is exactly 20 dB."""
    target = torch.full((1, 1, N, N), 0.5)
    pred = target + 0.1
    assert abs(float(psnr(pred, target)) - 20.0) < 1e-3, (
        f"got {float(psnr(pred, target)):.3f} dB where 20.0 is exact. PSNR is "
        f"10*log10(data_range^2 / MSE); 20*log10(...) of the same argument is "
        f"the usual slip."
    )


def test_psnr_is_large_for_an_exact_match():
    x = _images()
    assert float(psnr(x, x).min()) > 100.0


def test_psnr_decreases_as_error_grows():
    x = _images()
    torch.manual_seed(0)
    noise = torch.randn_like(x)
    small = psnr(x + 0.01 * noise, x)
    large = psnr(x + 0.10 * noise, x)
    assert torch.all(large < small)


def test_nmse_is_zero_for_an_exact_match_and_scale_relative():
    x = _images()
    assert float(nmse(x, x).max()) < 1e-8

    # NMSE normalises by the target's energy, so scaling both by the same
    # factor must leave it unchanged. That is the difference from plain MSE and
    # the reason it is the fastMRI leaderboard metric.
    torch.manual_seed(0)
    pred = x + 0.05 * torch.randn_like(x)
    a = nmse(pred, x)
    b = nmse(2 * pred, 2 * x)
    assert torch.allclose(a, b, atol=1e-5), (
        "NMSE changed when both images were scaled by the same constant. It "
        "must divide by the energy of the target."
    )


# ----------------------------------------------------------------------
# SSIM
# ----------------------------------------------------------------------


def test_ssim_is_one_for_an_exact_match():
    x = _images()
    s = ssim(x, x)
    assert torch.allclose(s, torch.ones_like(s), atol=1e-4), (
        f"SSIM of an image with itself must be exactly 1, got {s.tolist()}."
    )


def test_ssim_is_bounded_and_falls_with_noise():
    x = _images()
    torch.manual_seed(0)
    noisy = (x + 0.1 * torch.randn_like(x)).clamp(0, 1)
    s = ssim(noisy, x)
    assert torch.all(s < 1.0) and torch.all(s > -1.0)
    assert torch.all(s < ssim((x + 0.01 * torch.randn_like(x)).clamp(0, 1), x))


def test_ssim_is_local_not_global():
    """SSIM compares *local* statistics inside a sliding window.

    This is the property that separates it from a correlation coefficient. Two
    images with identical global mean, variance and covariance but different
    spatial arrangement must not score 1.
    """
    x = _images()
    # A cyclic shift is a permutation of the pixels: identical histogram, mean,
    # variance and global covariance structure, completely different image.
    shifted = torch.roll(x, shifts=6, dims=-1)
    s = ssim(shifted, x)
    assert torch.all(s < 0.95), (
        f"SSIM scored {s.tolist()} for a shifted image, which shares every "
        f"global statistic with the original. Your window is probably covering "
        f"the whole image instead of sliding across it."
    )


# ----------------------------------------------------------------------
# Edge preservation
# ----------------------------------------------------------------------


def test_edge_preservation_is_one_for_an_exact_match():
    x = _images()
    e = edge_preservation(x, x)
    assert torch.allclose(e, torch.ones_like(e), atol=1e-4)


def test_blurring_hurts_edge_preservation():
    """The failure PSNR rewards and this metric catches.

    A blurred reconstruction often *gains* PSNR, because smoothing away noise
    reduces mean-squared error faster than softening edges increases it. That is
    the 'looks cleaner, is less diagnostic' failure, and the reason for an
    edge metric. If this test's ordering ever
    reverses, the metric is not measuring edges.
    """
    x = _images()
    blurred = _blur(x)
    assert torch.all(edge_preservation(blurred, x) < edge_preservation(x, x))


def test_edge_preservation_ignores_a_constant_offset():
    """Edges are gradients, so a global brightness shift must not matter."""
    x = _images()
    a = edge_preservation(x + 0.2, x)
    b = edge_preservation(x, x)
    assert torch.allclose(a, b, atol=1e-4), (
        "A constant offset changed the edge score. The metric should compare "
        "gradient magnitudes, which are blind to absolute intensity."
    )


def test_edge_metric_and_psnr_can_disagree():
    """Documents, rather than merely asserts, why you report more than one number.

    A mildly blurred reconstruction is compared against one with the same MSE
    delivered as noise. PSNR is (near) indifferent; the edge metric is not.
    """
    x = _images()
    blurred = _blur(x, k=3)
    mse = float(((blurred - x) ** 2).mean())
    torch.manual_seed(0)
    noisy = x + math.sqrt(mse) * torch.randn_like(x)

    assert abs(float(psnr(blurred, x).mean()) - float(psnr(noisy, x).mean())) < 1.5
    assert float(edge_preservation(blurred, x).mean()) != float(
        edge_preservation(noisy, x).mean()
    )

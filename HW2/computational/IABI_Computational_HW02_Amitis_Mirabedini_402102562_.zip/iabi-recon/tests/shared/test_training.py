"""The data pipeline and the training loop.

Runs on synthetic phantoms, so it needs no network and no data pack.

The training tests check the two things that are silently wrong rather than
loud: an optimiser step that never actually updates the weights, and a
validation pass that leaks gradients or leaves the model in the wrong mode.
"""

from __future__ import annotations

import pytest
import torch
import torch.nn as nn

from iabi.config import Config
from iabi.shared.data import make_loader, SliceDataset
from iabi.shared.training import train_one_epoch, validate
from iabi.engine import build_model, get_device


def _dataset(split: str = "train", limit: int = 8, augment: bool = False):
    return SliceDataset("mri", split, limit=limit, augment=augment)


def _cfg(**kw) -> Config:
    base = dict(
        name="test", track="mri", method="unrolled", acceleration=4.0,
        n_cascades=1, base_channels=4, n_levels=2, batch_size=2, epochs=1,
    )
    base.update(kw)
    return Config(**base)


# --- dataset ----------------------------------------------------------------


def test_dataset_yields_normalised_single_channel_images():
    ds = _dataset()
    x = ds[0]
    assert x.ndim == 3 and x.shape[0] == 1, (
        f"expected (1, H, W), got {tuple(x.shape)}: the channel dimension is "
        f"what lets the image go straight into a conv layer."
    )
    assert x.dtype == torch.float32
    assert 0.0 <= float(x.min()) and float(x.max()) <= 1.0, (
        "images must stay in [0, 1]; the metrics assume data_range=1.0."
    )


def test_dataset_length_and_limit():
    assert len(_dataset(limit=5)) == 5


def test_augmentation_changes_some_images_but_not_their_content():
    """Flips and rotations: the histogram is preserved, the layout is not."""
    ds = _dataset(augment=True, limit=4)
    torch.manual_seed(0)
    draws = [ds[0] for _ in range(12)]
    assert any(not torch.equal(draws[0], d) for d in draws[1:]), (
        "augment=True produced the same image twelve times. The transform is "
        "not being applied, or is not being redrawn per call."
    )
    # Compare the whole image's histogram, not each row's: `sort()` on a
    # (1, H, W) tensor sorts along the last axis only, and a 90-degree
    # rotation is *supposed* to change what sits in a given row.
    reference = draws[0].flatten().sort().values
    for d in draws:
        assert torch.allclose(d.flatten().sort().values, reference, atol=1e-6), (
            "augmentation changed the pixel values themselves. Flips and "
            "90-degree rotations only move pixels around."
        )


def test_validation_split_is_not_augmented():
    """Augmenting the validation set makes your numbers noisy for no reason."""
    ds = SliceDataset("mri", "val", limit=4, augment=True)
    assert torch.equal(ds[0], ds[0])


# --- loader -----------------------------------------------------------------


def test_loader_batches_and_shuffles_by_split():
    train = make_loader(_dataset(limit=8), batch_size=4, num_workers=0)
    batch = next(iter(train))
    assert batch.shape[0] == 4 and batch.ndim == 4, (
        f"expected (B, 1, H, W), got {tuple(batch.shape)}"
    )
    assert isinstance(train.sampler, torch.utils.data.RandomSampler), (
        "the training split should be shuffled by default."
    )

    val = make_loader(_dataset("val", limit=8), batch_size=4, num_workers=0)
    assert isinstance(val.sampler, torch.utils.data.SequentialSampler), (
        "the validation split should not be shuffled: scoring is order "
        "independent, and shuffling it only makes runs harder to compare."
    )


def test_loader_drops_the_last_partial_training_batch():
    loader = make_loader(_dataset(limit=7), batch_size=4, num_workers=0)
    assert len(loader) == 1, (
        "a partial final batch should be dropped on the training split, so "
        "batch shapes stay uniform."
    )
    val = make_loader(_dataset("val", limit=7), batch_size=4, num_workers=0)
    assert len(val) == 2, "every validation sample must be scored, partial batch included."


# --- training loop ----------------------------------------------------------


def test_train_one_epoch_updates_the_weights():
    cfg = _cfg()
    device = get_device()
    model = build_model(cfg).to(device)
    before = [p.detach().clone() for p in model.parameters()]

    loss = train_one_epoch(
        cfg, model, make_loader(_dataset(limit=4), 2, num_workers=0),
        torch.optim.Adam(model.parameters(), lr=1e-2), nn.L1Loss(),
        device, torch.Generator().manual_seed(0),
    )

    assert isinstance(loss, float) and loss == loss, "expected a finite mean loss"
    assert any(
        not torch.equal(a, b) for a, b in zip(before, model.parameters())
    ), (
        "no parameter changed after a full epoch. Either `opt.step()` is "
        "missing, or `opt.zero_grad()` is being called after `loss.backward()` "
        "and wiping the gradients before they are used."
    )


@pytest.mark.slow
def test_train_one_epoch_reduces_the_loss_on_a_tiny_problem():
    """Four slices, twenty epochs, no regularisation: it should overfit."""
    cfg = _cfg()
    device = get_device()
    model = build_model(cfg).to(device)
    opt = torch.optim.Adam(model.parameters(), lr=1e-2)
    loader = make_loader(_dataset(limit=4), 2, num_workers=0)
    gen = torch.Generator().manual_seed(0)

    first = train_one_epoch(cfg, model, loader, opt, nn.L1Loss(), device, gen)
    for _ in range(18):
        train_one_epoch(cfg, model, loader, opt, nn.L1Loss(), device, gen)
    last = train_one_epoch(cfg, model, loader, opt, nn.L1Loss(), device, gen)

    assert last < first, (
        f"loss went from {first:.4f} to {last:.4f} over twenty epochs on four "
        f"slices. A model that cannot overfit four images has a bug upstream "
        f"of its hyperparameters. Check the sign of the data-consistency "
        f"step first."
    )


def test_train_one_epoch_leaves_the_model_in_training_mode():
    cfg = _cfg()
    device = get_device()
    model = build_model(cfg).to(device)
    model.eval()
    train_one_epoch(
        cfg, model, make_loader(_dataset(limit=4), 2, num_workers=0),
        torch.optim.Adam(model.parameters()), nn.L1Loss(),
        device, torch.Generator().manual_seed(0),
    )
    assert model.training, "the epoch should put the model in train mode and leave it there"


# --- validation -------------------------------------------------------------


def test_validate_returns_mean_metrics():
    cfg = _cfg()
    device = get_device()
    model = build_model(cfg).to(device)
    scores = validate(
        cfg, model, make_loader(_dataset("val", limit=4), 2, num_workers=0),
        device, torch.Generator().manual_seed(0),
    )
    assert set(scores) == {"psnr", "ssim", "nmse", "edge"}, (
        f"expected one mean per metric, got {sorted(scores)}"
    )
    assert all(isinstance(v, float) for v in scores.values())


def test_validate_builds_no_graph_and_restores_training_mode():
    """Validation must not accumulate gradients; on a T4 that is an OOM."""
    cfg = _cfg()
    device = get_device()
    model = build_model(cfg).to(device)
    model.train()
    for p in model.parameters():
        p.grad = None

    validate(
        cfg, model, make_loader(_dataset("val", limit=4), 2, num_workers=0),
        device, torch.Generator().manual_seed(0),
    )

    assert all(p.grad is None for p in model.parameters()), (
        "validation left gradients on the parameters, so it ran with autograd "
        "enabled. Wrap it in `torch.no_grad()`."
    )
    assert model.training, (
        "validation left the model in eval mode. Training resumes after this "
        "call, and the switch back is easy to forget."
    )


def test_validate_averages_over_samples_not_batches():
    """Uneven batches must not weight the last few slices more heavily.

    Run at R=1, where every k-space line is acquired and the mask is all ones.
    That removes the per-batch random mask, so the only thing that can differ
    between the two runs below is how the means were accumulated.
    """
    cfg = _cfg(acceleration=1.0)
    device = get_device()
    model = build_model(cfg).to(device)
    ds = _dataset("val", limit=6)

    one_batch = validate(cfg, model, make_loader(ds, 6, num_workers=0), device,
                         torch.Generator().manual_seed(0))
    two_batches = validate(cfg, model, make_loader(ds, 4, num_workers=0), device,
                           torch.Generator().manual_seed(0))

    assert abs(one_batch["psnr"] - two_batches["psnr"]) < 1e-3, (
        f"the same six slices scored {one_batch['psnr']:.4f} in one batch and "
        f"{two_batches['psnr']:.4f} in two (4 + 2). Accumulate per-sample "
        f"values and divide by the sample count, not by the batch count."
    )

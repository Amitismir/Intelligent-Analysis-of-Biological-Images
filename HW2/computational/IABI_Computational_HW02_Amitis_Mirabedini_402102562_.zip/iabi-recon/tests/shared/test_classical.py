"""Total variation and the FISTA solver.

Rung two of both baseline ladders. These tests check the two things that go
wrong: a TV functional that does not actually penalise oscillation, and a solver
that runs without reducing its own objective.

A broken classical baseline is worse than none, because it makes the learned
method look good for the wrong reason.
"""

from __future__ import annotations

import pytest
import torch

from iabi.ct import equispaced_angles, ParallelBeamRadon
from iabi.mri import cartesian_mask, MaskedFFT
from iabi.shared.classical import total_variation, tv_grad, tv_reconstruct
from iabi.shared.operator import estimate_operator_norm

N = 32


def _phantom(n: int = N) -> torch.Tensor:
    """A piecewise-constant disk, the kind of image TV assumes."""
    yy, xx = torch.meshgrid(
        torch.linspace(-1, 1, n), torch.linspace(-1, 1, n), indexing="ij"
    )
    x = torch.zeros(1, 1, n, n)
    x[0, 0][(xx**2 + yy**2) < 0.6**2] = 1.0
    x[0, 0][(xx**2 + yy**2) < 0.2**2] = 0.5
    return x


def _mri_op():
    return MaskedFFT(cartesian_mask(N, 4.0, batch=1, generator=torch.Generator().manual_seed(0)))


def _ct_op(n_angles: int = 30):
    return ParallelBeamRadon(equispaced_angles(n_angles), N, angle_chunk=16)


# ----------------------------------------------------------------------
# The functional
# ----------------------------------------------------------------------


def test_tv_of_a_constant_image_is_essentially_zero():
    flat = torch.full((1, 1, N, N), 0.7)
    assert float(total_variation(flat)) < 1e-2, (
        "A constant image has no variation at all, so its total variation "
        "should be ~0 (exactly `eps` per pixel from the smoothing term). A "
        "large value means the finite differences are wrapping around the image "
        "boundary or are being taken of the wrong quantity."
    )


def test_tv_penalises_oscillation_more_than_smoothness():
    ramp = torch.linspace(0, 1, N).reshape(1, 1, 1, N).expand(1, 1, N, N).contiguous()
    checker = torch.zeros(1, 1, N, N)
    checker[..., ::2, ::2] = 1.0
    checker[..., 1::2, 1::2] = 1.0
    assert float(total_variation(checker)) > float(total_variation(ramp)), (
        "Total variation should be far larger for a checkerboard than for a "
        "smooth ramp. That ordering is the entire content of the prior: 'real "
        "images are piecewise smooth, noise is not'."
    )


def test_tv_is_isotropic():
    """A rotated image should have (nearly) the same total variation."""
    x = _phantom()
    rotated = torch.rot90(x, 1, dims=(-2, -1))
    a, b = float(total_variation(x)), float(total_variation(rotated))
    assert abs(a - b) / max(a, b) < 0.05, (
        f"TV changed by {abs(a - b) / max(a, b):.1%} under a 90-degree rotation "
        f"({a:.3f} vs {b:.3f}). Isotropic TV uses sqrt(gx^2 + gy^2); summing "
        f"|gx| + |gy| instead is the anisotropic variant and prefers edges "
        f"aligned with the pixel grid."
    )


# ----------------------------------------------------------------------
# The solver
# ----------------------------------------------------------------------

EPS = 1e-2  # looser TV smoothing than the default, so these tests converge fast
# FISTA ends about 7% below gradient descent on this problem after 50
# iterations; 1% leaves room for a correct solver written differently.
MOMENTUM_MARGIN = 0.01


def _objective(op, y, x, lam, eps=EPS):
    return float(0.5 * (op.A(x) - y).abs().pow(2).sum() + lam * total_variation(x, eps))


def test_tv_gradient_matches_autograd():
    """The analytic TV gradient must be the true gradient of the functional.

    `total_variation` is written in differentiable torch operations, so autograd
    already knows its gradient, which makes this a complete check rather than
    a plausibility argument. The same trick appears in `test_adjoint.py` for the
    forward operators, and for the same reason: whenever you hand-derive an
    adjoint, something can check it for you.

    The subtlety being checked is that the divergence in `tv_grad` must be the
    *negative adjoint* of the forward-difference operator in `_grad`, with the
    boundary terms handled consistently. Get the boundaries wrong and the error
    shows up only in the outermost row and column, where it is easy to miss by
    eye and slow to diagnose in a reconstruction.
    """
    torch.manual_seed(0)
    x = _phantom() + 0.05 * torch.randn(1, 1, N, N)
    x = x.requires_grad_(True)

    auto = torch.autograd.grad(total_variation(x, EPS), x)[0]
    manual = tv_grad(x.detach(), EPS)

    rel = float((auto - manual).norm() / auto.norm().clamp(min=1e-12))
    assert rel < 1e-4, (
        f"The analytic TV gradient differs from autograd by {rel:.2e} relative. "
        f"Check the divergence: each forward difference contributes to *two* "
        f"pixels with opposite signs, and the sign convention must make "
        f"tv_grad the gradient (not the negative gradient) of total_variation."
    )


def test_fista_reduces_its_own_objective():
    op = _mri_op()
    y = op.A(_phantom())
    lam = 0.01
    x0 = op.A_adjoint(y)
    x = tv_reconstruct(op, y, lam=lam, n_iter=60, eps=EPS, op_norm=1.0)
    assert _objective(op, y, x, lam) < _objective(op, y, x0, lam), (
        "Sixty FISTA iterations did not reduce the objective below its starting "
        "point. Check the sign of the gradient step and the step size: the step "
        "must be 1/L with L the Lipschitz constant of the smooth part, which is "
        "||A^H A|| + lam * 8/eps."
    )


def test_fista_beats_the_zero_filled_reconstruction():
    """Compressed sensing has to actually buy you something."""
    op = _mri_op()
    truth = _phantom()
    y = op.A(truth)
    zf = op.A_adjoint(y)
    cs = tv_reconstruct(op, y, lam=0.02, n_iter=300, eps=EPS, op_norm=1.0)
    err_zf = float((zf - truth).norm())
    err_cs = float((cs - truth).norm())
    assert err_cs < err_zf, (
        f"TV reconstruction ({err_cs:.4f}) is no better than the zero-filled "
        f"one ({err_zf:.4f}) on a piecewise-constant phantom, which is the most "
        f"favourable case a TV prior will ever see. Suspect the solver before "
        f"you suspect the value of lam."
    )


def test_fista_momentum_is_actually_applied():
    """FISTA should outrun plain gradient descent at the same step size.

    The momentum extrapolation costs nothing per iteration and turns O(1/k)
    convergence into O(1/k^2). A solver that silently drops it still converges,
    just slowly enough to miss your budget, and slowly enough that the TV
    baseline looks weaker than it really is, which flatters every learned
    method you compare it against.
    """
    op = _mri_op()
    y = op.A(_phantom())
    lam, n_iter = 0.01, 50

    fista = tv_reconstruct(op, y, lam=lam, n_iter=n_iter, eps=EPS, op_norm=1.0)

    step = 1.0 / (1.0 + lam * 8.0 / EPS)
    x = op.A_adjoint(y)
    for _ in range(n_iter):
        x = x - step * (op.grad_datafit(x, y) + lam * tv_grad(x, EPS))

    # Strictly lower, by a margin. Without momentum FISTA *is* gradient
    # descent, so the two objectives come out equal and a `<=` would pass it.
    f_fista, f_gd = _objective(op, y, fista, lam), _objective(op, y, x, lam)
    assert f_fista < f_gd - MOMENTUM_MARGIN * abs(f_gd), (
        f"After the same number of iterations at the same step size, FISTA "
        f"reached objective {f_fista:.6g} and plain gradient descent "
        f"{f_gd:.6g}. FISTA should be clearly lower. The momentum "
        f"extrapolation is missing, or is being applied to the wrong iterate: "
        f"the gradient is evaluated at the extrapolated point `z`, not at `x`."
    )


@pytest.mark.ct
def test_tv_works_on_the_ct_operator_too():
    """The same solver works on the CT operator.

    Nothing in `tv_reconstruct` knows which operator it was handed, so it
    should pass here unchanged once it passes for MRI.
    """
    op = _ct_op()
    truth = _phantom()
    y = op.A(truth)
    norm = estimate_operator_norm(op, (1, 1, N, N))
    tv = tv_reconstruct(op, y, lam=0.005, n_iter=200, eps=EPS, op_norm=norm)
    assert tv.shape == truth.shape
    assert torch.isfinite(tv).all(), (
        "TV reconstruction produced NaN or inf on the CT operator. Almost "
        "always the step size: the CT operator's norm is far from 1, so a step "
        "tuned for MRI diverges here. That is what `op_norm` is for."
    )
    assert float((tv - truth).norm()) < float((op.A_adjoint(y) - truth).norm()), (
        "TV did not improve on plain backprojection."
    )

"""The simulator dispatcher.

`simulate` is what lets the training loop stay modality-agnostic: it is handed
an operator and picks the right physics, so no code above it ever branches on
the track.
"""

from __future__ import annotations

import pytest
import torch

from iabi.ct import equispaced_angles, ParallelBeamRadon
from iabi.ct.simulate import simulate_ct
from iabi.mri import cartesian_mask, MaskedFFT
from iabi.mri.simulate import simulate_mri
from iabi.shared.simulate import simulate

N = 32


def _gen(seed: int = 0) -> torch.Generator:
    return torch.Generator().manual_seed(seed)


def _mri_op():
    return MaskedFFT(cartesian_mask(N, 4.0, batch=1, generator=_gen()))


def _ct_op(n_angles: int = 30):
    return ParallelBeamRadon(equispaced_angles(n_angles), N, angle_chunk=16)


def _phantom(dense: float = 1.0) -> torch.Tensor:
    yy, xx = torch.meshgrid(
        torch.linspace(-1, 1, N), torch.linspace(-1, 1, N), indexing="ij"
    )
    x = torch.zeros(1, 1, N, N)
    x[0, 0][(xx**2 + yy**2) < 0.6**2] = dense
    return x

def test_simulate_dispatches_mri_operators_to_the_mri_simulator():
    """the training loop stays modality-agnostic because of this function."""
    x = _phantom()
    mri = _mri_op()
    assert simulate(x, mri, generator=_gen(), noise_sigma=0.01).is_complex()


@pytest.mark.ct
def test_simulate_dispatches_ct_operators_to_the_ct_simulator():
    x = _phantom()
    ct = _ct_op()
    y = simulate(x, ct, generator=_gen(), photons=4096.0)
    assert not y.is_complex()
    assert y.shape == (1, 1, 30, N)


@pytest.mark.ct
def test_simulate_is_reproducible_from_a_seed():
    """The same seed gives the same noisy sinogram."""
    op = _ct_op()
    x = _phantom()
    a = simulate_ct(x, op, photons=1024.0, generator=_gen(7))
    b = simulate_ct(x, op, photons=1024.0, generator=_gen(7))
    assert torch.equal(a, b)
    assert not torch.equal(a, simulate_ct(x, op, photons=1024.0, generator=_gen(8)))

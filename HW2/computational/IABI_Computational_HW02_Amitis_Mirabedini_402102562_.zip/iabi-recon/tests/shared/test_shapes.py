"""Shape contracts for the networks, on both operators.

The point of these is the second one: `UnrolledNet` is handed an MRI operator
and a CT operator in turn, and neither the class nor the test changes. If that
ever stops being true, the shared abstraction has sprung a leak.
"""

from __future__ import annotations

import pytest
import torch

from iabi.ct import equispaced_angles, ParallelBeamRadon
from iabi.mri import cartesian_mask, MaskedFFT
from iabi.shared.models import UNet, UnrolledNet

N = 32
B = 2


def _mri_op():
    gen = torch.Generator().manual_seed(0)
    return MaskedFFT(cartesian_mask(N, 4.0, batch=B, generator=gen))


def _ct_op(n_angles=24):
    return ParallelBeamRadon(equispaced_angles(n_angles), N, angle_chunk=16)

def test_unet_preserves_shape():
    net = UNet(base_channels=8, n_levels=2)
    x = torch.randn(B, 1, N, N)
    assert net(x).shape == x.shape


def test_unrolled_runs_on_the_mri_operator():
    """One network, two modalities: the whole premise of the shared design."""
    net = UnrolledNet(n_cascades=2, base_channels=8, n_levels=2)
    x = torch.randn(B, 1, N, N)
    mri = _mri_op()
    assert net(mri.A(x), mri, op_norm=1.0).shape == x.shape


@pytest.mark.ct
def test_unrolled_runs_on_the_ct_operator_too():
    """The same network, unchanged, on the other modality."""
    net = UnrolledNet(n_cascades=2, base_channels=8, n_levels=2)
    x = torch.randn(B, 1, N, N)
    ct = _ct_op()
    assert net(ct.A(x), ct, op_norm=1.0).shape == x.shape


@pytest.mark.ct
def test_unrolled_accepts_geometry_it_was_not_built_for():
    """A single model must run under any angle count.

    This is what makes the generalisation sweeps possible: the operator is an
    argument to `forward`, not a property of the model.
    """
    net = UnrolledNet(n_cascades=2, base_channels=8, n_levels=2)
    x = torch.randn(1, 1, N, N)
    for n_angles in (12, 24, 60):
        op = _ct_op(n_angles)
        assert net(op.A(x), op, op_norm=1.0).shape == x.shape


def test_shared_weights_reduces_parameter_count():
    a = UnrolledNet(n_cascades=4, base_channels=8, shared_weights=False)
    b = UnrolledNet(n_cascades=4, base_channels=8, shared_weights=True)
    assert b.n_params < a.n_params

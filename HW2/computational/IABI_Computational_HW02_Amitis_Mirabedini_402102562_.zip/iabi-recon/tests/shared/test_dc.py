"""The data-consistency step.

The step must move the estimate *toward* agreement with the measurements. The
failure mode this catches is a sign error, which is nastier than it sounds: the
network still trains, the loss still moves, and the reconstruction slowly gets
worse in a way that looks like a hyperparameter problem rather than a bug.
"""

from __future__ import annotations

import pytest
import torch

from iabi.ct import equispaced_angles, ParallelBeamRadon
from iabi.mri import cartesian_mask, MaskedFFT
from iabi.shared.models import UnrolledNet
from iabi.shared.operator import estimate_operator_norm

N = 32


def _mri_op():
    gen = torch.Generator().manual_seed(0)
    return MaskedFFT(cartesian_mask(N, 4.0, batch=1, generator=gen))


def _ct_op():
    return ParallelBeamRadon(equispaced_angles(24), N, angle_chunk=16)


def _residual(op, x, y) -> float:
    return float((op.A(x) - y).abs().pow(2).sum())


def _check_descends(op):
    torch.manual_seed(0)
    net = UnrolledNet(n_cascades=1, base_channels=8, n_levels=2)
    truth = torch.randn(1, 1, N, N)
    y = op.A(truth)
    norm = estimate_operator_norm(op, (1, 1, N, N))

    x0 = torch.zeros_like(truth)
    before = _residual(op, x0, y)
    x1 = net.data_consistency(x0, y, op, torch.tensor(1.0), norm)
    after = _residual(op, x1, y)
    return before, after


def test_dc_step_reduces_measurement_residual_mri():
    before, after = _check_descends(_mri_op())
    assert after < before, (
        f"The data-consistency step increased the measurement residual "
        f"({before:.4g} -> {after:.4g}). This is almost always a sign error: "
        f"you want to step *against* the gradient, i.e. x - eta * grad, not "
        f"x + eta * grad."
    )


@pytest.mark.ct
def test_dc_step_reduces_measurement_residual_ct():
    before, after = _check_descends(_ct_op())
    assert after < before, (
        f"The data-consistency step increased the measurement residual "
        f"({before:.4g} -> {after:.4g}). Check the sign, and check that you "
        f"are dividing by op_norm: the CT operator's norm is far from 1, so "
        f"an unnormalised step of size 1 will overshoot wildly."
    )


def test_dc_step_is_exact_for_a_projection_operator():
    """With eta=1 the MRI step lands exactly on the measured lines.

    The masked FFT's normal operator is an orthogonal projection, so a single
    unit gradient step is not an approximation. It reproduces the acquired
    frequencies exactly and leaves the unacquired ones untouched. That is why
    `eta` initialised to 1 is a sensible default, and it is a satisfying thing
    to verify rather than take on faith.
    """
    op = _mri_op()
    net = UnrolledNet(n_cascades=1, base_channels=8, n_levels=2)
    torch.manual_seed(0)
    truth = torch.randn(1, 1, N, N)
    y = op.A(truth)

    x1 = net.data_consistency(torch.zeros_like(truth), y, op, torch.tensor(1.0), 1.0)
    assert torch.allclose(op.A(x1), y, atol=1e-5), (
        "After one unit step the simulated measurements should match the "
        "acquired ones exactly for the masked-FFT operator."
    )


def test_dc_step_leaves_a_consistent_estimate_alone():
    """A reconstruction already consistent with the data should not be moved."""
    op = _mri_op()
    net = UnrolledNet(n_cascades=1, base_channels=8, n_levels=2)
    torch.manual_seed(0)
    truth = torch.randn(1, 1, N, N)
    y = op.A(truth)
    consistent = op.A_adjoint(y)

    moved = net.data_consistency(consistent, y, op, torch.tensor(1.0), 1.0)
    rel = float((moved - consistent).norm() / consistent.norm())
    assert rel < 1e-5, (
        f"The step moved an already-consistent estimate by {rel:.2e}. The "
        f"residual A(x) - y should be (near) zero there, so the step should "
        f"be a no-op."
    )


def test_step_size_is_learnable_and_registered():
    net = UnrolledNet(n_cascades=3, learn_step_size=True)
    assert net.eta.requires_grad
    assert net.eta.shape == (3,)
    fixed = UnrolledNet(n_cascades=3, learn_step_size=False)
    assert not fixed.eta.requires_grad

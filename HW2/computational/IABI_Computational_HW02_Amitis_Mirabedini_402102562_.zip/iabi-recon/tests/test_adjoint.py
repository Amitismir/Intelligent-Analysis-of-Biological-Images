"""The adjoint identity. Get this test green before you do anything else.

`shared/operator.py` says why this one comes first.

The identity being checked is the *definition* of the adjoint::

    <A(x), y>  ==  <x, A_adjoint(y)>     for all x, y

If it holds for a few random `x` and `y`, it holds. This is a complete check,
not a spot check, which is what makes it a good gate.

On the tolerance
----------------
Both operators are checked to near machine precision, because for both of them
the adjoint is exact linear algebra and not an approximation.

The CT case looks like it should be approximate.
Rotation uses bilinear interpolation, and it is tempting to build the adjoint
by rotating back, which is wrong by about ten percent, passes a loose
tolerance, and degrades every data-consistency step downstream. The
transpose of an interpolation is a *scatter*, not the reverse interpolation.
`ct/operator.py` explains how the projector gets it exactly.
"""

from __future__ import annotations

import math

import pytest
import torch

from iabi.ct import equispaced_angles, ParallelBeamRadon
from iabi.mri import cartesian_mask, MaskedFFT
from iabi.shared.operator import real_inner

N = 32
SEED = 0


def _mri_operator(device="cpu") -> MaskedFFT:
    gen = torch.Generator().manual_seed(SEED)
    mask = cartesian_mask(N, acceleration=4.0, batch=2, generator=gen, device=device)
    return MaskedFFT(mask)


def _ct_operator(device="cpu") -> ParallelBeamRadon:
    return ParallelBeamRadon(equispaced_angles(24, device=device), N, angle_chunk=16)


@pytest.mark.parametrize(
    "make_op,tol,label",
    [
        (_mri_operator, 1e-4, "mri"),
        (_ct_operator, 1e-4, "ct"),
    ],
)
def test_adjoint_identity(make_op, tol, label):
    """<Ax, y> == <x, A^H y> for random x and y."""
    torch.manual_seed(SEED)
    op = make_op()
    x = torch.randn(2, 1, N, N)
    y = op.A(torch.randn(2, 1, N, N))
    # Perturb y so it is not exactly in the range of A: a broken adjoint can
    # accidentally pass when y is a forward image of something.
    y = y + 0.5 * torch.randn_like(y)

    lhs = real_inner(op.A(x), y)
    rhs = real_inner(x, op.A_adjoint(y))
    denom = max(abs(float(lhs)), abs(float(rhs)), 1e-12)
    rel = abs(float(lhs) - float(rhs)) / denom

    assert rel < tol, (
        f"[{label}] adjoint identity violated: <Ax,y>={float(lhs):.6g} but "
        f"<x,A^H y>={float(rhs):.6g} (relative error {rel:.2e} > {tol:.0e}).\n"
        f"Your A_adjoint is not the adjoint of your A. Compare it against "
        f"op.A_adjoint_via_autograd(y, x.shape), which is correct by "
        f"construction, to see where they diverge."
    )


@pytest.mark.parametrize(
    "make_op,tol,label",
    [(_mri_operator, 1e-4, "mri"), (_ct_operator, 1e-4, "ct")],
)
def test_adjoint_matches_autograd(make_op, tol, label):
    """The hand-written adjoint agrees with the autograd vector-Jacobian product.

    For a linear operator the VJP *is* the adjoint, so this is an independent
    second opinion on the same property, and unlike the inner-product test it
    tells you *where* the two disagree, which makes it the more useful one to
    debug against.
    """
    torch.manual_seed(SEED)
    op = make_op()
    shape = (2, 1, N, N)
    y = op.A(torch.randn(*shape)) + 0.5 * torch.randn_like(op.A(torch.randn(*shape)))

    manual = op.A_adjoint(y)
    auto = op.A_adjoint_via_autograd(y, shape)
    rel = float((manual - auto).norm() / auto.norm().clamp(min=1e-12))

    assert rel < tol, (
        f"[{label}] A_adjoint disagrees with the autograd adjoint by "
        f"{rel:.2e} (> {tol:.0e}). Most likely a missing or wrong scale factor."
    )


def test_mri_operator_norm_is_one():
    """A^H A for the masked FFT is an orthogonal projection, so its norm is 1.

    A useful independent check on the scaling of your MRI operator: if this
    comes out at anything other than 1, you have picked up a stray
    normalisation factor somewhere (a non-orthonormal FFT is the usual
    culprit), and every step size in the unrolled network will be wrong by
    that factor.
    """
    from iabi.shared.operator import estimate_operator_norm

    op = _mri_operator()
    norm = estimate_operator_norm(op, (1, 1, N, N), n_iter=30)
    assert math.isclose(norm, 1.0, rel_tol=1e-3), (
        f"||A^H A|| for the masked FFT should be exactly 1, got {norm:.6g}. "
        f"Check that fft2c/ifft2c are being used with norm='ortho' and that "
        f"you are not applying the mask more or fewer times than the "
        f"derivation calls for."
    )


def test_backprojection_is_not_the_inverse():
    """A^H A is not the identity.

    The unfiltered backprojection of a sinogram is recognisable but heavily blurred, because
    A^H A acts like a 1/|k| low-pass filter. Undoing that blur is what
    the ramp filter in `fbp` does.
    """
    op = _ct_operator()
    x = torch.zeros(1, 1, N, N)
    x[..., N // 4 : 3 * N // 4, N // 4 : 3 * N // 4] = 1.0
    back = op.A_adjoint(op.A(x))
    back = back / back.abs().max().clamp(min=1e-12)
    rel = float((back - x).norm() / x.norm())
    assert rel > 0.1, (
        "A^H A came out suspiciously close to the identity. That would mean "
        "your 'adjoint' is really an inverse, which usually means a rotation "
        "direction or an interpolation step is cancelling itself out."
    )

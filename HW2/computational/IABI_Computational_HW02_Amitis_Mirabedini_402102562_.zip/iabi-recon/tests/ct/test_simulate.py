"""Low-dose CT noise: Poisson counting, and why it is not Gaussian.

The property that makes this a low-dose problem rather than a denoising one is
signal dependence: rays through dense material arrive with fewer photons,
so those measurements are the noisiest. That is why streaks radiate from bone.
Adding Gaussian noise to a sinogram would pass a shape test and delete the
physics; `test_ct_is_not_merely_additive_gaussian` is what notices.
"""

from __future__ import annotations

import inspect
import math

import torch

from iabi.ct import equispaced_angles, ParallelBeamRadon, simulate_ct

N = 32


def _gen(seed: int = 0) -> torch.Generator:
    return torch.Generator().manual_seed(seed)


def _ct_op(n_angles: int = 30):
    return ParallelBeamRadon(equispaced_angles(n_angles), N, angle_chunk=16)


def _phantom(dense: float = 1.0) -> torch.Tensor:
    yy, xx = torch.meshgrid(
        torch.linspace(-1, 1, N), torch.linspace(-1, 1, N), indexing="ij"
    )
    x = torch.zeros(1, 1, N, N)
    x[0, 0][(xx**2 + yy**2) < 0.6**2] = dense
    return x

def test_ct_infinite_photons_is_the_clean_sinogram():
    """The noiseless limit must return the plain forward projection.

    This is the check that your attenuation scaling cancels. The simulator
    multiplies the image by `mu_scale` on the way in so the exponential lands in
    a sensible range; it has to divide it back out on the way, or every CT
    number you report is off by a constant factor.
    """
    op = _ct_op()
    x = _phantom()
    y = simulate_ct(x, op, photons=float("inf"))
    assert torch.allclose(y, op.A(x), atol=1e-4), (
        "With infinite photons the simulated sinogram must equal A(x) exactly. "
        "A constant factor off means `mu_scale` was applied but not undone."
    )


def test_ct_high_dose_converges_to_the_clean_sinogram():
    """At a huge but finite dose the noisy path must agree with A(x).

    The infinite-photon test above returns early, before any of the
    Beer-Lambert, Poisson or log steps run, so it cannot see them. This one
    goes through all of them. With a billion photons the Poisson noise is
    negligible, so what is left is the chain itself: `-log(I / I0)` undoes
    `I0 * exp(-A)` exactly, and anything else (a missing log, a linearised
    `1 - I / I0`, a forgotten `/ mu_scale`) is off by a lot on the dense rays.
    """
    op = _ct_op()
    x = _phantom()
    clean = op.A(x)
    y = simulate_ct(x, op, photons=1e9, generator=_gen())
    through = clean > 0.5 * clean.max()
    err = float((y - clean)[through].abs().max())
    assert err < 1e-2 * float(clean.max()), (
        f"at 1e9 photons the simulated sinogram is {err:.3g} away from A(x) on "
        f"the dense rays. The noise is negligible at this dose, so the chain "
        f"itself is wrong: the line integral is -log(counts / photons), divided "
        f"by mu_scale, not a linear approximation to it."
    )


def test_ct_counts_are_whole_photons():
    """The detector counts photons, so the counts must be integers.

    Undo the log to recover the counts the simulator drew. Poisson sampling
    gives whole numbers; a Gaussian approximation to it, however carefully
    scaled, does not. The Gaussian version is signal-dependent and skewed once
    it goes through the log, so the statistical tests below cannot tell it
    apart. This one can.
    """
    mu_scale = inspect.signature(simulate_ct).parameters["mu_scale"].default
    op = _ct_op()
    photons = 512.0
    y = simulate_ct(_phantom(), op, photons=photons, generator=_gen())
    counts = photons * torch.exp(-(y.double() * mu_scale))
    frac = (counts - counts.round()).abs()
    assert float(frac.max()) < 1e-2, (
        f"the recorded counts are not whole numbers (largest fractional part "
        f"{float(frac.max()):.3g}). Draw them with torch.poisson from the "
        f"Beer-Lambert intensity; do not add Gaussian noise to the intensity "
        f"or to the sinogram."
    )


def test_ct_noise_grows_as_dose_falls():
    op = _ct_op()
    x = _phantom()
    clean = simulate_ct(x, op, photons=float("inf"))

    errs = []
    for photons in (1e6, 4096.0, 256.0):
        y = simulate_ct(x, op, photons=photons, generator=_gen())
        errs.append(float((y - clean).abs().mean()))

    assert errs[0] < errs[1] < errs[2], (
        f"mean sinogram error at 1e6 / 4096 / 256 photons was {errs}. Fewer "
        f"incident photons must mean a noisier measurement. That is the whole "
        f"meaning of 'low dose'."
    )


def test_ct_noise_is_signal_dependent():
    """The property that makes this a low-dose problem, not a denoising one.

    Rays through dense material are attenuated hardest, so fewest photons reach
    the detector, so those line integrals are the noisiest. Gaussian noise added
    to the sinogram would be uniform across rays and would lose this.
    """
    op = _ct_op()
    photons = 2048.0

    def noise_std(density: float) -> float:
        x = _phantom(density)
        clean = simulate_ct(x, op, photons=float("inf"))
        errs = torch.stack(
            [
                simulate_ct(x, op, photons=photons, generator=_gen(s)) - clean
                for s in range(6)
            ]
        )
        # Only look at rays that actually pass through the object.
        through = clean.abs() > 0.1 * clean.abs().max()
        return float(errs[:, through].std())

    thin, thick = noise_std(0.3), noise_std(1.0)
    assert thick > 1.3 * thin, (
        f"noise standard deviation through dense material ({thick:.4g}) is not "
        f"meaningfully larger than through thin material ({thin:.4g}). Your "
        f"noise is being added to the sinogram directly instead of to the "
        f"photon counts before the log transform."
    )


def test_ct_sinogram_stays_finite_at_punishing_dose():
    """Zero recorded photons would give an infinite line integral.

    At very low dose some detector bins really do record nothing, and -log(0) is
    the model breaking down rather than a numerical accident. Clamping is the
    standard fix; it is also the reason the log-transform model is least
    trustworthy where the problem is hardest.
    """
    op = _ct_op()
    y = simulate_ct(_phantom(2.0), op, photons=8.0, generator=_gen())
    assert torch.isfinite(y).all(), (
        "The simulated sinogram contains inf or NaN. Clamp the photon counts to "
        "at least 1 before taking the logarithm."
    )


def test_ct_is_not_merely_additive_gaussian():
    """A sanity check that the log transform is in the chain at all."""
    op = _ct_op()
    x = _phantom()
    clean = simulate_ct(x, op, photons=float("inf"))
    noisy = simulate_ct(x, op, photons=512.0, generator=_gen())

    # Look at the most attenuated rays, where few photons arrive and the
    # asymmetry is largest. Averaged over the whole sinogram it would be
    # diluted by the air around the phantom, where counts are high and the
    # Poisson distribution is nearly Gaussian.
    through = clean > 0.5 * clean.max()
    err = (noisy - clean)[through].flatten()

    skew = float(((err - err.mean()) ** 3).mean() / err.std().pow(3).clamp(min=1e-12))
    assert abs(skew) > 0.05, (
        f"the simulated noise is almost perfectly symmetric (skew {skew:.3g}), "
        f"which suggests Gaussian noise was added to the sinogram rather than "
        f"Poisson noise to the photon counts before the log. Photon counting is "
        f"skewed at low counts, and the logarithm makes it more so."
    )


# ----------------------------------------------------------------------
# The dispatcher
# ----------------------------------------------------------------------


def test_mu_scale_is_documented_by_its_effect():
    """`mu_scale` sets how much of the photon budget survives to the detector.

    Not a correctness check but a calibration one. If transmission through the
    densest part of the phantom is a large fraction of I0 the problem is
    trivially noise-free; if it is essentially zero the log transform is being
    asked for something it cannot give. Somewhere in between is a real low-dose
    problem, and this test documents where the shipped default sits.
    """
    mu_scale = inspect.signature(simulate_ct).parameters["mu_scale"].default
    photons = inspect.signature(simulate_ct).parameters["photons"].default

    op = _ct_op()
    # The worst case this scaling will ever face: a solid object at full
    # intensity spanning the whole field of view.
    worst_case = 2.0 * 1.0 * mu_scale
    counts = photons * math.exp(-worst_case)

    assert counts > 1.0, (
        f"At mu_scale={mu_scale} the most attenuated possible ray delivers "
        f"{counts:.3g} photons. Below one photon the count clamps and the "
        f"measurement stops depending on the object at all: the sinogram goes "
        f"flat and nothing can be reconstructed from it."
    )
    assert counts < 0.2 * photons, (
        f"At mu_scale={mu_scale} even the most attenuated ray keeps "
        f"{counts / photons:.1%} of the beam, so every measurement is nearly "
        f"noise-free and there is no low-dose problem left to solve."
    )

"""Shape contracts for the CT operator, and the angle-chunking invariant.

Chunking exists so a large angle count fits in memory. It must not change the
answer, and that is what the last test here is for.
"""

from __future__ import annotations

import torch

from iabi.ct import equispaced_angles, ParallelBeamRadon

N = 32
B = 2


def _ct_op(n_angles=24):
    return ParallelBeamRadon(equispaced_angles(n_angles), N, angle_chunk=16)

def test_ct_forward_shape():
    op = _ct_op(n_angles=24)
    y = op.A(torch.randn(B, 1, N, N))
    assert y.shape == (B, 1, 24, N), (
        f"expected a sinogram of shape (B, 1, n_angles, n_detectors), got {tuple(y.shape)}"
    )


def test_ct_adjoint_shape():
    op = _ct_op(n_angles=24)
    y = op.A(torch.randn(B, 1, N, N))
    assert op.A_adjoint(y).shape == (B, 1, N, N)


def test_ct_angle_chunking_is_transparent():
    """Chunking is a memory optimisation and must not change the result."""
    angles = equispaced_angles(24)
    x = torch.randn(B, 1, N, N)
    full = ParallelBeamRadon(angles, N, angle_chunk=64).A(x)
    chunked = ParallelBeamRadon(angles, N, angle_chunk=5).A(x)
    assert torch.allclose(full, chunked, atol=1e-5)

"""Filtered backprojection: sharper than backprojection, and quantitative.

Two different claims, and both need testing. The first is structural: FBP
beats the raw adjoint. The second is that the numbers mean something: a disk of
known attenuation must come back at that attenuation, not merely at the right
shape. The correlation test is deliberately blind to brightness, so it cannot
catch a filter whose scale is wrong; `test_fbp_recovers_the_true_attenuation`
is what does.
"""

from __future__ import annotations

import torch

from iabi.ct import equispaced_angles, ParallelBeamRadon

N = 32
B = 2


def _ct_op(n_angles=24):
    return ParallelBeamRadon(equispaced_angles(n_angles), N, angle_chunk=16)

def test_ct_fbp_beats_plain_backprojection():
    """Filtering before backprojecting must actually help.

    A sanity check on the ramp filter and its scaling. Correlation with the
    ground truth is used rather than PSNR so the check is insensitive to any
    overall brightness offset. We are testing that the *structure* improves.
    """
    op = _ct_op(n_angles=90)
    x = torch.zeros(1, 1, N, N)
    x[..., N // 4 : 3 * N // 4, N // 4 : 3 * N // 4] = 1.0
    y = op.A(x)

    def corr(a, b):
        a = (a - a.mean()).flatten()
        b = (b - b.mean()).flatten()
        return float((a @ b) / (a.norm() * b.norm()).clamp(min=1e-12))

    assert corr(op.fbp(y), x) > corr(op.A_adjoint(y), x), (
        "Filtered backprojection is no better correlated with the truth than "
        "plain backprojection. Check the ramp filter and its frequency axis."
    )


def test_fbp_recovers_the_true_attenuation():
    """FBP must be quantitatively right, not merely structurally right.

    The correlation check above deliberately ignores brightness, so on its own
    it passes a filter that is scaled wrongly or that has lost the DC term.
    This one pins the number: a disk of known attenuation must reconstruct at
    that attenuation, and the background around it must come back at zero.

    The failure this guards against is specific. Building the ramp as
    ``rfftfreq(N).abs()`` sets the filter's gain at zero frequency to zero,
    which throws away the mean of every projection and leaves a smooth
    negative bowl whose depth grows with the size of the object, so a small
    phantom looks nearly right and a large one is far out. See `ramp_filter`.
    """
    n, n_angles, mu = 96, 120, 0.8
    op = ParallelBeamRadon(equispaced_angles(n_angles), n, angle_chunk=60)
    yy, xx = torch.meshgrid(
        torch.linspace(-1, 1, n), torch.linspace(-1, 1, n), indexing="ij"
    )
    radius = (xx**2 + yy**2).sqrt()[None, None]
    x = (radius < 0.5).float() * mu

    recon = op.fbp(op.A(x))
    # Well inside the disk and well outside it, staying clear of the smoothed
    # edge and of the image corners, which a parallel-beam scan never sees.
    inside = float(recon[radius < 0.35].mean())
    outside = float(recon[(radius > 0.65) & (radius < 0.9)].mean())

    # 0.5%, not a looser figure: a correct filter lands within 0.05%, and the
    # zero-DC ramp on a zero-padded grid is only 1.4% out on this disk, so a
    # 2% tolerance would pass the very bug this test exists for.
    assert abs(inside - mu) < 0.005 * mu, (
        f"a disk of attenuation {mu} reconstructed at {inside:.4f}. FBP is "
        f"structurally right but quantitatively wrong, which points at the "
        f"ramp filter's DC gain or its overall scale rather than at the "
        f"geometry."
    )
    assert abs(outside) < 0.005 * mu, (
        f"the background around the disk came back at {outside:+.4f} instead "
        f"of 0. A filter with no DC response leaves exactly this bowl, and its "
        f"depth grows with the size of the object."
    )

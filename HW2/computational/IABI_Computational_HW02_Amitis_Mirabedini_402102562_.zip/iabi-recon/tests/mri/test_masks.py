"""k-space undersampling masks.

The mask is the acquisition. Everything downstream is decided here: the
aliasing pattern, the acceleration factor you report, and whether compressed
sensing has any right to work. That is why it is worth its own test file
rather than being folded into the operator checks.
"""

from __future__ import annotations

import torch

from iabi.mri import cartesian_mask

W = 128


def _gen(seed: int = 0) -> torch.Generator:
    return torch.Generator().manual_seed(seed)


def test_mask_shape_and_values():
    mask = cartesian_mask(W, 4.0, batch=3, generator=_gen())
    assert mask.shape == (3, 1, 1, W), (
        f"expected (batch, 1, 1, width), got {tuple(mask.shape)}. The singleton "
        f"dimensions matter: the mask broadcasts down every row of k-space "
        f"because Cartesian undersampling skips whole phase-encode lines."
    )
    assert mask.dtype == torch.float32
    unique = set(mask.unique().tolist())
    assert unique <= {0.0, 1.0}, (
        f"mask must be binary, found values {sorted(unique)}. A soft mask would "
        f"turn undersampling into weighting."
    )


def test_centre_is_fully_sampled():
    """The ACS band is not optional: it carries the image contrast."""
    center_fraction = 0.08
    mask = cartesian_mask(W, 8.0, center_fraction=center_fraction, generator=_gen())
    n_center = int(round(W * center_fraction))
    lo = (W - n_center) // 2
    centre = mask[0, 0, 0, lo : lo + n_center]
    assert torch.all(centre == 1.0), (
        f"{int((centre == 0).sum())} of the {n_center} central columns are not "
        f"acquired. The centre of k-space must be fully sampled: it holds most "
        f"of the image energy, and skipping it does not merely alias the "
        f"reconstruction, it destroys its contrast."
    )


def test_acceleration_is_approximately_achieved():
    for r in (4.0, 8.0):
        mask = cartesian_mask(W, r, batch=8, generator=_gen())
        kept = float(mask.sum()) / 8
        target = W / r
        assert abs(kept - target) < 0.25 * target, (
            f"at R={r} the mask keeps {kept:.1f} of {W} columns, but R={r} means "
            f"about {target:.1f}. Remember the ACS band counts toward the budget: "
            f"the outer region gets the remainder, not the full 1/R share."
        )


def test_equispaced_mode_is_regular():
    """Equispaced sampling should use a constant stride away from the centre.

    Regular skipping is what produces *coherent* aliasing: crisp ghosts rather
    than the noise-like artefact random sampling gives you. Compressed sensing
    theory prefers the latter; a stock product sequence looks like the former.
    """
    center_fraction = 0.08
    mask = cartesian_mask(
        W, 4.0, center_fraction=center_fraction, mode="equispaced", generator=_gen()
    )
    n_center = int(round(W * center_fraction))
    lo = (W - n_center) // 2

    # Look only at the left of the fully-sampled band, where the stride is the
    # only thing setting the pattern.
    idx = mask[0, 0, 0, :lo].nonzero().flatten()
    assert len(idx) > 2, "equispaced mode acquired almost nothing outside the centre"
    gaps = (idx[1:] - idx[:-1]).unique()
    assert len(gaps) == 1, (
        f"equispaced mode produced gaps {gaps.tolist()} outside the ACS band; "
        f"expected a single constant stride."
    )


def test_random_and_equispaced_differ():
    """The two modes must actually be different acquisitions.

    They produce different artefacts, incoherent noise-like aliasing versus
    coherent ghosts, and comparing them is one of the cheapest ablations
    available to you.
    """
    a = cartesian_mask(W, 4.0, mode="random", generator=_gen(1))
    b = cartesian_mask(W, 4.0, mode="equispaced", generator=_gen(1))
    assert not torch.equal(a, b)


def test_masks_in_a_batch_are_independent():
    """A fresh mask per sample is a free and strong augmentation."""
    mask = cartesian_mask(W, 6.0, batch=4, generator=_gen())
    rows = [mask[i, 0, 0] for i in range(4)]
    assert any(not torch.equal(rows[0], r) for r in rows[1:]), (
        "every mask in the batch is identical. Draw one per sample, or "
        "the network sees a single sampling pattern and memorises its artefact."
    )

"""Shape and dtype contracts for the MRI operator.

Fast, unglamorous checks that catch the errors you would otherwise discover
partway through a training run. Run these right after `tests/test_adjoint.py`.
"""

from __future__ import annotations

import torch

from iabi.mri import cartesian_mask, MaskedFFT

N = 32
B = 2


def _mri_op():
    gen = torch.Generator().manual_seed(0)
    return MaskedFFT(cartesian_mask(N, 4.0, batch=B, generator=gen))

def test_mri_forward_shape_and_dtype():
    op = _mri_op()
    x = torch.randn(B, 1, N, N)
    y = op.A(x)
    assert y.shape == (B, 1, N, N)
    assert y.is_complex(), "MRI measurements are complex: k-space, not an image"


def test_mri_adjoint_is_real():
    op = _mri_op()
    y = op.A(torch.randn(B, 1, N, N))
    x = op.A_adjoint(y)
    assert x.shape == (B, 1, N, N)
    assert not x.is_complex(), (
        "A_adjoint must return a real image. Image space is real, so the "
        "adjoint takes the real part; see the derivation in mri/operator.py."
    )
    assert x.dtype == torch.float32


def test_mri_mask_zeroes_unacquired_lines():
    """Lines you did not acquire must be exactly zero, not merely small."""
    op = _mri_op()
    y = op.A(torch.randn(B, 1, N, N))
    unacquired = (op.mask.expand_as(y.real) == 0)
    assert torch.all(y[unacquired] == 0), (
        "Some unacquired k-space lines are non-zero. The mask is either not "
        "being applied or is being applied before the transform."
    )

"""MRI noise: additive complex Gaussian, and only where you measured.

Noise enters the *measurement*,
so it can only ever appear on lines the mask actually acquired. A simulator
that sprays noise across unacquired lines has invented signal.
"""

from __future__ import annotations

import torch

from iabi.mri import cartesian_mask, MaskedFFT, simulate_mri

N = 32


def _gen(seed: int = 0) -> torch.Generator:
    return torch.Generator().manual_seed(seed)


def _mri_op():
    return MaskedFFT(cartesian_mask(N, 4.0, batch=1, generator=_gen()))


def _phantom(dense: float = 1.0) -> torch.Tensor:
    yy, xx = torch.meshgrid(
        torch.linspace(-1, 1, N), torch.linspace(-1, 1, N), indexing="ij"
    )
    x = torch.zeros(1, 1, N, N)
    x[0, 0][(xx**2 + yy**2) < 0.6**2] = dense
    return x

def test_mri_noise_never_lands_on_unacquired_lines():
    """A line you did not acquire carries no noise. It carries nothing."""
    op = _mri_op()
    y = simulate_mri(_phantom(), op, noise_sigma=0.1, generator=_gen())
    unacquired = op.mask.expand_as(y.real) == 0
    assert torch.all(y[unacquired] == 0), (
        "Noise appeared on k-space lines that were never acquired. Add the "
        "noise first and mask afterwards (or mask the noise too), or "
        "the network can tell acquired-and-empty from never-acquired, which a "
        "real scanner cannot."
    )


def test_mri_noise_scales_with_sigma():
    op = _mri_op()
    x = _phantom()
    clean = simulate_mri(x, op, noise_sigma=0.0)
    assert torch.allclose(clean, op.A(x)), "sigma=0 must give the noiseless measurement"

    for sigma in (0.01, 0.05):
        y = simulate_mri(x, op, noise_sigma=sigma, generator=_gen())
        on_mask = op.mask.expand_as(y.real) > 0
        err = (y - op.A(x))[on_mask]
        # Complex noise with total power sigma^2, i.e. sigma/sqrt(2) per part.
        measured = float(err.abs().pow(2).mean().sqrt())
        assert abs(measured - sigma) < 0.35 * sigma, (
            f"requested sigma={sigma}, measured {measured:.4f} in the acquired "
            f"lines. The real and imaginary parts each carry half the power."
        )


# ----------------------------------------------------------------------
# CT: Beer-Lambert, Poisson counting, log transform
# ----------------------------------------------------------------------
